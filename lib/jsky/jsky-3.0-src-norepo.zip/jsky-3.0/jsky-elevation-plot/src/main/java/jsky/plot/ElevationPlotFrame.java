// Copyright 2003
// Association for Universities for Research in Astronomy, Inc.,
// Observatory Control System, Gemini Telescopes Project.
//
// $Id: ElevationPlotFrame.java,v 1.1.1.1 2009/02/17 22:49:36 abrighto Exp $

package jsky.plot;

import java.awt.BorderLayout;

import javax.swing.JFrame;

import jsky.util.Preferences;


/**
 * Provides a top level window for an ElevationPlotPanel panel.
 *
 * @version $Revision: 1.1.1.1 $
 * @author Allan Brighton
 */
public class ElevationPlotFrame extends JFrame {

    // The GUI panel
    private ElevationPlotPanel _plotPanel;

    /**
     * Create a top level window containing an ElevationPlotPanel.
     */
    public ElevationPlotFrame() {
        super("Elevation Plot");
        _plotPanel = new ElevationPlotPanel();
        setJMenuBar(new ElevationPlotMenuBar(_plotPanel));
        getContentPane().add(_plotPanel, BorderLayout.CENTER);
        pack();
        Preferences.manageLocation(this);
        setVisible(true);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
    }

    public ElevationPlotPanel getPlotPanel() {
        return _plotPanel;
    }
}

