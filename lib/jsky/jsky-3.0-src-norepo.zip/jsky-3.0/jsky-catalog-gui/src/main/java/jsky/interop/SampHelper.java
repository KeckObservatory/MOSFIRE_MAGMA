package jsky.interop;

import org.astrogrid.samp.client.ClientProfile;
import org.astrogrid.samp.client.AbstractMessageHandler;
import org.astrogrid.samp.client.HubConnection;
import org.astrogrid.samp.client.SampException;
import org.astrogrid.samp.xmlrpc.StandardClientProfile;
import org.astrogrid.samp.gui.GuiHubConnector;
import org.astrogrid.samp.Metadata;
import org.astrogrid.samp.Message;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.net.URL;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

import jsky.util.gui.DialogUtil;
import jsky.util.Resources;
import jsky.navigator.Navigator;
import jsky.navigator.NavigatorImageDisplayFrame;
import jsky.catalog.vo.VoTable;
import jsky.catalog.vo.VoCatalog;
import jsky.catalog.gui.TableDisplayTool;
import jsky.catalog.QueryResult;
import jsky.catalog.TableQueryResult;
import jsky.image.gui.DivaMainImageDisplay;
import jsky.image.gui.MainImageDisplay;
import jsky.image.ImageChangeEvent;

import javax.swing.SwingUtilities;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JComponent;
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.Icon;
import javax.swing.Action;
import javax.swing.ComboBoxModel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListDataEvent;

/**
 * Manages access to the SAMP (JSamp) features for interprocess communication.
 * <p/>
 * See <a href="http://www.ivoa.net/cgi-bin/twiki/bin/view/IVOA/SampMTypes">here</a>
 * for list of standard types.
 *
 * @author Allan Brighton
 * @since Feb 15, 2009
 */
public class SampHelper {

    private static final Logger LOG = Logger.getLogger(SampHelper.class.getName());

// From http://www.ivoa.net/cgi-bin/twiki/bin/view/IVOA/SampMTypes for list of standard types:
//
//  table.load.votable
//  Loads a table in VOTable format.
//
//      * Arguments:
//            o url (string): URL of the VOTable document to load
//            o table-id (string) optional: identifier which may be used to refer to the loaded table in subsequent messages
//            o name (string) optional: name which may be used to label the loaded table in the application GUI
//      * Return Values: none
//
//  table.load.fits
//  Loads a table in FITS format.
//
//      * Arguments:
//            o url (string): URL of the FITS file to load
//            o table-id (string) optional: identifier which may be used to refer to the loaded table in subsequent messages
//            o name (string) optional: name which may be used to label the loaded table in the application GUI
//      * Return Values: none
//
//  table.highlight.row
//  Highlights a single row of an identified table by row index. The table to operate on is identified by one or both of
//  the table-id or url arguments. At least one of these must be supplied; if both are given they should refer to the same
//  thing. Exactly what highlighting means is left to the receiving application.
//
//      * Arguments:
//            o table-id (string): identifier associated with a table by a previous message (e.g. table.load.*)
//            o url (string): URL of a table
//            o row (SAMP int): Row index (zero-based) of the row to highlight.
//      * Return Values: none
//
//  table.select.rowList
//  Selects a list of rows of an identified table by row index. The table to operate on is identified by one or both of
//  the table-id or url arguments. At least one of these must be supplied; if both are given they should refer to the same
//  thing. Exactly what selection means is left to the receiving application.
//
//      * Arguments:
//            o table-id (string): identifier associated with a table by a previous message (e.g. table.load.*)
//            o url (string): URL of a table
//            o row-list (list of SAMP int): list of row indices (zero-based) defining which table rows are to form the
//              selection
//      * Return Values: none
//
//  image.load.fits
//  Loads a 2-dimensional FITS image.
//
//      * Arguments:
//            o url (string): URL of the FITS image to load
//            o image-id (string) optional: Identifier which may be used to refer to the loaded image in subsequent messages
//            o name (string) optional: name which may be used to label the loaded image in the application GUI
//      * Return Values: none
//
//  coord.pointAt.sky
//  Directs attention (e.g. by moving a cursor or shifting the field of view) to a given point on the celestial sphere.
//
//      * Arguments:
//            o ra (SAMP float): right ascension in degrees
//            o dec (SAMP float): declination in degrees
//      * Return Values: none

    private static final String TABLE_LOAD_VOTABLE = "table.load.votable";
    private static final String TABLE_LOAD_FITS = "table.load.fits";
    private static final String TABLE_HIGHLIGHT_ROW = "table.highlight.row";
    private static final String TABLE_SELECT_ROW_LIST = "table.select.rowList";
    private static final String IMAGE_LOAD_FITS = "image.load.fits";
    private static final String COORDS_POINT_AT_SKY = "coord.pointAt.sky";

    private static final String[] MESSAGE_TYPES = {
            TABLE_LOAD_VOTABLE,
            TABLE_LOAD_FITS,
            TABLE_HIGHLIGHT_ROW,
            TABLE_SELECT_ROW_LIST,
            IMAGE_LOAD_FITS,
            COORDS_POINT_AT_SKY
    };

    // Singleton instance of this class
    private static SampHelper _instance;

    // The SAMP connector
    private GuiHubConnector _connector;

    // the main image display frame
    private NavigatorImageDisplayFrame _imageFrame;

    // Action to display the SAMP config window
    private WindowAction _windowAction;

    // Check box that controls if table row selections are broadcast
    private JCheckBoxMenuItem _broadcastRowSelectionsMenuItem;

    // Manages sending the row selection messages to selected SAMP clients
    private SendManager _tableSelectionSendManager;

    // Set to true while processing a SAMP message
    private boolean _processingMessage;


    /**
     * This method should be called once at the start of the application to initialize SAMP with the application name,
     * icon and other relevant information
     *
     * @param meta       contains application specific information
     * @param imageFrame the main image display frame
     */
    public static void init(Metadata meta, NavigatorImageDisplayFrame imageFrame) {
        if (_instance == null) {
            _instance = new SampHelper(meta, imageFrame);
        }
    }

    /**
     * Before calling this method, the static init method needs to be called once.
     *
     * @return the singleton instance of this class
     */
    public static SampHelper getInstance() {
        return _instance;
    }

    /**
     * @return the SAMP connector
     */
    public GuiHubConnector getConnector() {
        return _connector;
    }

    /**
     * Initialize the SAMP connection support
     *
     * @param meta       application specific data
     * @param imageFrame the main image frame
     */
    public SampHelper(Metadata meta, NavigatorImageDisplayFrame imageFrame) {
        _imageFrame = imageFrame;

        // Construct a connector
        ClientProfile profile = StandardClientProfile.getInstance();
        _connector = new GuiHubConnector(profile);

        // Configure it with metadata about this application
        _connector.declareMetadata(meta);

        // Prepare to receive messages with specific MType(s)
        _connector.addMessageHandler(new AbstractMessageHandler(MESSAGE_TYPES) {
            public Map processCall(HubConnection c, final String senderId, final Message msg) {
                try {
                    // This method is not called in the event processing thread, so invoke later
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                _processingMessage = true;
                                handleMessage(senderId, msg);
                            } catch (Exception e) {
                                DialogUtil.error(e);
                            } finally {
                                _processingMessage = false;
                            }
                        }
                    });
                    return null;
                } catch (Exception e) {
                    DialogUtil.error(e);
                    return null;
                }
            }
        });

        // This step required even if no custom message handlers added.
        _connector.declareSubscriptions(_connector.computeSubscriptions());

        // Keep a look out for hubs if initial one shuts down
        _connector.setAutoconnect(10);
    }

    /**
     * Implements message processing.  Implementations should return a map which contains the <code>samp.result</code>
     * part of the call response, that is the MType-specific return value name-&gt;value map. As a special case,
     * returning null is equivalent to returning an empty map.
     *
     * @param senderId public ID of sender client
     * @param message  message with MType this handler is subscribed to
     * @return MType-specific return name-&gt;value map; null may be used for an empty map
     * @throws Exception on error
     */
    protected Map handleMessage(String senderId, Message message) throws Exception {
        LOG.info("process call from: " + senderId + ", msg = " + message);

        String type = message.getMType();
        if (TABLE_LOAD_VOTABLE.equals(type)) {
            URL url = new URL((String) message.getParam("url"));
            String name = (String) message.getParam("name");
            String tableId = (String) message.getParam("table-id");
            if (name == null) {
                name = tableId;
            }
            tableLoadVotable(url, tableId, name);
        } else if (TABLE_LOAD_FITS.equals(type)) {
            URL url = new URL((String) message.getParam("url"));
            String name = (String) message.getParam("name");
            String tableId = (String) message.getParam("table-id");
            if (name == null) {
                name = tableId;
            }
            tableLoadFits(url, tableId, name);
        } else if (IMAGE_LOAD_FITS.equals(type)) {
            URL url = new URL((String) message.getParam("url"));
            String name = (String) message.getParam("name");
            String imageId = (String) message.getParam("image-id");
            if (name == null) {
                name = imageId;
            }
            imageLoadFits(url, imageId, name);
        } else if (TABLE_HIGHLIGHT_ROW.equals(type)) {
            String tableId = (String) message.getParam("table-id");
            String urlStr = (String) message.getParam("url");
            URL url = null;
            if (urlStr != null) {
                url = new URL(urlStr);
            }
            String rowStr = (String) message.getParam("row");
            if (rowStr != null) {
                int row = Integer.parseInt(rowStr);
                tableHighlightRow(tableId, url, row);
            }
        } else if (TABLE_SELECT_ROW_LIST.equals(type)) {
            String tableId = (String) message.getParam("table-id");
            String urlStr = (String) message.getParam("url");
            URL url = null;
            if (urlStr != null) {
                url = new URL(urlStr);
            }
            @SuppressWarnings({"unchecked"})
            List<String> rowList = (List<String>) message.getParam("row-list");
            if (rowList != null) {
                tableSelectRowList(tableId, url, rowList);
            }
        } else if (COORDS_POINT_AT_SKY.equals(type)) {
            double ra = Double.parseDouble((String) message.getParam("ra"));
            double dec = Double.parseDouble((String) message.getParam("dec"));
            coordPointAtSky(ra, dec);
        }
        return null;
    }

    /**
     * Loads and displays the VO table pointed to by the given URL
     *
     * @param url     URL of the VOTable document to load
     * @param tableId optional: identifier which may be used to refer to the loaded table in subsequent message
     * @param name    optional: name which may be used to label the loaded table in the application GUI
     * @throws Exception on error
     */
    protected void tableLoadVotable(URL url, String tableId, String name) throws Exception {
        Navigator navigator = _imageFrame.getNavigator();
        if (navigator != null) {
            VoCatalog catalog = new VoCatalog(VoTable.createVoTable(url, tableId, name));
            navigator.setQueryResult(catalog);
            navigator.setOrigURL(url); // XXX is this still needed?
            navigator.registerTable(url, tableId);
        }
    }

    /**
     * Loads and displays the FITS table pointed to by the given URL
     *
     * @param url     URL of the FITS table to load
     * @param tableId optional: identifier which may be used to refer to the loaded table in subsequent message
     * @param name    optional: name which may be used to label the loaded table in the application GUI
     * @throws Exception on error
     */
    protected void tableLoadFits(URL url, String tableId, String name) throws Exception {
        tableLoadVotable(url, tableId, name); // StarTable should hanlde FITS also
    }

    /**
     * Loads and displays the FITS image pointed to by the given URL
     *
     * @param url     URL of the FITS image to load
     * @param imageId optional: identifier which may be used to refer to the loaded image in subsequent message
     * @param name    optional: name which may be used to label the loaded image in the application GUI
     * @throws Exception on error
     */
    protected void imageLoadFits(URL url, String imageId, String name) throws Exception {
        DivaMainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        imageDisplay.setURL(url);
//        imageDisplay.setImageId(imageId); TODO imageId is not used anywhere yet
    }

    /**
     * Highlights a single row of an identified table by row index. The table to operate on is identified by one or both
     * of the table-id or url arguments. At least one of these must be supplied; if both are given they should refer to
     * the same thing. Exactly what highlighting means is left to the receiving application.
     *
     * @param tableId identifier associated with a table by a previous message (e.g. table.load.*)
     * @param url     URL of a table
     * @param row     Row index (zero-based) of the row to highlight.
     * @throws Exception on error
     */
    protected void tableHighlightRow(String tableId, URL url, int row) throws Exception {
        Navigator navigator = _imageFrame.getNavigator();
        if (navigator != null) {
            navigator.selectTableRows(tableId, url, new int[]{row});
        }
    }

    /**
     * Selects a list of rows of an identified table by row index. The table to operate on is identified by one or both
     * of the table-id or url arguments. At least one of these must be supplied; if both are given they should refer to
     * the same thing. Exactly what selection means is left to the receiving application.
     *
     * @param tableId identifier associated with a table by a previous message (e.g. table.load.*)
     * @param url     URL of a table
     * @param rowList indexes (zero-based) of the rows to highlight.
     * @throws Exception on error
     */
    protected void tableSelectRowList(String tableId, URL url, List<String> rowList) throws Exception {
        Navigator navigator = _imageFrame.getNavigator();
        if (navigator != null) {
            int[] rows = new int[rowList.size()];
            for (int i = 0; i < rows.length; i++) {
                rows[i] = Integer.parseInt(rowList.get(i));
            }
            navigator.selectTableRows(tableId, url, rows);
        }
    }

    /**
     * Directs attention (e.g. by moving a cursor or shifting the field of view) to a given
     * point on the celestial sphere.
     *
     * @param ra  right ascension in degrees
     * @param dec declination in degrees
     * @throws Exception on error
     */
    protected void coordPointAtSky(double ra, double dec) throws Exception {
        DivaMainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        imageDisplay.loadCachedImage(ra, dec);
    }


    /**
     * Fills the given menu with the table related actions implemented in this class.
     *
     * @param menu the menu to add items to
     */
    public void initTableMenu(JMenu menu) {
        _initTableMenu(menu, null, null, new HashMap());
    }

    /**
     * Fills the given menu with the table related actions implemented in this class.
     *
     * @param menu   the menu to add items to
     * @param url    URL of the table to send, or null to use the displayed table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     */
    public void initTableMenu(JPopupMenu menu, URL url, String format, Map ucdMap) {
        _initTableMenu(menu, url, format, ucdMap);
    }

    /**
     * Fills the given menu with the table related actions implemented in this class.
     *
     * @param menu   the menu to add items to
     * @param url    URL of the table to send, or null to use the displayed table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     */
    public void initTableMenu(JMenu menu, URL url, String format, Map ucdMap) {
        _initTableMenu(menu, url, format, ucdMap);
    }

    /**
     * Fills the given menu with the table related or general actions implemented in this class.
     *
     * @param menu   the menu (JMenu or JPopupMenu) to add items to
     * @param url    URL of the table to send, or null to use the displayed table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     */
    private void _initTableMenu(JComponent menu, URL url, String format, Map ucdMap) {
        if (menu instanceof JMenu) {
            // Add a SAMP control window item in the main menu
            JMenu m = (JMenu) menu;
            m.add(getWindowAction());
            m.addSeparator();
        }

        // Add the Send Table to ... menu item
        final Navigator navigator = _imageFrame.getNavigator();

        final TableSendActionManager man = new TableSendActionManager(navigator, _connector, url, format, ucdMap);
        menu.add(man.createSendMenu());

        final JMenuItem broadCastItem = new JMenuItem("Broadcast Table");
        broadCastItem.setIcon(Resources.getIcon("broadcast.gif"));
        broadCastItem.addActionListener(man.getBroadcastAction());
        menu.add(broadCastItem);

        if (url == null) {
            man.setEnabled(false);
            broadCastItem.setEnabled(false);
            navigator.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent changeEvent) {
                    boolean enabled = navigator.getResultComponent() instanceof TableDisplayTool;
                    man.setEnabled(enabled);
                    broadCastItem.setEnabled(enabled);
                }
            });
        } else {
            man.setEnabled(true);
        }

        if (menu instanceof JMenu) {
            JMenu m = (JMenu) menu;
            m.addSeparator();
            JMenu transmitSelectedRowsMenu = _makeTransmitSelectedRowsMenu();
            _broadcastRowSelectionsMenuItem = _makeBroadcastRowSelectionsMenuItem(transmitSelectedRowsMenu);
            m.add(_broadcastRowSelectionsMenuItem);
            m.add(transmitSelectedRowsMenu);
        }
    }

    /**
     * Returns a checkbox menu item to enable/disable broadcasting row selections
     *
     * @param transmitSelectedRowsMenu menu to enable and disable depending on the checkbox state
     * @return the menu item
     */
    private JCheckBoxMenuItem _makeBroadcastRowSelectionsMenuItem(final JMenu transmitSelectedRowsMenu) {
        final JCheckBoxMenuItem item = new JCheckBoxMenuItem("Broadcast Row Selections");
        item.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                transmitSelectedRowsMenu.setEnabled(item.isSelected());
            }
        });
        return item;
    }

    /**
     * Creates and returns a menu for configuring where messages are sent when rows are selected.
     * The existing StarJava code maintains a ComboBoxModel, which is adapted here for use in a menu.
     *
     * @return the menu
     */
    private JMenu _makeTransmitSelectedRowsMenu() {
        final JMenu menu = new JMenu("Transmit Selected Rows to");
        _tableSelectionSendManager = new SendManager(_connector, "table.select.rowList");
        final ComboBoxModel comboBoxModel = _tableSelectionSendManager.getComboBoxModel();
        // monitor changes in the ComboBoxModel to keep the menu up to date
        comboBoxModel.addListDataListener(new ListDataListener() {
            @Override
            public void intervalAdded(ListDataEvent e) {
            }

            @Override
            public void intervalRemoved(ListDataEvent e) {
            }

            @Override
            public void contentsChanged(ListDataEvent e) {
                menu.removeAll();
                ButtonGroup group = new ButtonGroup();
                for (int i = 0; i < comboBoxModel.getSize(); i++) {
                    final Object o = comboBoxModel.getElementAt(i);
                    JRadioButtonMenuItem item = new JRadioButtonMenuItem(o.toString());
                    group.add(item);
                    if (o == comboBoxModel.getSelectedItem()) {
                        item.setSelected(true);
                    }
                    menu.add(item);
                    item.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            comboBoxModel.setSelectedItem(o);
                        }
                    });
                }
            }
        });
        menu.setEnabled(false);
        return menu;
    }


    /**
     * Makes a map for a SAMP message for sending the selected rows in the current table
     * @param rowList list of selected row indexes in the currently displayed table
     *
     * @return a map of parameter names to values for the "table.select.rowList" message
     */
    private Map _makeTransmitSelectedRowsMessage(List<Integer> rowList) {
        Navigator navigator = _imageFrame.getNavigator();
        QueryResult queryResult = navigator.getQueryResult();
        if (queryResult instanceof TableQueryResult) {
            TableQueryResult table = (TableQueryResult) queryResult;
            String tableId = table.getId();
            String sampId = TableSendActionManager.getSampId(tableId);
            if (sampId != null) {
                // Must be a table we sent, so use the samp table id we sent it with
                tableId = sampId;
            }
            URL url = navigator.getOrigURL();
            String urlStr = url != null ? url.toString() : null;
            Message msg = new Message("table.select.rowList");
            if (tableId != null) {
                msg.addParam("table-id", tableId);
            }
            if (urlStr != null) {
                msg.addParam("url", urlStr);
            }
            if (urlStr != null || tableId != null) {
                // convert Integer list to String list
                List<String> strRowList = new ArrayList<String>(rowList.size());
                for(Integer i : rowList) {
                    strRowList.add(i.toString());
                }
                msg.addParam("row-list", strRowList);
                msg.check();
                return msg;
            }
        }
        return null;
    }

    /**
     * Transmit the given row selection to the selected clients
     * @param rowList list of selected row indexes in the currently displayed table
     */
    public void transmitSelectedRows(List<Integer> rowList) {
        if (_processingMessage || !_broadcastRowSelectionsMenuItem.isSelected()) {
            return;
        }
        Map map = _makeTransmitSelectedRowsMessage(rowList);
        if (map != null) {
            try {
                _tableSelectionSendManager.call(map);
            } catch (SampException e) {
                LOG.warning(e.toString());
            }
        }
    }


    /**
     * Fills the given menu with the image related actions implemented in this class.
     *
     * @param menu the menu to add items to
     */
    public void initImageMenu(JMenu menu) {
        _initImageMenu(menu, null);
    }

    /**
     * Fills the given menu with the image related actions implemented in this class.
     *
     * @param menu the menu to add items to
     * @param url  the url of the image to send
     */
    public void initImageMenu(JPopupMenu menu, URL url) {
        _initImageMenu(menu, url);
    }

    /**
     * Fills the given menu with the image related actions implemented in this class.
     *
     * @param menu the menu (JMenu or JPopupMenu) to add items to
     * @param url  the url of the image to send (optional: otherwise the displayed image is used)
     */
    private void _initImageMenu(JComponent menu, URL url) {
        if (menu instanceof JMenu) {
            // Add a SAMP control window item in the main menu
            JMenu m = (JMenu) menu;
            m.add(getWindowAction());
            m.addSeparator();
        }

        // Add the Send Table to ... menu item
        final MainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        final ImageSendActionManager man = new ImageSendActionManager(imageDisplay, _connector, url);

        menu.add(man.createSendMenu());

        final JMenuItem broadCastItem = new JMenuItem("Broadcast Image");
        broadCastItem.setIcon(Resources.getIcon("broadcast.gif"));
        broadCastItem.addActionListener(man.getBroadcastAction());
        menu.add(broadCastItem);

        if (url == null) {
            broadCastItem.setEnabled(false);
            man.setEnabled(false);
            imageDisplay.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent changeEvent) {
                    ImageChangeEvent e = (ImageChangeEvent) changeEvent;
                    if (e.isNewImage() && !e.isBefore()) {
                        boolean enabled = (imageDisplay.getURL() != null || imageDisplay.getFilename() != null);
                        man.setEnabled(enabled);
                        broadCastItem.setEnabled(enabled);
                    }
                }
            });
        } else {
            man.setEnabled(true);
        }
    }

    public Action getWindowAction() {
        if (_windowAction == null) {
            Icon sampOffIcon = Resources.getIcon("samp.gif");
            Icon sampOnIcon = Resources.getIcon("sampgo.gif");
            _windowAction = new WindowAction("SAMP Control", sampOffIcon, sampOnIcon);
        }
        return _windowAction;
    }

    /**
     * Action for displaying SAMP status window.
     */
    private class WindowAction
            extends AbstractAction
            implements ChangeListener {
        /**
         * SAMP control window object.
         */
        private JFrame sampFrame = null;

        /**
         * Icon representing disconnected state.
         */
        private Icon offIcon;

        /**
         * Icon representing connected state.
         */
        private Icon onIcon;

        /**
         * Constructor.
         *
         * @param name    action name
         * @param offIcon action icon when disconnected
         * @param onIcon  action icon when connected
         */
        WindowAction(String name, Icon offIcon, Icon onIcon) {
            super(name);
            this.offIcon = offIcon;
            this.onIcon = onIcon;
            putValue(SHORT_DESCRIPTION, "Show SAMP Control Window (Application Interoperability)");

            //  Change icon in accordance with connection status.
            _connector.addConnectionListener(this);
            stateChanged(null);
        }

        public void actionPerformed(ActionEvent ae) {
            if (sampFrame == null) {
                sampFrame = new SampFrame(_connector);
            }
            sampFrame.setVisible(true);
        }

        /**
         * Invoked when connection status has, or may have, changed.
         */
        public void stateChanged(ChangeEvent ce) {
            putValue(SMALL_ICON, _connector.isConnected() ? onIcon : offIcon);
        }
    }
}
