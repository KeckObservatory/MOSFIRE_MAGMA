/*
 * $Id: CatalogHistoryItem.java,v 1.3 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.catalog.gui;

import java.awt.event.ActionEvent;
import java.io.Serializable;
import java.io.IOException;
import java.net.URL;
import java.net.MalformedURLException;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.Action;
import javax.swing.Icon;

import jsky.catalog.URLQueryResult;
import jsky.catalog.CatalogFactory;
import jsky.catalog.Catalog;
import jsky.util.gui.DialogUtil;


/**
 * Local class used to store information about previously viewed catalogs or query results. During a given session, the
 * display component is saved and can be redisplayed if needed. If the application is restarted, the URL can be used
 * instead.
 */
public class CatalogHistoryItem implements Action, Serializable {

    // The URL of the catalog, table or FITS file, if known, otherwise null.
    private String _urlStr;

    // The catalogs's name
    private String _name;

    // The catalogs's type
    private String _type;

    // The component displaying the catalog (used in this session).
    private transient JComponent _queryComponent;

    // Action to be used to load the image file
    private transient AbstractAction _action;

    /**
     * Create a catalog history item with the given name (for display), URL string (for catalog files), and display
     * component. The component is used during this session, otherwise the name or URL are used.
     *
     * @param name The catalogs's name
     * @param url The URL of the catalog, table or FITS file, if known, otherwise null
     * @param queryComponent The component displaying the catalog or query results (used in this session).
     */
    public CatalogHistoryItem(String name, URL url, JComponent queryComponent) {
        _name = name;
        Catalog catalog = CatalogFactory.getCatalogByName(name);
        if (catalog != null) {
            _type = catalog.getType();
        }
        if (url != null) {
            _urlStr = url.toString();
        }
        _queryComponent = queryComponent;

        _initAction();
    }

    // Restores transient _action field during deserialization
    private void readObject(java.io.ObjectInputStream in)
            throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        _initAction();
    }

    // Initialize an action that can be used in menus to view the selected catalog
    private void _initAction() {
        _action = new AbstractAction(_name) {
            {
                putValue(Action.SMALL_ICON, _getIcon(_type));
            }

            /**
             * Display the catalog
             */
            public void actionPerformed(ActionEvent evt) {
                try {
                    CatalogNavigator navigator = CatalogNavigatorMenuBar.getCurrentCatalogNavigator();
                    URL url = null;
                    if (_urlStr != null) {
                        url = new URL(_urlStr);
                    }

                    if (_queryComponent != null) {
                        navigator.setOrigURL(url);
                        navigator.setQueryComponent(_queryComponent);
                    } else if (url != null) {
                        navigator.setQueryResult(new URLQueryResult(url));
                    } else if (navigator instanceof CatalogNavigatorOpener) {
                        ((CatalogNavigatorOpener) navigator).openCatalogWindow(_name);
                    } else {
                        DialogUtil.error("Don't know how to display catalog");
                    }
                } catch (Exception e) {
                    DialogUtil.error(e);
                }
            }
        };
    }

    /**
     * Returns the icon for the given catalog type
     *
     * @param type the catalog type (service type)
     * @return the Icon
     */
    private Icon _getIcon(String type) {
        if (type != null) {
            if (type.equals("catalog")) {
                return CatalogTreeCellRenderer.CATALOG_ICON;
            }
            if (type.equals("archive")) {
                return CatalogTreeCellRenderer.ARCHIVE_ICON;
            }
            if (type.equals("namesvr")) {
                return CatalogTreeCellRenderer.NAME_SERVER_ICON;
            }
            if (type.equals("imagesvr")) {
                return CatalogTreeCellRenderer.IMAGE_SERVER_ICON;
            }
        }
        return CatalogTreeCellRenderer.CATALOG_ICON;
    }

    /**
     * @return the URL string of the catalog, table or FITS file, if known, otherwise null.
     */
    public String getURLStr() {
        return _urlStr;
    }

    /**
     * @return the URL of the catalog, table or FITS file, if known and valid, otherwise null.
     */
    public URL getUrl() {
        try {
            return _urlStr == null ? null : new URL(_urlStr);
        } catch (MalformedURLException e) {
            return null;
        }
    }

    /**
     * @return the catalogs's name.
     */
    public String getName() {
        return _name;
    }

    /**
     * @return the component displaying the catalog or query results (used in this session).
     */
    public JComponent getQueryComponent() {
        return _queryComponent;
    }

    // --- Implement Action interface ---

    public Object getValue(String key) {
        return _action.getValue(key);
    }

    public void putValue(String key, Object value) {
        _action.putValue(key, value);
    }

    public void setEnabled(boolean b) {
        _action.setEnabled(b);
    }

    public boolean isEnabled() {
        return _action.isEnabled();
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        _action.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        _action.removePropertyChangeListener(listener);
    }

    public void actionPerformed(ActionEvent e) {
        _action.actionPerformed(e);
    }
}
