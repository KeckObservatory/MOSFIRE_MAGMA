/*
 * $Id: NavigatorImageDisplayControl.java,v 1.3 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.navigator;

import java.net.*;

import jsky.image.gui.ImageDisplayControl;
import jsky.image.gui.DivaMainImageDisplay;

/**
 * Extends the ImageDisplayControl class by adding support for
 * browsing catalogs and plotting catalog symbols on the image.
 *
 * @version $Revision: 1.3 $
 * @author Allan Brighton
 */
public class NavigatorImageDisplayControl extends ImageDisplayControl {

    /**
     * Construct a NavigatorImageDisplayControl widget.
     *
     * @param size   the size (width, height) to use for the pan and zoom windows.
     */
    public NavigatorImageDisplayControl(int size) {
        super(size);
    }

    /**
     * Make a NavigatorImageDisplayControl widget with the default settings.
     */
    public NavigatorImageDisplayControl() {
        super();
    }


    /**
     * Make a NavigatorImageDisplayControl widget with the default settings and display the contents
     * of the image file pointed to by the URL.
     *
     * @param url The URL for the image to load
     */
    public NavigatorImageDisplayControl(URL url) {
        super(url);
    }


    /**
     * Make a NavigatorImageDisplayControl widget with the default settings and display the contents
     * of the image file.
     *
     * @param filename The image file to load
     */
    public NavigatorImageDisplayControl(String filename) {
        super(filename);
    }

    /** Make and return the image display window */
    protected DivaMainImageDisplay makeImageDisplay() {
        return new NavigatorImageDisplay();
    }
}

