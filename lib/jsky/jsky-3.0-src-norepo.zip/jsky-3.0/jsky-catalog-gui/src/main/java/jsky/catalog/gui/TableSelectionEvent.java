/*
 * $Id: TableSelectionEvent.java,v 1.3 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.catalog.gui;

import java.util.EventObject;

import jsky.catalog.TableQueryResult;


/**
 * This event is generated when a catalog table is seletced or deselected.
 *
 * @version $Revision: 1.3 $
 * @author Daniella Malin
 */
public class TableSelectionEvent extends EventObject {

    /** The catalog table data row corresponding to the table. */
    protected int row;

    /** The table containing the data */
    TableQueryResult table;

    /**
     * Create a TableSelectionEvent for the given row and table data.
     *
     * @param row the catalog table data row corresponding to the table
     * @param table the table containing the data
     */
    public TableSelectionEvent(int row, TableQueryResult table) {
        super(table);
        this.row = row;
        this.table = table;
    }


    /** Return the catalog table data row corresponding to the table. */
    public int getRow() {
        return row;
    }

    /** Return the table containing the data. */
    public TableQueryResult getTable() {
        return table;
    }
}
