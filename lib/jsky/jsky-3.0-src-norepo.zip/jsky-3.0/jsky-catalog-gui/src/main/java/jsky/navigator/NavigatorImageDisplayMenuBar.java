/*
 * $Id: NavigatorImageDisplayMenuBar.java,v 1.10 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.navigator;

import javax.swing.*;

import jsky.image.gui.ImageDisplayMenuBar;
import jsky.util.I18N;
import jsky.interop.SampHelper;
import jsky.interop.PlasticHelper;

/**
 * Extends the image display menubar by adding a catalog menu.
 *
 * @author Allan Brighton
 * @version $Revision: 1.10 $
 */
public class NavigatorImageDisplayMenuBar extends ImageDisplayMenuBar {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(NavigatorImageDisplayMenuBar.class);

    /**
     * Handle for the Image menu
     */
    private JMenu _catalogMenu;

    // Handle for the Interop menu
    private JMenu _interopMenu;


    /**
     * Create the menubar for the given main image display.
     *
     * @param imageDisplay the target image display
     * @param toolBar      the toolbar associated with this menubar (shares some actions)
     */
    public NavigatorImageDisplayMenuBar(NavigatorImageDisplay imageDisplay,
                                        NavigatorImageDisplayToolBar toolBar) {
        super(imageDisplay, toolBar);

        add(_catalogMenu = new NavigatorCatalogMenu(imageDisplay, true));

        // move the Pick Object menu item to the Catalog menu
        JMenuItem pickObjectMenuItem = getPickObjectMenuItem();
        getViewMenu().remove(pickObjectMenuItem);
        _catalogMenu.add(pickObjectMenuItem);

        // need to wait until SAMP is initialized, after GUI init
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _interopMenu = createInteropMenu();
                if (_interopMenu != null) {
                    add(_interopMenu);
                }
            }
        });

    }

    /**
     * Create the Interop menu.
     *
     * @return the new or updated menu
     */
    protected JMenu createInteropMenu() {
        SampHelper sh = SampHelper.getInstance();
        PlasticHelper ph = PlasticHelper.getInstance();
        if (sh == null && ph == null) {
            return null; // no interop services
        }

        JMenu menu = new JMenu(_I18N.getString("interop"));

        if (sh != null && ph != null) {
            JMenu sampMenu = new JMenu("SAMP");
            menu.add(sampMenu);
            sh.initImageMenu(sampMenu);

            JMenu plasticMenu = new JMenu("PLASTIC");
            menu.add(plasticMenu);
            ph.initImageMenu(plasticMenu);
        } else {
            if (sh != null) {
                sh.initImageMenu(menu);
            }
            if (ph != null) {
                ph.initImageMenu(menu);
            }
        }
        return menu;
    }

    public JMenu getCatalogMenu() {
        return _catalogMenu;
    }

    public JMenu getInteropMenu() {
        return _interopMenu;
    }
}
