/*
 * Created by JFormDesigner on Tue Feb 10 22:20:34 CET 2009
 */

package jsky.catalog.gui;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import com.jgoodies.forms.factories.*;
import com.jgoodies.forms.layout.*;

/**
 * @author Allan Brighton
 */
public class CatalogDirectoryChooserForm extends JDialog {
    public CatalogDirectoryChooserForm(Frame owner) {
        super(owner);
        initComponents();
    }

    public CatalogDirectoryChooserForm(Dialog owner) {
        super(owner);
        initComponents();
    }

    public JPanel getDialogPane() {
        return dialogPane;
    }

    public JPanel getContentPanel() {
        return contentPanel;
    }

    public JLabel getTitleLabel() {
        return titleLabel;
    }

    public JScrollPane getScrollPane() {
        return scrollPane;
    }

    public JTable getTable() {
        return table;
    }

    public JPanel getButtonBar() {
        return buttonBar;
    }

    public JButton getOkButton() {
        return okButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        ResourceBundle bundle = ResourceBundle.getBundle("jsky.catalog.gui.i18n.gui");
        dialogPane = new JPanel();
        contentPanel = new JPanel();
        titleLabel = new JLabel();
        scrollPane = new JScrollPane();
        table = new JTable();
        buttonBar = new JPanel();
        okButton = new JButton();
        cancelButton = new JButton();
        CellConstraints cc = new CellConstraints();

        //======== this ========
        setTitle(bundle.getString("this.title"));
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== dialogPane ========
        {
            dialogPane.setBorder(Borders.DIALOG_BORDER);
            dialogPane.setLayout(new BorderLayout());

            //======== contentPanel ========
            {
                contentPanel.setLayout(new FormLayout(
                    "default:grow",
                    "default, $lgap, default:grow"));

                //---- titleLabel ----
                titleLabel.setText(bundle.getString("title.text"));
                contentPanel.add(titleLabel, cc.xy(1, 1));

                //======== scrollPane ========
                {
                    scrollPane.setPreferredSize(new Dimension(760, 319));

                    //---- table ----
                    table.setModel(new DefaultTableModel(
                        new Object[][] {
                        },
                        new String[] {
                            "Use", "Display Name", "Registry URL"
                        }
                    ) {
                        Class[] columnTypes = new Class[] {
                            Boolean.class, String.class, String.class
                        };
                        boolean[] columnEditable = new boolean[] {
                            true, true, false
                        };
                        @Override
                        public Class<?> getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                        @Override
                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                            return columnEditable[columnIndex];
                        }
                    });
                    {
                        TableColumnModel cm = table.getColumnModel();
                        cm.getColumn(0).setResizable(false);
                        cm.getColumn(0).setMinWidth(35);
                        cm.getColumn(0).setMaxWidth(35);
                        cm.getColumn(0).setPreferredWidth(35);
                        cm.getColumn(1).setResizable(false);
                        cm.getColumn(1).setMinWidth(125);
                        cm.getColumn(1).setMaxWidth(125);
                        cm.getColumn(1).setPreferredWidth(125);
                    }
                    table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
                    scrollPane.setViewportView(table);
                }
                contentPanel.add(scrollPane, cc.xy(1, 3));
            }
            dialogPane.add(contentPanel, BorderLayout.CENTER);

            //======== buttonBar ========
            {
                buttonBar.setBorder(Borders.BUTTON_BAR_GAP_BORDER);
                buttonBar.setLayout(new FormLayout(
                    "$glue, $button, $rgap, $button",
                    "pref"));

                //---- okButton ----
                okButton.setText(bundle.getString("okButton.text"));
                buttonBar.add(okButton, cc.xy(2, 1));

                //---- cancelButton ----
                cancelButton.setText(bundle.getString("cancelButton.text"));
                buttonBar.add(cancelButton, cc.xy(4, 1));
            }
            dialogPane.add(buttonBar, BorderLayout.SOUTH);
        }
        contentPane.add(dialogPane, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel dialogPane;
    private JPanel contentPanel;
    private JLabel titleLabel;
    private JScrollPane scrollPane;
    private JTable table;
    private JPanel buttonBar;
    private JButton okButton;
    private JButton cancelButton;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
