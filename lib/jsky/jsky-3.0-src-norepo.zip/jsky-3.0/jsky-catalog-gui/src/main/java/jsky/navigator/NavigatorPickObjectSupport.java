package jsky.navigator;

import jsky.image.gui.PickObjectStatistics;
import jsky.catalog.TableQueryResult;
import jsky.catalog.FieldDesc;
import jsky.catalog.skycat.SkycatCatalog;
import jsky.catalog.skycat.SkycatTable;
import jsky.catalog.skycat.SkycatConfigFile;
import jsky.catalog.skycat.SkycatConfigEntry;
import jsky.catalog.gui.TableDisplayTool;
import jsky.catalog.gui.CatalogQueryTool;
import jsky.util.gui.SwingUtil;
import jsky.util.gui.DialogUtil;

import javax.swing.JComponent;
import javax.swing.JFrame;
import java.util.Properties;
import java.util.Vector;

/**
 * @author Allan Brighton
 * @since Feb 14, 2009
 */
public class NavigatorPickObjectSupport {

    // Reference to the catalog window
    private Navigator _navigator;

    /**
     * Initialize with a link to the catalog window
     * @param navigator the catalog window
     */
    public NavigatorPickObjectSupport(Navigator navigator) {
        _navigator = navigator;
    }

    /**
     * Add the object described by stats to the currently displayed table, or create a new table if none is being
     * displayed.
     *
     * @param stats    describes the selected object
     * @param isUpdate set to true if this is just an update of the previously selected position
     */
    public void addToTable(PickObjectStatistics stats, boolean isUpdate) {
        TableQueryResult table = null;
        TableDisplayTool tableDisplayTool = null;

        // see if a table is already being displayed, and if so, use it

        JComponent resultComponent = _navigator.getResultComponent();
        if (resultComponent instanceof TableDisplayTool) {
            tableDisplayTool = (TableDisplayTool) resultComponent;
            table = tableDisplayTool.getTableDisplay().getTableQueryResult();
        }

        if (table == null) {
            // no table being displayed: make a new table
            table = _makeTable(stats);

            // Make a dummy catalog for the table, so we have something to display in the top window
            SkycatCatalog cat = new SkycatCatalog((SkycatTable) table);
            _navigator.setQueryResult(cat);

            JComponent queryComponent = _navigator.getQueryComponent();
            if (queryComponent instanceof CatalogQueryTool) {
                // This is like pressing the Go button to show the contents of the table
                ((CatalogQueryTool) queryComponent).search();
            }
            JFrame parent = SwingUtil.getFrame(_navigator);
            if (parent != null) {
                parent.setVisible(true);
            }
        } else {
            // just add the row to the existing table
            _addRow(table, tableDisplayTool, stats, isUpdate);
        }
    }


    /**
     * Make a catalog table to use to hold the objects picked by the user and add the first row based on
     * the given stats object.
     * @param stats statistics of a selected position
     * @return the new table with one row added
     */
    private TableQueryResult _makeTable(PickObjectStatistics stats) {
        Properties properties = new Properties();
        properties.setProperty(SkycatConfigFile.SERV_TYPE, "local");
        properties.setProperty(SkycatConfigFile.LONG_NAME, "Picked Objects");
        properties.setProperty(SkycatConfigFile.SHORT_NAME, "PickedObjects");
        properties.setProperty(SkycatConfigFile.SYMBOL,
                "{{FWHM_X} {FWHM_Y} {Angle}} "
                        + "{{plus} {green} {$FWHM_X/$FWHM_Y} {$Angle} {} {1}} "
                        + "{{($FWHM_X+$FWHM_Y)*0.5} {image}}");
        properties.setProperty(SkycatConfigFile.URL, "none");
        SkycatConfigEntry configEntry = new SkycatConfigEntry(properties);
        FieldDesc[] fields = PickObjectStatistics.getFields();

        Vector<Vector<Object>> dataRows = new Vector<Vector<Object>>();
        dataRows.add(stats.getRow());
        SkycatTable table = new SkycatTable(configEntry, dataRows, fields);
        table.setProperties(properties);
        return table;
    }


    /**
     * Add a row to the given table with information from the given stats object.
     * The target table may or may not be compatible, so column names and types are checked.
     * @param table the target table
     * @param tableDisplayTool the component displaying the table
     * @param stats the statistics to be displayed in the row
     * @param isUpdate if true, update the last row instead of adding a new row
     */
    private void _addRow(TableQueryResult table, TableDisplayTool tableDisplayTool,
                                         PickObjectStatistics stats, boolean isUpdate) {
        if (!table.hasCoordinates()) {
            DialogUtil.error("The current table does not support coordinates");
            return;
        }

        int numCols = table.getColumnCount();
        Vector<Object> v = stats.getRow();
        Vector<Object> rowVec = new Vector<Object>(numCols);

        for (int col = 0; col < numCols; col++) {
            FieldDesc field = table.getColumnDesc(col);
            String name = field.getName();
            if (field.isId()) {
                rowVec.add(v.get(PickObjectStatistics.ID));
            } else if (field.isRaMain()) {
                rowVec.add(stats.getCenterPos().getRA().toString());
            } else if (field.isDecMain()) {
                rowVec.add(stats.getCenterPos().getDec().toString());
            } else {
                Object o = null;
                for (int i = 0; i < PickObjectStatistics.NUM_FIELDS; i++) {
                    if (name.equals(PickObjectStatistics.FIELD_NAMES[i])) {
                        o = v.get(i);
                        break;
                    }
                }
                rowVec.add(o);
            }
        }
        if (isUpdate) {
            // if the last row added is for the same point, update it
            int rowIndex = tableDisplayTool.getRowCount() - 1;
            if (rowIndex >= 0) {
                tableDisplayTool.updateRow(rowIndex, rowVec);
            } else {
                tableDisplayTool.addRow(rowVec);
            }
        } else {
            tableDisplayTool.addRow(rowVec);
        }
        tableDisplayTool.replot();
    }
}
