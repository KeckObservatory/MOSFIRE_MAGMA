// Copyright 2001 Association for Universities for Research in Astronomy, Inc.,
// Observatory Control System, Gemini Telescopes Project.
//
// $Id: TableColumnConfigPanel.java,v 1.7 2009/04/21 13:31:17 abrighto Exp $
//

package jsky.catalog.gui;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import jsky.util.I18N;
import jsky.util.gui.TableUtil;
import jsky.util.gui.JTextAreaCellRenderer;
import jsky.util.gui.JTextAreaCellEditor;
import jsky.catalog.TableQueryResult;


/**
 * A panel for choosing which table columns to display.
 */
public class TableColumnConfigPanel extends JPanel {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(TableColumnConfigPanel.class);

    // Index of the "Show?" column
    private static final int SHOW_COL = 0;

    // Index of the "Description" column
    private static final int DESCRIPTION_COL = 3;

    // The widget displaying the table
    private TableDisplay _tableDisplay;

    // The table displaying the available table columns
    private JTable _table;

    // Column names for _table
    private Vector<String> _columnNames;


    /**
     * Constructor.
     *
     * @param tableDisplay the widget displaying the table
     */
    public TableColumnConfigPanel(TableDisplay tableDisplay) {
        _tableDisplay = tableDisplay;

        _table = new JTable();

        _table.setRowSelectionAllowed(true);
        _table.setColumnSelectionAllowed(false);
        _table.setRowHeight(20);
        _table.setGridColor(Color.gray);
        _table.setShowGrid(true);
        _table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        JTableHeader header = _table.getTableHeader();
        header.setUpdateTableInRealTime(false);
        header.setFont(header.getFont().deriveFont(Font.BOLD));

        _columnNames = new Vector<String>(4);
        _columnNames.add(_I18N.getString("showQM"));
        _columnNames.add(_I18N.getString("colName"));
        _columnNames.add("UCD");
        _columnNames.add(_I18N.getString("description"));

        setModel(_tableDisplay.getTableQueryResult());

        setLayout(new BorderLayout());
        JScrollPane scrollPane = new JScrollPane(_table,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(scrollPane, BorderLayout.CENTER);
    }


    /**
     * Set the table model to use for the table displaying the column names and checkboxes.
     * @param model used to get the column names that make up this table model
     */
    public void setModel(TableQueryResult model) {
        String[] columnIdentifiers = _getColumnIdentifiers(model);
        boolean[] show = _tableDisplay.getShow();
        Vector<Vector<Object>> data = new Vector<Vector<Object>>(columnIdentifiers.length);

        if (show != null && show.length != columnIdentifiers.length) {
            show = null; // table columns might have changed since last session
        }

        for (int i = 0; i < columnIdentifiers.length; i++) {
            Vector<Object> row = new Vector<Object>(4);
            row.add(show != null ? show[i] : Boolean.TRUE);
            row.add(columnIdentifiers[i]);
            row.add(model.getColumnDesc(i).getUCD());
            row.add(model.getColumnDesc(i).getDescription());
            data.add(row);
        }

        _table.setModel(new DefaultTableModel(data, _columnNames) {

            public Class getColumnClass(int columnIndex) {
                if (columnIndex == SHOW_COL) {
                    return Boolean.class;
                }
                return String.class;
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
//                return (columnIndex == SHOW_COL);
                return true;
            }
        });

        // The descriptions can be very wide, so allow multiple lines in the table
        TableColumn col = _table.getColumnModel().getColumn(DESCRIPTION_COL);
        col.setCellRenderer(new JTextAreaCellRenderer());
        col.setCellEditor(new JTextAreaCellEditor(_table));
        col.setPreferredWidth(500);
        col.setMinWidth(500);

        TableUtil.initColumnSizes(_table, show);
    }


    /**
     * Return an array of column names
     * @param model target table model
     * @return array of column names in model
     */
    private String[] _getColumnIdentifiers(TableQueryResult model) {
        String[] ar = new String[model.getColumnCount()];
        for (int i = 0; i < ar.length; i++) {
            ar[i] = model.getColumnName(i);
        }
        return ar;
    }

    /**
     * Apply any changes
     */
    public void apply() {
        DefaultTableModel model = (DefaultTableModel) _table.getModel();
        Vector data = model.getDataVector();
        int numCols = data.size();
        boolean[] show = new boolean[numCols];
        for (int i = 0; i < numCols; i++) {
            Vector row = (Vector) data.get(i);
            show[i] = (Boolean) row.get(SHOW_COL);
        }
        _tableDisplay.setShow(show);
        _tableDisplay.reorderColumns();
    }


    /**
     * Cancel any changes
     */
    public void cancel() {
        setModel(_tableDisplay.getTableQueryResult());
    }
}

