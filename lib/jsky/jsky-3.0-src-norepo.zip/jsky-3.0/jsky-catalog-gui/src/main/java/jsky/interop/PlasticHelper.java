package jsky.interop;

import jsky.navigator.NavigatorImageDisplayFrame;
import jsky.navigator.Navigator;
import jsky.catalog.vo.VoCatalog;
import jsky.catalog.vo.VoTable;
import jsky.catalog.gui.TableDisplayTool;
import jsky.image.gui.MainImageDisplay;
import jsky.image.gui.DivaMainImageDisplay;
import jsky.image.ImageChangeEvent;
import jsky.util.Resources;
import jsky.util.gui.BasicAction;
import jsky.util.gui.SwingUtil;

import java.net.URI;
import java.net.URL;
import java.util.List;
import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.logging.Logger;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.awt.Component;
import java.awt.event.ActionEvent;

import uk.ac.starlink.plastic.MessageId;
import uk.ac.starlink.plastic.HubManager;
import uk.ac.starlink.plastic.PlasticTransmitter;
import uk.ac.starlink.plastic.ApplicationItem;
import uk.ac.starlink.plastic.PlasticListWindow;
import uk.ac.starlink.util.DataSource;
import uk.ac.starlink.util.URLUtils;
import uk.ac.starlink.votable.VOTableWriter;
import uk.ac.starlink.votable.DataFormat;
import uk.ac.starlink.table.StarTable;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFrame;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import org.votech.plastic.PlasticHubListener;
import org.astrogrid.samp.Metadata;

/**
 * Manages access to the Plastic features for interprocess communication.
 * <p>
 * See <a href="http://eurovotech.org/twiki/bin/view/VOTech/PlasticMessagesProposal">here</a>
 * for a description of the PLASTIC messages and arguments.
 *
 * @author Allan Brighton (based on code found in TopCat)
 * @since Mar 2, 2009
 */
public class PlasticHelper extends HubManager {

    private static final Logger LOG = Logger.getLogger(PlasticHelper.class.getName());

    // URIs of supported plastic messages
    private static final URI[] SUPPORTED_MESSAGES = new URI[]{
            MessageId.VOT_LOAD,
            MessageId.VOT_LOADURL,
            MessageId.VOT_SHOWOBJECTS,
            MessageId.VOT_HIGHLIGHTOBJECT,
            MessageId.INFO_GETDESCRIPTION,
            MessageId.INFO_GETICONURL,
            MessageId.FITS_LOADIMAGE,
            MessageId.SKY_POINT,
    };

    // Singleton instance of this class
    private static PlasticHelper _instance;

    // the main image display frame
    private NavigatorImageDisplayFrame _imageFrame;

    // Application metadata
    private Metadata _meta;

    /**
     * This method should be called once at the start of the application to initialize Plastic with the application name,
     * icon and other relevant information
     *
     * @param meta the application metadata
     * @param imageFrame the main image display frame
     */
    public static void init(Metadata meta, NavigatorImageDisplayFrame imageFrame) {
        if (_instance == null) {
            _instance = new PlasticHelper(meta, imageFrame);
        }
    }

    /**
     * Before calling this method, the static init method needs to be called once.
     *
     * @return the singleton instance of this class
     */
    public static PlasticHelper getInstance() {
        return _instance;
    }

    /**
     * Initialize the Plastic connection support
     *
     * @param meta the application metadata
     * @param imageFrame the main image frame
     */
    public PlasticHelper(Metadata meta, NavigatorImageDisplayFrame imageFrame) {
        super(meta.getName(), SUPPORTED_MESSAGES);
        _imageFrame = imageFrame;
        _meta = meta;
        setActive();
    }

    /**
     * Register with the Plastic hub and return true on success
     *
     * @return true on success
     */
    public boolean setActive() {
        boolean isReg;
        try {
            register();
            isReg = true;
        }
        catch (IOException e) {
            LOG.warning(e.getMessage());
            isReg = false;
        }
        setAutoRegister(5000);
        return isReg;
    }

    @Override
    /**
     * Does the work for processing a hub message.
     *
     * @param  sender   sender ID
     * @param  message  message ID (determines the action required)
     * @param  args     message argument list
     * @return return value requested by message
     */
    public Object doPerform(URI sender, URI message, List args)
            throws IOException {

        /* Load VOTable passed as text in an argument. */
        if (MessageId.VOT_LOAD.equals(message) && checkArgs(args, new Class[]{String.class})) {
            String text = (String) args.get(0);
            String id = args.size() > 1 ? String.valueOf(args.get(1))
                    : null;
            votableLoad(sender, text, id);
            return Boolean.TRUE;
        }

        /* Load VOTable by URL. */
        else if (MessageId.VOT_LOADURL.equals(message) &&
                checkArgs(args, new Class[]{Object.class})) {
            String url = args.get(0) instanceof String
                    ? (String) args.get(0)
                    : args.get(0).toString();
            String id = url;
            if (args.size() > 1) {
                id = args.get(1) instanceof String
                        ? (String) args.get(1)
                        : args.get(0).toString();
            }
            votableLoadFromURL(sender, url, id);
            return Boolean.TRUE;
        }

        /* Select VOTable rows. */
        else if (MessageId.VOT_SHOWOBJECTS.equals(message) &&
                args.size() >= 2 &&
                args.get(1) instanceof List) {
            String tableId = args.get(0).toString();
            List rowList = (List) args.get(1);
            Navigator navigator = _imageFrame.getNavigator();
            if (navigator != null) {
                int[] rows = new int[rowList.size()];
                for (int i = 0; i < rows.length; i++) {
                    // should actually be a number
                    rows[i] = Integer.parseInt(rowList.get(i).toString());
                }
                navigator.selectTableRows(tableId, null, rows);
            }
            return Boolean.TRUE;
        }

        /* Highlight a single row. */
        else if (MessageId.VOT_HIGHLIGHTOBJECT.equals(message) &&
                args.size() >= 2 &&
                args.get(1) instanceof Number) {
            String tableId = args.get(0).toString();
            int irow = ((Number) args.get(1)).intValue();
            Navigator navigator = _imageFrame.getNavigator();
            if (navigator != null) {
                navigator.selectTableRows(tableId, null, new int[]{irow});
            }
            return Boolean.TRUE;
        }

        /* Get the icon for this application. */
        else if (MessageId.INFO_GETICONURL.equals(message)) {
            return _meta.getIconUrl();
        }

        /* Load an image by URL. */
        else if (MessageId.FITS_LOADIMAGE.equals(message) &&
                checkArgs(args, new Class[]{Object.class})) {
            String url = args.get(0) instanceof String
                    ? (String) args.get(0)
                    : args.get(0).toString();
            String id = url;
            if (args.size() > 1) {
                id = args.get(1) instanceof String
                        ? (String) args.get(1)
                        : args.get(0).toString();
            }
            fitsLoadImage(sender, url, id);
            return Boolean.TRUE;
        }

        /* Load an image by URL. */
        else if (MessageId.SKY_POINT.equals(message) &&
                checkArgs(args, new Class[]{Object.class})) {
            if (args.size() >= 2) {
                double ra = Double.parseDouble(args.get(0).toString());
                double dec = Double.parseDouble(args.get(1).toString());
                skyPoint(ra, dec);
            }
            return Boolean.TRUE;
        }

        /* Unknown message. */
        else {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * Does the work for the load-from-string VOTable message.
     *
     * @param sender sender ID
     * @param votText VOTable text contained in a string, assumed UTF-8
     * encoded
     * @param id identifies the sent VOTable for later use
     * @throws java.io.IOException on error
     */
    private void votableLoad(URI sender, String votText, String id)
            throws IOException {
        Navigator navigator = _imageFrame.getNavigator();
        if (navigator != null) {
            final byte[] votBytes = votText.getBytes("UTF-8");
            DataSource datsrc = new DataSource() {
                public InputStream getRawInputStream() {
                    return new ByteArrayInputStream(votBytes);
                }
            };
            String name = sender.toString() + "-" + id;
            VoCatalog catalog = new VoCatalog(VoTable.createVoTable(datsrc, id, name));
            navigator.setQueryResult(catalog);
            navigator.registerTable(null, id);
        }
    }

    /**
     * Does the work for the load-from-URL VOTable load message.
     *
     * @param sender sender ID
     * @param urlStr location of table
     * @param id identifier for loaded table
     * @throws java.io.IOException on error
     */
    private void votableLoadFromURL(URI sender, String urlStr, String id)
            throws IOException {
        Navigator navigator = _imageFrame.getNavigator();
        if (navigator != null) {
            String name = sender.toString() + "-" + id;
            URL url = new URL(urlStr);
            VoCatalog catalog = new VoCatalog(VoTable.createVoTable(url, id, name));
            navigator.setQueryResult(catalog);
            navigator.registerTable(url, id);
        }
    }

    /**
     * Does the work for the fits load image message.
     *
     * @param sender sender ID
     * @param urlStr location of table
     * @param id identifier for loaded table
     * @throws java.io.IOException on error
     */
    @SuppressWarnings({"UnusedDeclaration"})
    private void fitsLoadImage(URI sender, String urlStr, String id)
            throws IOException {
        DivaMainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        imageDisplay.setURL(new URL(urlStr));
    }

    /**
     * Directs attention (e.g. by moving a cursor or shifting the field of view) to a given
     * point on the celestial sphere.
     *
     * @param ra right ascension in degrees
     * @param dec declination in degrees
     */
    protected void skyPoint(double ra, double dec) {
        DivaMainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        imageDisplay.loadCachedImage(ra, dec);
    }

    /**
     * Fills the given menu with the image related or general actions implemented in this class.
     *
     * @param menu the menu (JMenu or JPopupMenu) to add items to
     */
    public void initImageMenu(JMenu menu) {
        _initImageMenu(menu, null);
    }

    /**
     * Fills the given menu with the image related implemented in this class.
     *
     * @param menu the menu (JMenu or JPopupMenu) to add items to
     * @param url the URL of the image to send
     */
    public void initImageMenu(JPopupMenu menu, URL url) {
        _initImageMenu(menu, url);
    }

    /**
     * Fills the given menu with the image related or general actions implemented in this class.
     *
     * @param menu the menu (JMenu or JPopupMenu) to add items to
     * @param url the URL of the image to send
     */
    private void _initImageMenu(JComponent menu, final URL url) {
        final MainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        if (menu instanceof JMenu) {
            // only include these in the main menu
            JMenu jMenu = (JMenu) menu;
            jMenu.add(getRegisterAction(true));
            jMenu.add(getRegisterAction(false));
            jMenu.add(new HubWatchAction(_imageFrame, this));
            jMenu.add(getHubStartAction(true));
            jMenu.add(getHubStartAction(false));
            jMenu.addSeparator();
        }

        final PlasticTransmitter trans = new PlasticTransmitter(this, MessageId.FITS_LOADIMAGE, "image") {
            @Override
            protected void transmit(PlasticHubListener hub, URI clientId, ApplicationItem app) throws IOException {
                URI[] recipients = app == null
                        ? null
                        : new URI[]{app.getId()};
                transmitImage(hub, clientId, recipients, url);
            }
        };

        JMenu sendMenu = trans.createSendMenu();
        sendMenu.setIcon(Resources.getIcon("phone2.gif"));
        menu.add(sendMenu);

        final JMenuItem broadCastItem = new JMenuItem("Broadcast Image");
        broadCastItem.setIcon(Resources.getIcon("broadcast.gif"));
        broadCastItem.addActionListener(trans.getBroadcastAction());
        menu.add(broadCastItem);

        if (url == null) {
            broadCastItem.setEnabled(false);
            trans.setEnabled(false);
            imageDisplay.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent changeEvent) {
                    ImageChangeEvent e = (ImageChangeEvent) changeEvent;
                    if (e.isNewImage() && !e.isBefore()) {
                        boolean enabled = (imageDisplay.getURL() != null || imageDisplay.getFilename() != null);
                        trans.setEnabled(enabled);
                        broadCastItem.setEnabled(enabled);
                    }
                }
            });
        } else {
            trans.setEnabled(true);
        }
    }

    /**
     * Action which displays a window giving some information about
     * the state of the PLASTIC hub.
     */
    private static class HubWatchAction extends BasicAction {
        private final Component parent_;
        private final HubManager hubManager_;
        private JFrame hubWindow_;

        /**
         * Constructor.
         *
         * @param parent parent window
         * @param hubManager connection manager
         */
        HubWatchAction(Component parent, HubManager hubManager) {
            super("Show Registered Applications", null,
                    "Display applications registered with the PLASTIC hub");
            parent_ = parent;
            hubManager_ = hubManager;
        }

        public void actionPerformed(ActionEvent evt) {
            if (hubWindow_ == null) {
                hubWindow_ = new PlasticListWindow(hubManager_
                        .getApplicationListModel());
                hubWindow_.setTitle("PLASTIC apps");
                SwingUtil.positionAfter(parent_, hubWindow_);
                hubWindow_.pack();
            }
            hubWindow_.setVisible(true);
        }
    }

    /**
     * Fills the given menu with the table related or general actions implemented in this class.
     *
     * @param menu the menu to add items to
     */
    public void initTableMenu(JMenu menu) {
        _initTableMenu(menu, null, null, new HashMap());
    }

    /**
     * Fills the given menu with the table related or general actions implemented in this class.
     *
     * @param menu the menu to add items to
     * @param url the URL of the table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     */
    public void initTableMenu(JPopupMenu menu, URL url, String format, Map ucdMap) {
        _initTableMenu(menu, url, format, ucdMap);
    }

    /**
     * Fills the given menu with the table related or general actions implemented in this class.
     *
     * @param menu the menu to add items to
     * @param url the URL of the table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     */
    public void initTableMenu(JMenu menu, URL url, String format, Map ucdMap) {
        _initTableMenu(menu, url, format, ucdMap);
    }

    /**
     * Fills the given menu with the table or spectrum related or general
     * actions implemented in this class.
     *
     * @param menu the menu (JMenu or JPopupMenu) to add items to
     * @param url the URL of the table or spectrum, or null to use the displayed table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     */
    private void _initTableMenu(JComponent menu, final URL url, final String format, final Map ucdMap) {
        final Navigator navigator = _imageFrame.getNavigator();
        if (menu instanceof JMenu) {
            // only include these in the main menu
            JMenu jMenu = (JMenu) menu;
            jMenu.add(getRegisterAction(true));
            jMenu.add(getRegisterAction(false));
            jMenu.add(new HubWatchAction(_imageFrame, this));
            jMenu.add(getHubStartAction(true));
            jMenu.add(getHubStartAction(false));
            jMenu.addSeparator();
        }

        boolean isSpectrum = format != null && format.startsWith("spectrum/");
        final PlasticTransmitter trans = new PlasticTransmitter(this,
                isSpectrum ? MessageId.SPECTRUM_LOADURL : MessageId.VOT_LOADURL,
                isSpectrum ? "spectrum" : "table") {
            @Override
            protected void transmit(PlasticHubListener hub, URI clientId, ApplicationItem app) throws IOException {
                URI[] recipients = (app == null) ? null : new URI[]{app.getId()};
                transmitTable(hub, clientId, recipients, url, format, ucdMap);
            }
        };

        JMenu sendMenu = trans.createSendMenu();
        sendMenu.setIcon(Resources.getIcon("phone2.gif"));
        menu.add(sendMenu);

        final JMenuItem broadCastItem = new JMenuItem(isSpectrum ? "Broadcast Spectrum" : "Broadcast Table");
        broadCastItem.setIcon(Resources.getIcon("broadcast.gif"));
        broadCastItem.addActionListener(trans.getBroadcastAction());
        menu.add(broadCastItem);

        if (url == null) {
            broadCastItem.setEnabled(false);
            trans.setEnabled(false);
            navigator.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent changeEvent) {
                    boolean enabled = navigator.getResultComponent() instanceof TableDisplayTool;
                    trans.setEnabled(enabled);
                    broadCastItem.setEnabled(enabled);
                }
            });
        } else {
            trans.setEnabled(true);
        }
    }


    /**
     * Sends a table to a specific list of PLASTIC listeners.
     *
     * @param hub hub object
     * @param plasticId registration ID for this application
     * @param recipients listeners to receive it; null means do a broadcast
     * @param url the url of the table, or null to use the displayed table
     * @param format the expected format/mime type
     * @param ucdMap maps UCD to column value for the current table row (may be empty)
     * @throws java.io.IOException on error
     */
    private void transmitTable(final PlasticHubListener hub,
                               final URI plasticId, final URI[] recipients,
                               URL url, final String format, final Map ucdMap) throws IOException {

        // Write the data as a VOTable to a temporary file preparatory to broadcast.
        final Navigator navigator = _imageFrame.getNavigator();
        final String urlStr;
        final String name;
        final File tmpfile;
        if (url == null) {
            tmpfile = File.createTempFile("plastic", ".vot");
            urlStr = URLUtils.makeFileURL(tmpfile).toString();
            tmpfile.deleteOnExit();
            OutputStream ostrm = new BufferedOutputStream(new FileOutputStream(tmpfile));
            final StarTable starTable = navigator.getStarTable();
            name = starTable.getName();
            try {
                new VOTableWriter(DataFormat.TABLEDATA, true).writeStarTable(starTable, ostrm);
            }
            catch (IOException e) {
                //noinspection ResultOfMethodCallIgnored
                tmpfile.delete();
                throw e;
            }
            finally {
                ostrm.close();
            }
        } else {
            urlStr = url.toString();
            name = plasticId.toString();
            tmpfile = null;
        }

        // Store a record of the table that was broadcast
        navigator.registerTable(new URL(urlStr), name);

        // Do the broadcast, synchronously so that we don't delete the
        // temporary file too early, but in another thread so that we
        // don't block the GUI.
        new Thread("PLASTIC table broadcast") {
            public void run() {
                URI msgId;
                List argList;
                if (format != null && format.startsWith("spectrum/")) {
                    msgId = MessageId.SPECTRUM_LOADURL;
                    argList = Arrays.asList(urlStr, urlStr, ucdMap);
                } else {
                    msgId = MessageId.VOT_LOADURL;
                    argList = Arrays.asList(urlStr, urlStr);
                }
                LOG.info("PLASTIC Send: " + msgId + ": " + urlStr);
                @SuppressWarnings({"UnusedDeclaration"})
                Map responses = (recipients == null)
                        ? hub.request(plasticId, msgId, argList)
                        : hub.requestToSubset(plasticId, msgId, argList, Arrays.asList(recipients));

                /* Delete the temp file. */
                if (tmpfile != null) {
                    //noinspection ResultOfMethodCallIgnored
                    tmpfile.delete();
                }
            }
        }.start();
    }

    /**
     * Sends an image to a specific list of PLASTIC listeners.
     *
     * @param hub hub object
     * @param plasticId registration ID for this application
     * @param recipients listeners to receive it; null means do a broadcast
     * @param url the URL of the image to send, or null to send the displayed image
     * @throws java.io.IOException on error
     */
    private void transmitImage(final PlasticHubListener hub,
                               final URI plasticId, final URI[] recipients,
                               URL url)
            throws IOException {

        final MainImageDisplay imageDisplay = _imageFrame.getImageDisplayControl().getImageDisplay();
        URL imageUrl = url;
        if (imageUrl == null) {
            String fileName = imageDisplay.getFilename();
            imageUrl = imageDisplay.getURL();
            if (fileName != null) {
                imageUrl = new File(fileName).toURI().toURL();
            }
        }
        if (imageUrl == null) {
            return;
        }

        // Do the broadcast, synchronously, but in another thread so that we
        // don't block the GUI.
        final String urlStr = imageUrl.toString();
        new Thread("FITS broadcast") {
            public void run() {
                List argList = Arrays.asList(urlStr, urlStr);
                URI msgId = MessageId.FITS_LOADIMAGE;
                LOG.info("PLASTIC Send: " + msgId + ": " + urlStr);
                @SuppressWarnings({"UnusedDeclaration"})
                Map responses = recipients == null
                        ? hub.request(plasticId, msgId, argList)
                        : hub.requestToSubset(plasticId, msgId, argList,
                        Arrays.asList(recipients));
            }
        }.start();
    }
}
