/*
 * ESO Archive
 *
 * $Id: CatalogTreeCellRenderer.java,v 1.2 2009/03/19 17:38:08 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  2000/01/27  Created
 */

package jsky.catalog.gui;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

import jsky.catalog.Catalog;
import jsky.util.Resources;

/**
 * This local class is used to override the default tree node
 * renderer and provide special catalog dependent icons.
 */
public class CatalogTreeCellRenderer extends DefaultTreeCellRenderer {

    public static final Icon IMAGE_SERVER_ICON = Resources.getIcon("WebComponentAdd16.gif");
    public static final Icon CATALOG_ICON = Resources.getIcon("File16.gif");
    public static final Icon ARCHIVE_ICON = Resources.getIcon("New16.gif");
    public static final Icon NAME_SERVER_ICON = Resources.getIcon("About16.gif");
    public static final Icon BUSY_ICON = Resources.getIcon("phone2.gif");

    public Component getTreeCellRendererComponent(JTree tree,
                                                  Object value,
                                                  boolean sel,
                                                  boolean expanded,
                                                  boolean leaf,
                                                  int row,
                                                  boolean hasFocus) {

        super.getTreeCellRendererComponent(tree, value, sel,
                expanded, leaf, row, hasFocus);

        setBackgroundNonSelectionColor(tree.getBackground());

        if (value instanceof DefaultMutableTreeNode) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
            Object o = node.getUserObject();
            if (o instanceof Catalog) {
                Catalog catalog = (Catalog) o;
                setToolTipText(catalog.getDescription());
                String servType = catalog.getType();
                if (servType.equals("directory")) {
                    setIcon(getOpenIcon());
                }
                if (servType.equals("catalog")) {
                    setIcon(CATALOG_ICON);
                }
                if (servType.equals("archive")) {
                    setIcon(ARCHIVE_ICON);
                }
                if (servType.equals("namesvr")) {
                    setIcon(NAME_SERVER_ICON);
                }
                if (servType.equals("imagesvr")) {
                    setIcon(IMAGE_SERVER_ICON);
                }
                setToolTipText(getText());
            } else if (o instanceof String) {
                setIcon(BUSY_ICON); // message before catalog directory is read
            }
        }

        return this;
    }
}

