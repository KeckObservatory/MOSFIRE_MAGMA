package jsky.interop;

import org.astrogrid.samp.gui.IndividualCallActionManager;
import org.astrogrid.samp.gui.GuiHubConnector;
import org.astrogrid.samp.gui.SubscribedClientListModel;
import org.astrogrid.samp.Client;
import org.astrogrid.samp.Message;
import org.astrogrid.samp.Subscriptions;

import javax.swing.JMenu;
import java.util.Map;
import java.io.File;
import java.net.URL;
import java.awt.*;

import jsky.util.Resources;
import jsky.image.gui.MainImageDisplay;


/**
 * SendActionManager which will transmit a FITS image.
 *
 * @author Allan Brighton
 */
public class ImageSendActionManager
        extends IndividualCallActionManager {

    /**
     * Supported image send formats.
     */
    private static final Sender[] SENDERS = new Sender[]{
            new Sender("image.load.fits"),
    };

    // Reference to image display window
    private MainImageDisplay _imageDisplay;

    // The URL of the image, if known (otherwise the displayed image is used)
    private URL _url;

    // Used to generate unique id
    private int idCount_;


    /**
     * Constructor.
     *
     * @param parent parent component
     * @param connector hub connector
     */
    public ImageSendActionManager(MainImageDisplay parent, GuiHubConnector connector) {
        this(parent, connector, null);
    }

    /**
     * Constructor.
     *
     * @param parent parent component
     * @param connector hub connector
     * @param url the URL of the image
     */
    public ImageSendActionManager(MainImageDisplay parent, GuiHubConnector connector, URL url) {
        super((Component) parent, connector, new SubscribedClientListModel(connector, getSendMtypes()));
        _imageDisplay = parent;
        _url = url;
    }

    /**
     * Returns the Message object which is to be transmitted by this manager
     * to a given client.  This is called by the action returned by
     * {@link #getSendAction}.
     *
     * @param client target
     * @return message
     */
    @Override
    protected Map createMessage(Client client) throws Exception {
        Sender sender = getSender(client);
        if (sender != null) {
            URL url = _url;
            if (url == null) {
                String fileName = _imageDisplay.getFilename();
                url = _imageDisplay.getURL();
                if (fileName != null) {
                    url = new File(fileName).toURI().toURL();
                }
            }
            String label = createId();
            return sender.createMessage(url, label);
        }
        return null;
    }

    /**
     * Returns a unique ID each time it is called.
     *
     * @return opaque ID string
     */
    private synchronized String createId() {
        return "jsky"
                + Integer.toString(System.identityHashCode(this) & 0xffff, 16)
                + "-"
                + ++idCount_;
    }

    /**
     * Returns a Sender object which can send a image to a given client.
     *
     * @param client target client
     * @return sender
     */
    private static Sender getSender(Client client) {
        Subscriptions subs = client.getSubscriptions();
        for (Sender sender : SENDERS) {
            if (subs.isSubscribed(sender.getMtype())) {
                return sender;
            }
        }
        return null;
    }


    public JMenu createSendMenu() {
        JMenu menu = super.createSendMenu("Send Image to...");
        menu.setToolTipText("Send image to a single other registered client using SAMP");
        menu.setIcon(Resources.getIcon("phone2.gif"));
        return menu;
    }

    /**
     * Returns the array of MTypes which this sender can use to send images.
     *
     * @return mtype list
     */
    private static String[] getSendMtypes() {
        String[] mtypes = new String[SENDERS.length];
        for (int i = 0; i < SENDERS.length; i++) {
            mtypes[i] = SENDERS[i].getMtype();
        }
        return mtypes;
    }

    /**
     * Encapsulates format-specific details of how a image is sent over SAMP.
     */
    private static class Sender {
        private final String mtype_;

        /**
         * Constructor.
         *
         * @param mtype MType of image send message
         */
        Sender(String mtype) {
            mtype_ = mtype;
        }

        /**
         * Returns the MType used by this sender.
         *
         * @return MType
         */
        public String getMtype() {
            return mtype_;
        }

        /**
         * Returns a message suitable for sending an image.
         *
         * @param url URL of the image to send
         * @param sampId image ID, unique to relevant parts of image state
         * @return send message
         */
        public Message createMessage(URL url, String sampId) {
            return new Message(getMtype())
                    .addParam("url", url.toString())
                    .addParam("image-id", sampId);
        }

        public String toString() {
            return mtype_;
        }
    }
}
