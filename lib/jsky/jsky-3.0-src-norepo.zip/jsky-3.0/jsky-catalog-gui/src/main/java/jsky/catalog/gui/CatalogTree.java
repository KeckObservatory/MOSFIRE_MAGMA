/*
 * Copyright 2002 Association for Universities for Research in Astronomy, Inc.,
 * Observatory Control System, Gemini Telescopes Project.
 *
 * $Id: CatalogTree.java,v 1.4 2009/03/25 15:01:44 abrighto Exp $
 */

package jsky.catalog.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Set;
import java.util.HashSet;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

import jsky.catalog.BasicQueryArgs;
import jsky.catalog.Catalog;
import jsky.catalog.CatalogDirectory;
import jsky.catalog.HTMLQueryResultHandler;
import jsky.catalog.QueryResult;
import jsky.catalog.QueryResultHandler;
import jsky.catalog.URLQueryResult;
import jsky.util.I18N;
import jsky.util.SwingWorker;
import jsky.util.Resources;
import jsky.util.gui.*;


/**
 * Used to display a catalog hierarchy.
 */
@SuppressWarnings("serial")
public class CatalogTree extends JPanel
        implements QueryResultDisplay, QueryResultHandler, TreeModelListener {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(CatalogTree.class);

    // The tree widget
    private JTree _tree;

    // Set to true if tree node selections should be ignored
    private boolean _ignoreSelection = false;

    // Optional handler, used to report HTML format results (errors) from HTTP servers
    private HTMLQueryResultHandler _htmlQueryResultHandler;

    // Reference to object used to display leaf items, such as tables, etc.
    private QueryResultDisplay _queryResultDisplay;

    // Reference to the top level catalog directory object passed to the constructor
    private CatalogDirectory _rootCatDir;

    // Utility object used to control background thread
    private CatalogLoader _loader;

    // Panel used to display status information
    private ProgressPanel _progressPanel;

    // Popup menu for tree nodes
    private JPopupMenu _nodeMenu;

    // Action to use for the "Cut" menu and toolbar items
    private AbstractAction _cutAction = new AbstractAction(
            _I18N.getString("cut"),
            Resources.getIcon("Cut24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("cutTip"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                _cut();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Copy" menu and toolbar items
    private AbstractAction _copyAction = new AbstractAction(
            _I18N.getString("copy"),
            Resources.getIcon("Copy24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("copyTip"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                _copy();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Paste" menu and toolbar items
    private AbstractAction _pasteAction = new AbstractAction(
            _I18N.getString("paste"),
            Resources.getIcon("Paste24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("pasteTip"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                _paste();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Add to Favorites" menu and toolbar items
    private AbstractAction _addToFavoritesAction = new AbstractAction(
            _I18N.getString("addToFavorites")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("addToFavoritesTip"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                _addToFavorites();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Refresh Selected" menu items
    private AbstractAction _refreshSelectedAction = new AbstractAction(
            _I18N.getString("refreshSelected")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("refreshSelectedTip"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                _refreshSelected();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Add to Favorites" menu and toolbar items
    private AbstractAction _configureCatalogDirectoriesAction = new AbstractAction(
            _I18N.getString("configureCatalogDirectories")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("configureCatalogDirectoriesTip"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                _configureCatDirs();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };


    // Action to use for the "Move Up" menu and toolbar items
    private AbstractAction _moveUpAction = new AbstractAction(_I18N.getString("moveUp")) {
        public void actionPerformed(ActionEvent evt) {
            try {
                _moveNode(true);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Move Down" menu and toolbar items
    private AbstractAction _moveDownAction = new AbstractAction(_I18N.getString("moveDown")) {
        public void actionPerformed(ActionEvent evt) {
            try {
                _moveNode(false);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "To Up" menu and toolbar items
    private AbstractAction _toTopAction = new AbstractAction(_I18N.getString("toTop")) {
        public void actionPerformed(ActionEvent evt) {
            try {
                _moveNodeToEnd(true);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "To Bottom" menu and toolbar items
    private AbstractAction _toBottomAction = new AbstractAction(_I18N.getString("toBottom")) {
        public void actionPerformed(ActionEvent evt) {
            try {
                _moveNodeToEnd(false);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Filter panel for tree
    private CatalogTreeControlPanel _controlPanel;

    /**
     * Create a CatalogTree to display a catalog directory hierarchy
     */
    public CatalogTree() {
        setMinimumSize(new Dimension(300, 250));

        _tree = new JTree();

        // Display a message while the catalog directory is being loaded in a background thread
        _tree.setModel(new DefaultTreeModel(new DefaultMutableTreeNode("One moment please...")));
        _loadCatalogDirectory();

        _tree.setShowsRootHandles(true);
        _tree.setBackground(getBackground());
        _tree.setExpandsSelectedPaths(true);
        _tree.setScrollsOnExpand(true);

        // setup the tree node popup menus
        _cutAction.setEnabled(false);
        _copyAction.setEnabled(false);
        _pasteAction.setEnabled(false);
        _toTopAction.setEnabled(false);
        _moveUpAction.setEnabled(false);
        _moveDownAction.setEnabled(false);
        _toBottomAction.setEnabled(false);
        _addToFavoritesAction.setEnabled(false);
        _configureCatalogDirectoriesAction.setEnabled(false);

        _nodeMenu = makeNodeMenu();
        _tree.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    _nodeMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }

            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    _nodeMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });

        // Enable tool tips.
        _tree.setCellRenderer(_getTreeCellRenderer());
        ToolTipManager.sharedInstance().registerComponent(_tree);

        // Listen for when the selection changes.
        _tree.addTreeSelectionListener(new TreeSelectionListener() {
            public void valueChanged(TreeSelectionEvent e) {
                try {
                    _nodeSelected();
                    updateEnabledStates();
                } catch (Exception ex) {
                    DialogUtil.error(ex);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(_tree);
        _controlPanel = _makeControlPanel();
        _controlPanel.setEnabled(false);
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(_controlPanel, BorderLayout.NORTH);
    }

    // Makes and returns a control panel for the tree
    private CatalogTreeControlPanel _makeControlPanel() {
        CatalogTreeControlPanel panel = new CatalogTreeControlPanel();
        ActionListener l = new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                _updateTreeModel();
                _expandAll();
            }
        };
        panel.getFilterTextField().addActionListener(l);
        panel.getCatalogButton().addActionListener(l);
        panel.getArchiveButton().addActionListener(l);
        panel.getImageServerButton().addActionListener(l);
        panel.getNameServerButton().addActionListener(l);

        panel.getExpandButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                _expandAll();
            }
        });

        panel.getCollapseButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                _collapseAll();
            }
        });

        _setMacButtonProperties(panel.getCatalogButton(), "first");
        _setMacButtonProperties(panel.getArchiveButton(), "middle");
        _setMacButtonProperties(panel.getImageServerButton(), "middle");
        _setMacButtonProperties(panel.getNameServerButton(), "last");
        
        _setMacButtonProperties(panel.getExpandButton(), "first");
        _setMacButtonProperties(panel.getCollapseButton(), "last");

        return panel;
    }

    // Sets some button properties that are only used under Mac OS X
    // See http://developer.apple.com/technotes/tn2007/tn2196.html#JBUTTON_BUTTONTYPE
    private void _setMacButtonProperties(AbstractButton button, String pos) {
        button.putClientProperty("JButton.buttonType", "segmentedTextured");
        button.putClientProperty("JButton.segmentPosition", pos);
        button.setFocusable(false);
    }

    // Make sure that all nodes under the given tree node are expanded.
    private void _expandAll() {
        TreeModel model = _tree.getModel();
        _expandAll(model, (DefaultMutableTreeNode) model.getRoot());
    }

    // Make sure that all nodes under the given tree node are expanded.
    private void _expandAll(TreeModel model, DefaultMutableTreeNode treeNode) {
        TreePath path = new TreePath(treeNode.getPath());
        if (_tree.isCollapsed(path)) {
            _tree.expandPath(path);
        }
        int n = model.getChildCount(treeNode);
        for (int i = 0; i < n; i++) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) model.getChild(treeNode, i);
            _expandAll(model, node);
        }
    }

    // Make sure that all nodes "under" the given tree node are collapsed (root stays expanded).
    private void _collapseAll() {
        TreeModel model = _tree.getModel();
        Object root = model.getRoot();
        int n = model.getChildCount(root);
        for (int i = 0; i < n; i++) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) model.getChild(root, i);
            _collapseAll(model, node);
        }
    }

    // Make sure that all nodes under the given tree node are collapsed.
    private void _collapseAll(TreeModel model, DefaultMutableTreeNode treeNode) {
        TreePath path = new TreePath(treeNode.getPath());
        if (!_tree.isCollapsed(path)) {
            _tree.collapsePath(path);
        }
        int n = model.getChildCount(treeNode);
        for (int i = 0; i < n; i++) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) model.getChild(treeNode, i);
            _collapseAll(model, node);
        }
    }

    /**
     * @param handler optional handler, used to report HTML format errors from servers
     */
    public void setHTMLQueryResultHandler(HTMLQueryResultHandler handler) {
        _htmlQueryResultHandler = handler;
    }


    /**
     * @return the renderer to use for tree cells (may be redefined
     *         in a subclass. The default here returns an instance of
     *         CatalogTreeRenderer.
     */
    private TreeCellRenderer _getTreeCellRenderer() {
        return new CatalogTreeCellRenderer();
    }


    /**
     * Sets the object used to display leaf items, such as tables, etc.
     *
     * @param q the object used to display query results
     */
    public void setQueryResultDisplay(QueryResultDisplay q) {
        _queryResultDisplay = q;
    }

    /**
     * @return the object used to display leaf items, such as tables, etc.
     */
    public QueryResultDisplay getQueryResultDisplay() {
        return _queryResultDisplay;
    }


    /**
     * @return the internal JTree
     */
    public JTree getTree() {
        return _tree;
    }


    /**
     * Display the tree structure of the given query result, which may be
     * either a CatalogDirectory or a URLQueryResult, where an HTTP get
     * of the URL returns a CatalogDirectory.
     */
    public void setQueryResult(QueryResult queryResult) {
        if (queryResult instanceof URLQueryResult) {
            _addURLQueryResult(null, ((URLQueryResult) queryResult).getURL());
        } else if (queryResult instanceof CatalogDirectory) {
            _rootCatDir = (CatalogDirectory) queryResult;
            _updateTreeModel();
            _rootCatDir.removeTreeModelListener(this);
            _rootCatDir.addTreeModelListener(this);
        } else {
            throw new RuntimeException("Expected a CatalogDirectory object, not: " + queryResult);
        }
    }

    // Update the tree model to display the (filtered) root catalog directory contents
    private void _updateTreeModel() {
        TreeModel model = _makeTreeModel();
        _tree.setModel(model);
        _controlPanel.setEnabled(true);
    }

    // Returns a filtered tree model, based on the settings in the catalog tree control panel
    private TreeModel _makeTreeModel() {
        String filter = _controlPanel.getFilterTextField().getText();

        Set<String> types = new HashSet<String>();
        if (_controlPanel.getCatalogButton().isSelected()) {
            types.add(Catalog.CATALOG);
        }
        if (_controlPanel.getArchiveButton().isSelected()) {
            types.add(Catalog.ARCHIVE);
        }
        if (_controlPanel.getImageServerButton().isSelected()) {
            types.add(Catalog.IMAGE_SERVER);
        }
        if (_controlPanel.getNameServerButton().isSelected()) {
            types.add(Catalog.NAME_SERVER);
        }

        return new CatalogTreeModel(_rootCatDir, filter, types);
    }


    // Do an HTTP GET on the given URL and add the result to the tree at the given node,
    // if applicable.
    private void _addURLQueryResult(Catalog node, URL url) {
        if (_progressPanel == null) {
            _progressPanel = ProgressPanel.makeProgressPanel(_I18N.getString("downloadingCatalogDesc"), this);
        }

        // run in a separate thread, so the user can monitor progress and cancel it, if needed
        if (_loader == null) {
            _loader = new CatalogLoader(node, url);
            _loader.start();
        }
    }


    // This method is called when a tree node is selected
    private void _nodeSelected() {
        if (_ignoreSelection) {
            return;
        }

        Catalog cat = getSelectedCatalog();
        if (cat == null) {
            return;
        }

        if (cat == _rootCatDir) {
            if (_queryResultDisplay != null) {
                _queryResultDisplay.setQueryResult(null);
            }
            return;
        }

        _addCatalog(cat, cat);
    }


    /**
     * Select the given catalog in the tree
     *
     * @param cat the catalog tree node
     * @param ignoreSelection if true, ignore the tree selection event that results
     */
    public void setSelectedCatalog(Catalog cat, boolean ignoreSelection) {
        if (ignoreSelection) {
            _ignoreSelection = true;
        }
        try {
            CatalogTreeModel model = (CatalogTreeModel) _tree.getModel();
            TreePath path = model.getTreePath(cat);
            if (path != null) {
                _tree.clearSelection();
                _tree.setSelectionPath(path);
                _tree.scrollPathToVisible(path);
            }
        } finally {
            if (ignoreSelection) {
                _ignoreSelection = false;
            }
        }
    }

    /**
     * @return the currently selected catalog
     */
    public Catalog getSelectedCatalog() {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) _tree.getLastSelectedPathComponent();
        if (node != null) {
            Object o = node.getUserObject();
            if (o instanceof Catalog) {
                return (Catalog) o;
            }
        }
        return null;
    }


    /**
     * Add the given query result to the tree at the currently selected node.
     *
     * @param queryResult the query result
     */
    public void addQueryResult(QueryResult queryResult) {
        Catalog selectedCatalog = getSelectedCatalog();
        if (selectedCatalog == null) {
            setQueryResult(queryResult);
        } else {
            _addQueryResult(selectedCatalog, queryResult);
        }
    }


    // Add the given query result to the tree at the given node.
    private void _addQueryResult(Catalog node, QueryResult queryResult) {
        if (queryResult instanceof URLQueryResult) {
            _addURLQueryResult(node, ((URLQueryResult) queryResult).getURL());
        } else if (queryResult instanceof CatalogDirectory) {
//            _addCatalogDirectory(node, (CatalogDirectory) queryResult);
        } else if (queryResult instanceof Catalog) {
            _addCatalog(node, (Catalog) queryResult);
        }
    }


//    // Add the given catalog directory to the tree at the given node.
//    private void _addCatalogDirectory(Catalog node, CatalogDirectory catDir) {
//        int numCatalogs = catDir.getNumCatalogs();
//        if (numCatalogs > 0) {
//            CatalogDirectory parent = node.getParent();
//            if (parent != null) {
//                parent.replaceCatalog(node, catDir);
//                CatalogTreeModel model = (CatalogTreeModel) _tree.getModel();
//                DefaultMutableTreeNode treeNode = model.getTreeNode(catDir);
//                if (treeNode != null) {
//                    _expandAll(model, treeNode);
//                }
//            } else if (node instanceof CatalogDirectory) {
//                // node must be the root node
//                setQueryResult(catDir);
//            } else {
//                throw new RuntimeException("No parent node specified for: " + node.getName());
//            }
//        } else {
//            // might be a link to the catalog description
//            _addCatalog(node, catDir);
//        }
//    }

    // Add the user interface for the given catalog to the query result display.

    private void _addCatalog(Catalog node, Catalog catalog) {
        if (_queryResultDisplay != null) {
            if (catalog.getNumParams() == 0) {
                // if there are no parameters, do the query to get to the actual catalog
                QueryResult queryResult;
                try {
                    queryResult = catalog.query(new BasicQueryArgs(catalog));
                } catch (Exception e) {
                    DialogUtil.error(e);
                    return;
                }
                _addQueryResult(node, queryResult);
            } else {
                _queryResultDisplay.setQueryResult(catalog);
            }
        }
    }


    // This method is called after queryResultHandler.getQueryResult(URL)
    // returns (in the event handling thread) to display the contents of the given
    // catalog directory in the tree at the given node.
    private void _displayQueryResult(Catalog node, CatalogDirectory catDir) {
        QueryResult queryResult = catDir;
        if (catDir.getNumCatalogs() == 1) {
            queryResult = catDir.getCatalog(0);
        }

        if (node == null) {
            setQueryResult(queryResult);
        } else {
            _addQueryResult(node, queryResult);
        }
    }


    // Make and return a popup menu for tree nodes
    private JPopupMenu makeNodeMenu() {
        JPopupMenu menu = new JPopupMenu();

        menu.add(_addToFavoritesAction);
        menu.add(_refreshSelectedAction);

        menu.addSeparator();
        menu.add(_cutAction);
        menu.add(_copyAction);
        menu.add(_pasteAction);

        menu.addSeparator();
        menu.add(_toTopAction);
        menu.add(_moveUpAction);
        menu.add(_moveDownAction);
        menu.add(_toBottomAction);

//        menu.addSeparator();
//        menu.add(_configureCatalogDirectoriesAction);

        return menu;
    }


    /**
     * @return a menu item to reload the catalog config file and rebuild the
     *         tree with the new data.
     */
    public JMenuItem makeReloadMenuItem() {
        JMenuItem menuItem = new JMenuItem(_I18N.getString("reloadConfigFile"));
        menuItem.setToolTipText(_I18N.getString("reloadConfigFileTip"));
        menuItem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                _reload();
            }
        });
        return menuItem;
    }

    // Loads the catalog directory in a background thread and then updates the tree
    private void _loadCatalogDirectory() {
        // Load the catalog information in a background thread, since it could hang, if not cached
        new SwingWorker() {
            public Object construct() {
                try {
                    return CatalogNavigator.getCatalogDirectory();
                } catch (Exception e) {
                    return e;
                }
            }

            public void finished() {
                Object o = getValue();
                if (o instanceof CatalogDirectory) {
                    _rootCatDir = (CatalogDirectory) o;
                    setQueryResult(_rootCatDir);
                } else if (o instanceof Exception) {
                    DialogUtil.error((Exception) o);
                }
            }
        }.start();

    }

    /**
     * If there is a URL corresponding to the root node, read it again and
     * rebuild the tree (in case the file changed...).
     */
    private void _reload() {
        // Run in a background thread, since it can hang
        new SwingWorker() {
            public Object construct() {
                try {
                    return _rootCatDir.reload();
                } catch (Exception e) {
                    return e;
                }
            }

            public void finished() {
                Object o = getValue();
                if (o instanceof CatalogDirectory) {
                    _rootCatDir = (CatalogDirectory) o;
                    setQueryResult(_rootCatDir);
                } else if (o instanceof Exception) {
                    DialogUtil.error((Exception) o);
                }
            }
        }.start();
    }


    /**
     * Displays a dialog for configuring the catalog directories displayed
     */
    private void _configureCatDirs() {
        CatalogDirectoryChooser catDirChooser = new CatalogDirectoryChooser(SwingUtil.getFrame(this));
        catDirChooser.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                setQueryResult(_rootCatDir);
            }
        });
        catDirChooser.setVisible(true);
    }


    /**
     * This method is called in a background thread to get the contents of the
     * given URL and return a QueryResult object representing it.
     */
    public QueryResult getQueryResult(URL url) throws IOException {
        URLConnection connection = url.openConnection();
        String contentType = connection.getContentType();
        if (contentType != null && contentType.equals("text/html")) {
            // might be an HTML error from an HTTP server
            _htmlQueryResultHandler.displayHTMLPage(url);
        } else {
//            String filename = url.getFile();
            CatalogDirectory parentDir = _rootCatDir;
            Catalog selectedNode = getSelectedCatalog();
            if (selectedNode != null && selectedNode != _rootCatDir) {
                CatalogDirectory dir = selectedNode.getParent();
                if (dir != null) {
                    parentDir = dir;
                }
            }
            return parentDir.loadSubDir(url);
        }
        throw new RuntimeException(_I18N.getString("urlAccessError") + ": " + url.toString());
    }

    // This method is called when a tree node is selected to update the
    // enabled states of the actions defined in this class.
    private void updateEnabledStates() {
        Catalog selectedNode = getSelectedCatalog();
        if (selectedNode == null) {
            return;
        }
        CatalogDirectory parent = selectedNode.getParent();
        boolean topLevel = (parent == _rootCatDir);
        boolean editable = (topLevel && !(selectedNode instanceof CatalogDirectory));

        _cutAction.setEnabled(editable);
        _copyAction.setEnabled(!(selectedNode instanceof CatalogDirectory));
        _addToFavoritesAction.setEnabled(!editable && !(selectedNode instanceof CatalogDirectory));
        _pasteAction.setEnabled(ClipboardHelper.getClipboard() instanceof Catalog);

        _toTopAction.setEnabled(topLevel);
        _moveUpAction.setEnabled(topLevel);
        _moveDownAction.setEnabled(topLevel);
        _toBottomAction.setEnabled(topLevel);

        _configureCatalogDirectoriesAction.setEnabled(true);
    }


    /**
     * Cut the selected catalog to the clipboard.
     */
    private void _cut() {
        Catalog selectedNode = getSelectedCatalog();
        if (selectedNode == null) {
            return;
        }

        ClipboardHelper.setClipboard(selectedNode);
        _rootCatDir.removeCatalog(selectedNode);
        _rootCatDir.save();
        _updateTreeModel();
    }


    /**
     * Copy the selected catalog to the clipboard.
     */
    private void _copy() {
        Catalog selectedNode = getSelectedCatalog();
        if (selectedNode == null) {
            return;
        }
        ClipboardHelper.setClipboard(selectedNode);
    }


    /**
     * Paste the selected catalog from the clipboard.
     */
    private void _paste() {
        Object o = ClipboardHelper.getClipboard();
        if (o instanceof Catalog) {
            Catalog cat = (Catalog) o;
            _rootCatDir.addCatalog(0, cat);
            _rootCatDir.save();
            _updateTreeModel();
        } else {
            if (o == null) {
                DialogUtil.error(_I18N.getString("noCatalogObjInClipboard"));
            } else {
                DialogUtil.error(_I18N.getString("noSuitableObjInClipboard"));
            }
        }
    }

    /**
     * Add the selected catalog to the favorites list
     */
    private void _addToFavorites() {
        Catalog selectedCatalog = getSelectedCatalog();
        if (selectedCatalog == null) {
            return;
        }
        _rootCatDir.addCatalog(0, selectedCatalog);
        _rootCatDir.save();
        _updateTreeModel();
        setSelectedCatalog(selectedCatalog, true);
        _expandAll();
    }

    /**
     * Refresh the selected catalog or catalog directory (reload, discarding
     * any cached information)
     */
    private void _refreshSelected() {
        final Catalog selectedCatalog = getSelectedCatalog();
        if (selectedCatalog == _rootCatDir) {
            _reload();
            return;
        }
        // Run in a background thread, since it can hang
        new SwingWorker() {
            public Object construct() {
                try {
                    return selectedCatalog.reload();
                } catch (Exception e) {
                    return e;
                }
            }

            public void finished() {
                Object o = getValue();
                if (o instanceof Catalog) {
                    Catalog cat = (Catalog) o;
                    selectedCatalog.getParent().replaceCatalog(selectedCatalog, cat);
                    setQueryResult(_rootCatDir);
                    setSelectedCatalog(cat, false);
                } else if (o instanceof Exception) {
                    DialogUtil.error((Exception) o);
                }
            }
        }.start();
    }

    /**
     * Move the the selected catalog up or down in the tree.
     *
     * @param up true to move up, false for down
     */
    private void _moveNode(boolean up) {
        Catalog selectedNode = getSelectedCatalog();
        if (selectedNode == null) {
            return;
        }

        _rootCatDir.moveCatalog(selectedNode, up);
        _rootCatDir.save();
        _updateTreeModel();
    }


    /**
     * Move the the selected catalog all the way up or down in the tree, as far as possible.
     *
     * @param up true to move up, false for down
     */
    private void _moveNodeToEnd(boolean up) {
        Catalog selectedNode = getSelectedCatalog();
        if (selectedNode == null) {
            return;
        }

        _rootCatDir.moveCatalogToEnd(selectedNode, up);
        _rootCatDir.save();
        _updateTreeModel();
    }


    // access other toolbar actions
    public AbstractAction getCutAction() {
        return _cutAction;
    }

    public AbstractAction getCopyAction() {
        return _copyAction;
    }

    public AbstractAction getPasteAction() {
        return _pasteAction;
    }

    public AbstractAction getMoveUpAction() {
        return _moveUpAction;
    }

    public AbstractAction getMoveDownAction() {
        return _moveDownAction;
    }

    public AbstractAction getToTopAction() {
        return _toTopAction;
    }

    public AbstractAction getToBottomAction() {
        return _toBottomAction;
    }

    public AbstractAction getConfigureCatalogDirectoriesAction() {
        return _configureCatalogDirectoriesAction;
    }


    // -- Implement TreeModelListener to update the tree when the catalog dir changes --
    public void treeNodesChanged(TreeModelEvent e) {
        setQueryResult(CatalogNavigator.getCatalogDirectory(false));
    }

    public void treeNodesInserted(TreeModelEvent e) {
        setQueryResult(CatalogNavigator.getCatalogDirectory(false));
    }

    public void treeNodesRemoved(TreeModelEvent e) {
        setQueryResult(CatalogNavigator.getCatalogDirectory(false));
    }

    public void treeStructureChanged(TreeModelEvent e) {
        setQueryResult(CatalogNavigator.getCatalogDirectory(false));
    }

    // This utility class is used to load a catalog file or URL in a background thread.
    private class CatalogLoader extends SwingWorker {

        private Catalog _node;
        private URL _url;

        /**
         * Construct a CatalogLoader with a reference to the given tree node and URL
         *
         * @param node the catalog tree node
         * @param url the URL to load
         */
        public CatalogLoader(Catalog node, URL url) {
            _node = node;
            _url = url;
            _progressPanel.start();
        }

        /**
         * Load the URL in the background thread
         */
        public Object construct() {
            try {
                return getQueryResult(_url);
            } catch (Exception e) {
                return e;
            }
        }

        /**
         * Called in default thread after construct() is done
         */
        public void finished() {
            _progressPanel.stop();
            _loader = null;

            Object result = getValue();
            if (result instanceof Exception) {
                DialogUtil.error((Exception) result);
                return;
            }

            if (result == null || !(result instanceof QueryResult)) {
                DialogUtil.error(_I18N.getString("urlLoadError") + ": " + _url.toString());
                return;
            }

            if (result instanceof CatalogDirectory) {
                // A URL returned a catalog directory
                _displayQueryResult(_node, (CatalogDirectory) result);
            } else if (_queryResultDisplay != null) {
                // if the URL's content type was not recognized here, it may be something that the
                // QueryResultDisplay class knows how to display
                _queryResultDisplay.setQueryResult(new URLQueryResult(_url));
            }
        }
    }


    /**
     * test main
     *
     * @param args not used
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("CatalogTree");
                CatalogTree catTree = new CatalogTree();
                frame.getContentPane().add(catTree, BorderLayout.CENTER);
                frame.pack();
                frame.setVisible(true);
                frame.addWindowListener(new BasicWindowMonitor());
            }
        });
    }
}

