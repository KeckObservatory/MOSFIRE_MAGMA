// Copyright 2003 Association for Universities for Research in Astronomy, Inc.,
// Observatory Control System, Gemini Telescopes Project.
//
// $Id: NavigatorImageDisplayManager.java,v 1.1.1.1 2009/02/17 22:50:00 abrighto Exp $
//
package jsky.navigator;

import javax.swing.JFrame;

/**
 * An interface for classes that manage the creation of and a reference to
 * an image display window and its frame.
 */
public abstract interface NavigatorImageDisplayManager {

    /** Return the image display widget */
    public NavigatorImageDisplay getImageDisplay();

    /** Return the image display frame, creating it if needed */
    public JFrame getImageDisplayControlFrame();
}

