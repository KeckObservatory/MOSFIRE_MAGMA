/*
 * Created by JFormDesigner on Sat Jan 24 21:23:12 CET 2009
 */

package jsky.catalog.gui;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import com.jgoodies.forms.layout.*;

/**
 * GUI for the catalog tree control panel.
 * Displays a filter text box and toggle buttons for the catalog type as well as
 * expand and collapse tree buttons. This class only defines the layout.
 *
 * @author Allan Brighton
 */
public class CatalogTreeControlPanel extends JPanel {
    public CatalogTreeControlPanel() {
        initComponents();
    }

    public JLabel getFilterLabel() {
        return filterLabel;
    }

    public JTextField getFilterTextField() {
        return filterTextField;
    }

    public JToggleButton getCatalogButton() {
        return catalogButton;
    }

    public JToggleButton getArchiveButton() {
        return archiveButton;
    }

    public JToggleButton getImageServerButton() {
        return imageServerButton;
    }

    public JToggleButton getNameServerButton() {
        return nameServerButton;
    }

    public JButton getExpandButton() {
        return expandButton;
    }

    public JButton getCollapseButton() {
        return collapseButton;
    }

    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        filterTextField.setEnabled(enabled);
        catalogButton.setEnabled(enabled);
        archiveButton.setEnabled(enabled);
        imageServerButton.setEnabled(enabled);
        nameServerButton.setEnabled(enabled);
        expandButton.setEnabled(enabled);
        collapseButton.setEnabled(enabled);
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        ResourceBundle bundle = ResourceBundle.getBundle("jsky.catalog.gui.i18n.gui");
        filterLabel = new JLabel();
        filterTextField = new JTextField();
        catalogButton = new JToggleButton();
        archiveButton = new JToggleButton();
        imageServerButton = new JToggleButton();
        nameServerButton = new JToggleButton();
        expandButton = new JButton();
        collapseButton = new JButton();
        CellConstraints cc = new CellConstraints();

        //======== this ========
        setLayout(new FormLayout(
            "2*(default, $lcgap), default:grow, $ugap, 3*(default, 1dlu), default, 11dlu, default, 1dlu, default, $lcgap, default",
            "default"));

        //---- filterLabel ----
        filterLabel.setText(bundle.getString("filterLabel.text"));
        add(filterLabel, cc.xy(3, 1));

        //---- filterTextField ----
        filterTextField.setToolTipText(bundle.getString("filterTextField.toolTipText"));
        add(filterTextField, cc.xy(5, 1));

        //---- catalogButton ----
        catalogButton.setIcon(new ImageIcon(getClass().getResource("/images/File16.gif")));
        catalogButton.setMargin(new Insets(0, 0, 0, 0));
        catalogButton.setSelected(true);
        catalogButton.setToolTipText(bundle.getString("catalogButton.toolTipText"));
        add(catalogButton, cc.xy(7, 1));

        //---- archiveButton ----
        archiveButton.setMargin(new Insets(0, 0, 0, 0));
        archiveButton.setIcon(new ImageIcon(getClass().getResource("/images/New16.gif")));
        archiveButton.setSelected(true);
        archiveButton.setToolTipText(bundle.getString("archiveButton.toolTipText"));
        add(archiveButton, cc.xy(9, 1));

        //---- imageServerButton ----
        imageServerButton.setMargin(new Insets(0, 0, 0, 0));
        imageServerButton.setIcon(new ImageIcon(getClass().getResource("/images/WebComponentAdd16.gif")));
        imageServerButton.setSelected(true);
        imageServerButton.setToolTipText(bundle.getString("imageServerButton.toolTipText"));
        add(imageServerButton, cc.xy(11, 1));

        //---- nameServerButton ----
        nameServerButton.setMargin(new Insets(0, 0, 0, 0));
        nameServerButton.setIcon(new ImageIcon(getClass().getResource("/images/About16.gif")));
        nameServerButton.setSelected(true);
        nameServerButton.setToolTipText(bundle.getString("nameServerButton.toolTipText"));
        add(nameServerButton, cc.xy(13, 1));

        //---- expandButton ----
        expandButton.setIcon(new ImageIcon(getClass().getResource("/images/expandall.png")));
        expandButton.setMargin(new Insets(1, 1, 1, 1));
        expandButton.setToolTipText(bundle.getString("expandButton.toolTipText"));
        add(expandButton, cc.xy(15, 1));

        //---- collapseButton ----
        collapseButton.setIcon(new ImageIcon(getClass().getResource("/images/collapseall.png")));
        collapseButton.setMargin(new Insets(1, 1, 1, 1));
        collapseButton.setToolTipText(bundle.getString("collapseButton.toolTipText"));
        add(collapseButton, cc.xy(17, 1));
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JLabel filterLabel;
    private JTextField filterTextField;
    private JToggleButton catalogButton;
    private JToggleButton archiveButton;
    private JToggleButton imageServerButton;
    private JToggleButton nameServerButton;
    private JButton expandButton;
    private JButton collapseButton;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
