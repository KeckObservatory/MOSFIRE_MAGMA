package jsky.catalog.gui;

import jsky.util.SwingWorker;
import jsky.util.gui.ProgressPanel;
import jsky.util.gui.DialogUtil;
import jsky.catalog.astrocat.AstroCatConfig;
import jsky.catalog.Catalog;
import jsky.catalog.CatalogDirectory;
import jsky.catalog.vo.VoCatalogDirectory;

import java.net.URL;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.awt.Frame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import uk.ac.starlink.vo.RegistryQuery;

import javax.swing.table.DefaultTableModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

/**
 * Dialog to choose the top level catalog directories (VO registries) to use
 * for the list of available catalogs.
 *
 * @author Allan Brighton
 * @since Feb 11, 2009
 */
public class CatalogDirectoryChooser extends CatalogDirectoryChooserForm {

    // Root URL for finding registries (TODO: make configurable)
    private static final String ROOT_URL = "http://registry.astrogrid.org/astrogrid-registry/services/RegistryQueryv1_0";

    // Panel used to display download progress information
    private ProgressPanel _progressPanel;

    // list of listeners for change events
    private EventListenerList _listenerList = new EventListenerList();

    /**
     * Initialize with the owner frame.
     *
     * @param owner optional owner frame
     */
    public CatalogDirectoryChooser(Frame owner) {
        super(owner);
        try {
            _update();
        }
        catch (Exception e) {
            DialogUtil.error(e);
        }

        getCancelButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        getOkButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                _apply();
            }
        });
    }

    // Updates the list of available registries and catalog directories
    private void _update() throws MalformedURLException {
        final URL rootUrl = new URL(ROOT_URL);
        if (_progressPanel == null) {
            _progressPanel = ProgressPanel.makeProgressPanel("Updating list of available VO registries from: "
                    + rootUrl.getHost(), this);
        }
        new SwingWorker() {
            public Object construct() {
                try {
                    AstroCatConfig.getConfigFile(); // make sure the current catalog list is read in
                    _progressPanel.start();
                    return RegistryQuery.getSearchableRegistries(ROOT_URL);
                } catch (Exception e) {
                    return e;
                } finally {
                    _progressPanel.stop();
                }
            }

            @Override
            public void finished() {
                Object o = getValue();
                if (o instanceof String[]) {
                    try {
                        _updateTableModel((String[]) o);
                    } catch (Exception e) {
                        DialogUtil.error(e);
                    }
                } else if (o instanceof Exception) {
                    DialogUtil.error((Exception) o);
                }
            }
        }.start();
    }

    // Updates the table model with the list of registry URLs   
    private void _updateTableModel(String[] urls) throws MalformedURLException, URISyntaxException {
        DefaultTableModel model = (DefaultTableModel) getTable().getModel();
        int numRows = model.getRowCount();
        for (int i = 0; i < numRows; i++) {
            model.removeRow(i);
        }

        Set<URI> set = new TreeSet<URI>(); // sort and avoid duplicates
        for (String url : urls) {
            set.add(new URI(url));
        }
        set.add(new URI(ROOT_URL));

        // Determine current VO registries being used: map URL to display name
        AstroCatConfig config = AstroCatConfig.getConfigFile();
        Map<URI, String> map = new HashMap<URI, String>();
        for (Catalog cat : config.getCatalogs()) {
            if (cat instanceof VoCatalogDirectory) {
                VoCatalogDirectory dir = (VoCatalogDirectory) cat;
                URI uri = dir.getURL().toURI();
                String name = dir.getName();
                if (name == null) {
                    name = "";
                }
                map.put(uri, name);
                set.add(uri);
            }
        }

        for (URI uri : set) {
            Vector<Object> row = new Vector<Object>(3);
            String name = map.get(uri);
            row.add(name != null);
            row.add(name);
            row.add(uri.toString());
            model.addRow(row);
        }
    }

    // Apply the changes: Set the catalog directories used to the selected ones in the table.
    private void _apply() {
        // map URL to ddisplay name
        final Map<String, String> map = new TreeMap<String, String>();
        DefaultTableModel model = (DefaultTableModel) getTable().getModel();
        int numRows = model.getRowCount();
        for (int row = 0; row < numRows; row++) {
            if ((Boolean) model.getValueAt(row, 0)) {
                String url = (String) model.getValueAt(row, 2);
                String name = (String) model.getValueAt(row, 1);
                if (name == null || name.length() == 0) {
                    name = url;
                }
                map.put(url, name);
            }
        }

        // Remove any unchecked catalog dirs from the main catalog list
        final AstroCatConfig config = AstroCatConfig.getConfigFile();
        for (Catalog cat : new ArrayList<Catalog>(config.getCatalogs())) {
            if (cat instanceof VoCatalogDirectory) {
                VoCatalogDirectory catDir = (VoCatalogDirectory) cat;
                if (map.get(catDir.getURL().toString()) == null) {
                    config.removeCatalog(cat);
                }
            }
        }

        // Add any checked catalog dirs (this can take some time, so use background threads)
        new SwingWorker() {
            public Object construct() {
                try {
                    for (String urlStr : map.keySet()) {
                        String name = map.get(urlStr);
                        URL url = new URL(urlStr);
                        CatalogDirectory dir = _findDir(config.getCatalogs(), url);
                        if (dir != null) {
                            dir.setName(name);
                        } else {
                            config.addCatalog(VoCatalogDirectory.getCatalogList(name, url));
                        }
                    }
                    return null;
                } catch (Exception e) {
                    return e;
                }
            }

            @Override
            public void finished() {
                Object o = getValue();
                if (o instanceof Exception) {
                    DialogUtil.error((Exception) o);
                } else {
                    setVisible(false);
                    config.save();
                    _fireChangeEvent();
                }
            }
        }.start();
    }

    // Searches the given catalog list for a catDir with the given URL
    private CatalogDirectory _findDir( List<Catalog> list, URL url) {
        for(Catalog cat : list) {
            if (cat instanceof CatalogDirectory) {
                CatalogDirectory catDir = (CatalogDirectory)cat;
                if (url.equals(catDir.getURL())) {
                    return catDir;
                }
            }
        }
        return null;
    }

    /**
     * register to receive change events from this object whenever changes are applied
     *
     * @param l the listener
     */
    public void addChangeListener(ChangeListener l) {
        _listenerList.add(ChangeListener.class, l);
    }

    /**
     * Stop receiving change events from this object.
     *
     * @param l the listener
     */
    public void removeChangeListener(ChangeListener l) {
        _listenerList.remove(ChangeListener.class, l);
    }

    // Notify all ChangeListeners that changes were applied
    private void _fireChangeEvent() {
        ChangeEvent changeEvent = new ChangeEvent(this);
        Object[] listeners = _listenerList.getListenerList();
        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == ChangeListener.class) {
                ((ChangeListener) listeners[i + 1]).stateChanged(changeEvent);
            }
        }
    }

    /**
     * test main
     *
     * @param args not used
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                CatalogDirectoryChooser chooser = new CatalogDirectoryChooser(null);
                chooser.setVisible(true);
            }
        });
    }
}
