package jsky.interop;

import jsky.catalog.FieldDesc;
import jsky.catalog.TableQueryResult;
import jsky.catalog.QueryResult;
import jsky.catalog.gui.QueryResultDisplay;
import jsky.util.gui.DialogUtil;
import jsky.util.gui.ClipboardHelper;
import jsky.util.Resources;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Color;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;

/**
 * A table cell renderer and editor for table cells that contain a URL with a known mime-type.
 * It displays up to three icon buttons:
 * One for the default action (display the contents of the URL, such as the image or table),
 * and two menu buttons for SAMP/PLASTIC send and broadcast.
 *
 * @author Allan Brighton
 * @since Mar 5, 2009
 */
public class UrlTableCellRenderer extends AbstractCellEditor implements TableCellRenderer, TableCellEditor, ActionListener {

    private static final Icon IMAGE_ICON = Resources.getIcon("ImageDisplay18.gif");
    private static final Icon TABLE_ICON = Resources.getIcon("Catalog18.gif");
    private static final Icon BROWSER_ICON = Resources.getIcon("firefox18.gif");

    private static final Icon SEND_ICON = Resources.getIcon("phone2_menu.gif");
    private static final Icon COPY_ICON = Resources.getIcon("Copy16.gif");

    private static final String IMAGE_TOOLTIP = "Display the image at this URL";
    private static final String TABLE_TOOLTIP = "Display the table at this URL";
    private static final String BROWSER_TOOLTIP = "Display the URL link in the default web browser";

    // Background color when selected
    private static final Color SEL_BG = (Color) UIManager.get("Table.selectionBackground");

    // Holds the buttons displayed in the renderer
    private JPanel _panel;

    // The table field corresponding to this cell
    private FieldDesc _fieldDesc;

    // The table containg the field
    private TableQueryResult _tableQueryResult;

    // Used to display query results found by following the link
    private QueryResultDisplay _queryResultDisplay;

    // The value in the cell
    private Object _value;

    // The table row containing this button
    private int _row;

    // The button for the default action
    private JButton _defaultButton;

    // The menu button for sending the URL to another application
    private JButton _sendButton;

    // Set to true if SAMP or PLASTIC are in use
    private boolean _sendEnabled;

    // The format of the link in the currently selected row, if known 
    private String _format;

    // The URL of the link in the currently selected row, if known
    private URL _url;

    // Maps UCD to value in the current table row (needed later for sending spectra)
    private Map _ucdMap;

    // Action to copy the URL for the link to the system clipboard
    private AbstractAction _copyUrlAction = new AbstractAction("Copy URL", COPY_ICON) {
        public void actionPerformed(ActionEvent e) {
            if (_url != null) {
                ClipboardHelper.setClipboard(_url.toString());
            }
        }
    };

    /**
     * Create a JTable cell renderer and editor for columns containing a URL.
     * The URL string may contain column name variables of the form
     * $COLNAME or ${COLNAME}, which are substituted with the values in
     * the named columns.
     *
     * @param fieldDesc          object representing a field (a table column description) in the table query result.
     * @param tableQueryResult   contains the table data
     * @param queryResultDisplay used to display the query result
     */
    public UrlTableCellRenderer(FieldDesc fieldDesc, TableQueryResult tableQueryResult,
                                QueryResultDisplay queryResultDisplay) {
        _panel = new JPanel();
        _fieldDesc = fieldDesc;
        _tableQueryResult = tableQueryResult;
        _queryResultDisplay = queryResultDisplay;
        _sendEnabled = SampHelper.getInstance() != null || PlasticHelper.getInstance() != null;
        _makeLayout();
    }

    // Make the panel layout
    private void _makeLayout() {
        boolean isMacOsX = "Mac OS X".equals(UIManager.getLookAndFeel().getName());
        _panel.setLayout(new FlowLayout(FlowLayout.LEFT, 11, isMacOsX ? -5 : 0)); // Mac OS X look stangeness
        _panel.setBackground(Color.white);

        _defaultButton = new JButton();
        _defaultButton.setBorder(null);
        _defaultButton.setBorderPainted(false);
        _defaultButton.setIcon(IMAGE_ICON);
        _defaultButton.addActionListener(this);
        _defaultButton.setBackground(Color.white);
        _defaultButton.setRolloverEnabled(true);
        _panel.add(_defaultButton);

        _sendButton = new JButton();
        if (_sendEnabled) {
            _sendButton.setBorder(null);
            _sendButton.setBorderPainted(false);
            _sendButton.setIcon(SEND_ICON);
            _sendButton.setBackground(Color.white);
            _sendButton.setRolloverEnabled(true);
            _sendButton.setToolTipText("Send the URL to the selected SAMP/PLASTIC client");
            _sendButton.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    Component c = e.getComponent();
                    JPopupMenu menu = _getSendPopupMenu();
                    if (menu != null) {
                        menu.show(c, 0, c.getHeight());
                    }
                }
            });
            _panel.add(_sendButton);
        }
    }

    // Returns the popup menu for the send button
    private JPopupMenu _getSendPopupMenu() {
        if (_format == null) {
            return null;
        }

        JPopupMenu menu = new JPopupMenu();
        SampHelper sh = SampHelper.getInstance();
        PlasticHelper ph = PlasticHelper.getInstance();

        if (_format.startsWith("image/")
                || _format.equalsIgnoreCase("application/fits")) {
            if (sh != null && ph != null) {
                JMenu sampMenu = new JMenu("SAMP");
                menu.add(sampMenu);
                sh.initImageMenu(sampMenu);

                JMenu plasticMenu = new JMenu("PLASTIC");
                menu.add(plasticMenu);
                ph.initImageMenu(plasticMenu);
            } else {
                if (sh != null) {
                    sh.initImageMenu(menu, _url);
                }
                if (ph != null) {
                    ph.initImageMenu(menu, _url);
                }
            }
        } else if (_format.startsWith("spectrum/")
                || _format.equalsIgnoreCase("text/xml;x-votable")) {
            if (sh != null && ph != null) {
                JMenu sampMenu = new JMenu("SAMP");
                menu.add(sampMenu);
                sh.initTableMenu(sampMenu, _url, _format, _ucdMap);

                JMenu plasticMenu = new JMenu("PLASTIC");
                menu.add(plasticMenu);
                ph.initTableMenu(plasticMenu, _url, _format, _ucdMap);
            } else {
                if (sh != null) {
                    sh.initTableMenu(menu, _url, _format, _ucdMap);
                }
                if (ph != null) {
                    ph.initTableMenu(menu, _url, _format, _ucdMap);
                }
            }
        }
        menu.add(_copyUrlAction);
        return menu;
    }

    /**
     * Called when the default button is pressed
     */
    public void actionPerformed(ActionEvent ev) {
        // get the query result and display it
        try {
            QueryResult queryResult = _fieldDesc.getLinkValue(_tableQueryResult, _value, _row);
            _queryResultDisplay.setQueryResult(queryResult);
        } catch (Exception e) {
            DialogUtil.error(e);
        }
    }

    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        _updateBgColor(isSelected);
        try {
            if (value instanceof String) {
                String urlStr = (String) value;
                _updateDisplay(urlStr, row);
                return _panel;
            }
        } catch (Exception ignored) {
        }
        return table.getDefaultRenderer(Object.class).getTableCellRendererComponent(table, value,
                isSelected, hasFocus,
                row, column);
    }


    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        _row = row;
        _value = value;
        _updateBgColor(isSelected);
        try {
            if (value instanceof String) {
                String urlStr = (String) value;
                _updateDisplay(urlStr, row);
                return _panel;
            }
        } catch (Exception ignored) {
        }
        return table.getDefaultEditor(Object.class).getTableCellEditorComponent(table, value,
                isSelected, row, column);
    }

    // Sets a tooltip for the renderer, including the URL
    private void setUrlToolTip() {
        if (_url != null) {
            _panel.setToolTipText("<html>Display the object, send or broadcast it to another application<br>"
                    + "URL: " + _url.toString());
        }
    }

    // Updates the display based on the format string associated with the link, if known
    private void _updateBgColor(boolean isSelected) {
        Color color = (isSelected ? SEL_BG : Color.white);
        _panel.setBackground(color);
        _sendButton.setBackground(color);
        _defaultButton.setBackground(color);
    }

    // Returns a Map of UCD => columnValue for the given row
    private Map _getUcdMap(int row) {
        Map<String, String> ucdMap = new HashMap<String, String>();
        int columnCount = _tableQueryResult.getColumnCount();
        for (int col = 0; col < columnCount; col++) {
            String ucd = _tableQueryResult.getColumnDesc(col).getUCD();
            if (ucd != null) {
                Object value = _tableQueryResult.getValueAt(row, col);
                if (value != null) {
                    ucdMap.put(ucd, value.toString());
                }
            }
        }
        return ucdMap;
    }

    // Updates the display based on the format string associated with the link, if known
    private void _updateDisplay(String urlStr, int row) throws MalformedURLException {
        _format = _fieldDesc.getLinkFormat(_tableQueryResult, row);
        _ucdMap = _getUcdMap(row);
        // For backward compat: More Info column
        if (urlStr.startsWith("M=")) {
            urlStr = urlStr.substring(2);
            _format = "text/html";
        }
        // For backward compat: Preview column
        if (urlStr.startsWith("P=")) {
            urlStr = urlStr.substring(2);
            _format = "image/fits";
        }
        _url = new URL(urlStr);
        setUrlToolTip();

        _defaultButton.setVisible(false);
        _sendButton.setVisible(false);

        if (_format != null) {
            if (_format.startsWith("spectrum/")
                    || _format.equalsIgnoreCase("text/xml;x-votable")
                    || _format.equalsIgnoreCase("text/csv")) {
                _defaultButton.setVisible(true);
                _defaultButton.setIcon(TABLE_ICON);
                _defaultButton.setToolTipText(TABLE_TOOLTIP);
                _sendButton.setVisible(true);
            } else if (_format.startsWith("image/")
                    || _format.equalsIgnoreCase("application/fits")) {
                _defaultButton.setVisible(true);
                _defaultButton.setIcon(IMAGE_ICON);
                _defaultButton.setToolTipText(IMAGE_TOOLTIP);
                _sendButton.setVisible(true);
            } else {
//                // This will cause the default renderer to be used
//                throw new RuntimeException();

                // Let the browser deal with it...
                _defaultButton.setVisible(true);
                _defaultButton.setIcon(BROWSER_ICON);
                _defaultButton.setToolTipText(BROWSER_TOOLTIP);
                _sendButton.setVisible(false);
            }
        } else {
            throw new RuntimeException();
        }
    }

    public Object getCellEditorValue() {
        return _value;
    }
}
