/*
 * Copyright 2001 Association for Universities for Research in Astronomy, Inc.,
 * Observatory Control System, Gemini Telescopes Project.
 *
 * $Id: NavigatorImageDisplayToolBar.java,v 1.4 2009/03/17 22:56:43 abrighto Exp $
 */

package jsky.navigator;

import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.Icon;
import javax.swing.Action;

import jsky.image.gui.ImageDisplayToolBar;
import jsky.util.I18N;
import jsky.util.Resources;

/**
 * A tool bar for the image display window.
 */
public class NavigatorImageDisplayToolBar extends ImageDisplayToolBar {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(NavigatorImageDisplayToolBar.class);

    // toolbar buttons
    protected JButton catalogButton;
    protected JToggleButton gridButton;

    /**
     * Create the toolbar for the given window
     */
    public NavigatorImageDisplayToolBar(NavigatorImageDisplay imageDisplay) {
        super(imageDisplay);
    }

    /**
     * Add the items to the tool bar.
     */
    protected void addToolBarItems() {
        super.addToolBarItems();

        addSeparator();
        add(makeCatalogButton());
        addSeparator();
        add(makeGridButton());
    }

    /**
     * Make the catalog button, if it does not yet exists. Otherwise update the display
     * using the current options for displaying text or icons.
     *
     * @return the catalog button
     */
    protected JButton makeCatalogButton() {
        if (catalogButton == null) {
            catalogButton = makeButton(((NavigatorImageDisplay) imageDisplay).getCatalogBrowseAction());
        }

        updateButton(catalogButton,
                _I18N.getString("catalogs"),
                Resources.getIcon("Catalog24.gif"));
        return catalogButton;
    }


    /**
     * Make the WCS grid button, if it does not yet exists. Otherwise update the display
     * using the current options for displaying text or icons.
     *
     * @return the grid button
     */
    protected JToggleButton makeGridButton() {
        if (gridButton == null) {
            gridButton = makeToggleButton(((NavigatorImageDisplay) imageDisplay).getGridAction());
        }

        updateButton(gridButton, _I18N.getString("grid"), getGridIcon());
        return gridButton;
    }

    /**
     * @return the icon to display (on/off) for the grid button, based on the current grid visibility
     */
    protected Icon getGridIcon() {
        return (Icon)((NavigatorImageDisplay) imageDisplay).getGridAction().getValue(Action.SMALL_ICON);
    }


    /**
     * Update the toolbar display using the current text/pictures options.
     * (redefined from the parent class).
     */
    public void update() {
        super.update();
        makeCatalogButton();
        makeGridButton();
    }
}

