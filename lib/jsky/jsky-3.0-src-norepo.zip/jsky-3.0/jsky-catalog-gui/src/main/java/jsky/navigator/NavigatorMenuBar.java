/*
 * $Id: NavigatorMenuBar.java,v 1.4 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.navigator;

import javax.swing.JMenu;

import jsky.catalog.gui.CatalogNavigatorMenuBar;
import jsky.catalog.gui.CatalogTree;

/**
 * Extends the CatalogNavigatorMenuBar class by adding a "Catalog"
 * menu containing implementation specific items for selecting the catalogs
 * to display in the tree.
 *
 * @version $Revision: 1.4 $
 * @author Allan Brighton
 */
public class NavigatorMenuBar extends CatalogNavigatorMenuBar {

    /**
     * Create the menubar for the given Navigator panel.
     * @param navigator the target catalog window
     * @param toolbar the toolbar for the window
     */
    public NavigatorMenuBar(Navigator navigator, NavigatorToolBar toolbar) {
        super(navigator, toolbar);
        //add(_helpMenu = createHelpMenu());
    }

    /** Add a catalog menu to the catalog navigator frame */
    protected JMenu createCatalogMenu() {
        Navigator navigator = (Navigator) getNavigator();
        JMenu menu = new NavigatorCatalogMenu(navigator, false);

        CatalogTree catalogTree = navigator.getCatalogTree();
        menu.addSeparator();
        menu.add(catalogTree.makeReloadMenuItem());

        // Unfortunately, this doesn't seem to work yet (SOAP errors)
//        menu.add(catalogTree.getConfigureCatalogDirectoriesAction());

        menu.addSeparator();
        menu.add(catalogTree.getCutAction());
        menu.add(catalogTree.getCopyAction());
        menu.add(catalogTree.getPasteAction());

        menu.addSeparator();
        menu.add(catalogTree.getToTopAction());
        menu.add(catalogTree.getMoveUpAction());
        menu.add(catalogTree.getMoveDownAction());
        menu.add(catalogTree.getToBottomAction());

        return menu;
    }
}

