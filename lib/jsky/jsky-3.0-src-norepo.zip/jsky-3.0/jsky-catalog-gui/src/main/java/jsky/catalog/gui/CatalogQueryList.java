/*
 * Copyright 2003 Association for Universities for Research in Astronomy, Inc.,
 * Observatory Control System, Gemini Telescopes Project.
 *
 * $Id: CatalogQueryList.java,v 1.1.1.1 2009/02/17 22:49:43 abrighto Exp $
 */

package jsky.catalog.gui;

import jsky.util.Preferences;

import java.util.*;

/**
 * Manages a list of saved query argument and display settings.
 */
public class CatalogQueryList {

    // Base filename for serialization of the query list
    private static final String QUERY_LIST_NAME = "catalogQueryList";

    // List of CatalogQueryItem, for previously saved queries.
    private List<CatalogQueryItem> _queryList;


    /** Constructor */
    public CatalogQueryList() {
        _load();

        // arrange to save the query list for the next session on exit
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                _save();
            }
        });
    }


    /**
     * Add the given item to the query stack, removing duplicates.
     * @param queryItem  the item to add
     */
    public void add(CatalogQueryItem queryItem) {
        // remove duplicates from query list
        remove(queryItem.getName());
        _queryList.add(queryItem);
    }

    /**
     * Remove the named item from the list.
     * @param name the name of the item to remove
     */
    public void remove(String name) {
        for (CatalogQueryItem item : new ArrayList<CatalogQueryItem>(_queryList)) {
            if (item.getName().equals(name)) {
                _queryList.remove(item);
                break;
            }
        }
    }


    /** @return an iterator over the query list */
    public Iterator iterator() {
        return _queryList.iterator();
    }

    /** @return the size of the query list */
    public int size() {
        return _queryList.size();
    }


    /** Make the query list empty */
    public void clear() {
        _queryList = new ArrayList<CatalogQueryItem>();
        _save();
    }

    // Try to load the query list from a file, and create an empty list if that fails. */
    private void _load() {
        try {
            //noinspection unchecked
            _queryList = (List<CatalogQueryItem>) Preferences.getPreferences().deserialize(QUERY_LIST_NAME);
        } catch (Exception e) {
            _queryList = new ArrayList<CatalogQueryItem>();
        }
    }

    /*
     * Save the current query list to a file.
     * If merge is true, merge the list with the existing list on disk.
     */
    private void _save() {
        try {
            Preferences.getPreferences().serialize(QUERY_LIST_NAME, _queryList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

