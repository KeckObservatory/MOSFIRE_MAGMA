/*
 * ESO Archive
 *
 * $Id: NavigatorFrame.java,v 1.2 2009/04/14 10:56:02 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/06/02  Created
 */

package jsky.navigator;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.ImageIcon;

import jsky.catalog.gui.BasicTablePlotter;
import jsky.catalog.gui.CatalogTree;
import jsky.catalog.gui.TablePlotter;
import jsky.image.gui.MainImageDisplay;
import jsky.util.Preferences;
import jsky.util.Resources;


/**
 * Provides a top level window and menubar for the Navigator class.
 */
public class NavigatorFrame extends JFrame {

    /**
     * Main panel
     */
    protected Navigator navigator;

    /**
     * Set to true until setVisible is called
     */
    private boolean firstTime = true;


    /**
     * Create a top level window containing a Navigator panel
     *
     * @param imageDisplay optional widget to use to display images (if not specified,
     *                     or null, a new window will be created)
     */
    public NavigatorFrame(MainImageDisplay imageDisplay) {
        super("Catalog Navigator");

        setIconImage(new ImageIcon(Resources.getResource("images/Catalog24.gif")).getImage());
        CatalogTree catalogTree = new CatalogTree();
        TablePlotter plotter = new BasicTablePlotter();

        navigator = new Navigator(catalogTree, plotter, imageDisplay);

        NavigatorToolBar toolbar = new NavigatorToolBar(navigator);
        getContentPane().add(toolbar, BorderLayout.NORTH);
        getContentPane().add(navigator, BorderLayout.CENTER);
        setJMenuBar(new NavigatorMenuBar(navigator, toolbar));

        // set default window size and remember changes between sessions
        Preferences.manageSize(navigator, new Dimension(800, 700));
        Preferences.manageLocation(this);
        setDefaultCloseOperation(HIDE_ON_CLOSE);

    }

    /**
     * Create a top level window containing a Navigator panel
     */
    public NavigatorFrame() {
        this(null);
    }

    /**
     * @return the navigator panel.
     */
    public Navigator getNavigator() {
        return navigator;
    }


    /**
     * Delay pack until first show of window to avoid linux display bug
     */
    public void setVisible(boolean b) {
        if (b && firstTime) {
            firstTime = false;
            pack();
        }
        super.setVisible(b);
    }


    /**
     * test main
     * @param args not used
     */
    public static void main(String[] args) {
        NavigatorFrame f = new NavigatorFrame();
        f.setVisible(true);
    }
}

