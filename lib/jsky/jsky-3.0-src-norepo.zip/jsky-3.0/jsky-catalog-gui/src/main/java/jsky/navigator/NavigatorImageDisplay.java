/*
 * $Id: NavigatorImageDisplay.java,v 1.7 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.navigator;

import java.awt.event.ActionEvent;
import java.awt.geom.AffineTransform;
import java.util.HashSet;
import java.util.Set;

import javax.swing.AbstractAction;
import javax.swing.JFrame;

import jsky.catalog.Catalog;
import jsky.catalog.CatalogDirectory;
import jsky.catalog.TableQueryResult;
import jsky.catalog.QueryResult;
import jsky.catalog.gui.CatalogNavigatorOpener;
import jsky.catalog.gui.TablePlotter;
import jsky.image.fits.codec.FITSImage;
import jsky.image.fits.gui.FITSKeywordsFrame;
import jsky.image.gui.DivaMainImageDisplay;
import jsky.image.gui.PickObjectStatistics;
import jsky.image.gui.ImageDisplayControlFrame;
import jsky.util.I18N;
import jsky.util.Resources;
import jsky.util.gui.DialogUtil;
import jsky.util.gui.SwingUtil;
import jsky.catalog.gui.CatalogNavigator;

/**
 * Extends the DivaMainImageDisplay class by adding support for
 * browsing catalogs and plotting catalog symbols on the image.
 *
 * @author Allan Brighton
 * @version $Revision: 1.7 $
 */
public class NavigatorImageDisplay extends DivaMainImageDisplay
        implements CatalogNavigatorOpener {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(NavigatorImageDisplay.class);

    /**
     * The instance of the catalog navigator to use with this image display.
     */
    private Navigator _navigator;

    /**
     * The Diva pane containing the added catalog symbol layer.
     */
    private NavigatorPane _navigatorPane;

    /**
     * The catalog navigator frame
     */
    private JFrame _navigatorFrame;

    /**
     * Set of filenames: Used to keep track of the files visited in this session.
     */
    private Set<String> _filesVisited = new HashSet<String>();

    /**
     * Action to use to show the catalog window (Browse catalogs)
     */
    private AbstractAction _catalogBrowseAction = new AbstractAction(
            _I18N.getString("browse") + "...",
            Resources.getIcon("Catalog24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("showCatalogWindow"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                openCatalogWindow();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use to show or hide the WCS grid
     */
    private AbstractAction _gridAction = new AbstractAction(
            _I18N.getString("grid") + "...",
            Resources.getIcon("grid.gif")
    ) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("showGrid"));
        }
        public void actionPerformed(ActionEvent evt) {
            try {
                toggleGrid();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Construct a NavigatorImageDisplay widget.
     */
    public NavigatorImageDisplay() {
        super(new NavigatorPane());
        _navigatorPane = (NavigatorPane) getCanvasPane();
        _navigatorPane.setImageDisplay(this);
    }

    /**
     * @return the Diva pane containing the added catalog symbol layer.
     */
    public NavigatorPane getNavigatorPane() {
        return _navigatorPane;
    }

    /**
     * Open up another window like this one and return a reference to it.
     */
    public ImageDisplayControlFrame newWindow() {
        NavigatorImageDisplayFrame f = new NavigatorImageDisplayFrame();
        f.getImageDisplayControl().getImageDisplay().setTitle(getTitle());
        f.setVisible(true);
        return f;
    }

    /**
     * Set the instance of the catalog navigator to use with this image display.
     *
     * @param navigator the instance
     */
    public void setNavigator(Navigator navigator) {
        _navigator = navigator;
        _navigatorFrame = SwingUtil.getFrame(navigator);
    }

    /**
     * @return the instance of the catalog navigator used with this image display.
     */
    public Navigator getNavigator() {
        return _navigator;
    }

    /**
     * Display or hide the WCS grid
     */
    public void toggleGrid() {
        setGridVisible(!isGridVisible());
    }

    /**
     * @return true if the WCS grid is visible
     */
    public boolean isGridVisible() {
        return _navigatorPane.getGridLayer().isVisible();
    }

    /**
     * Sets the visibility of the WCS grid
     *
     * @param visible set to true to show the grid
     */
    public void setGridVisible(boolean visible) {
        if (visible != isGridVisible()) {
            _navigatorPane.getGridLayer().setVisible(visible);
            // Use this if you want to change icons depending on the state of the grid
//            _gridAction.putValue(Action.SMALL_ICON, Resources.getIcon(isGridVisible() ? "gridon.gif" : "gridoff.gif"));
            repaint();
        }
    }

    /**
     * Open the catalog navigator window.
     */
    public void openCatalogWindow() {
        if (_navigatorFrame == null) {
            makeNavigatorFrame();
        }
        showNavigatorFrame(null);
    }

    /**
     * Display the interface for the given catalog, if not null, otherwise just
     * open the catalog navigator window.
     */
    public void openCatalogWindow(Catalog cat) {
        if (_navigatorFrame == null) {
            makeNavigatorFrame();
        }
        showNavigatorFrame(cat);
    }

    /**
     * Open a catalog window for the named catalog, if found.
     */
    public void openCatalogWindow(String name) {
        CatalogDirectory dir = CatalogNavigator.getCatalogDirectory(false);
        Catalog cat = dir.findCatalog(name);
        if (cat != null) {
            openCatalogWindow(cat);
        }
    }

    /**
     * Pop up a file browser to select a local catalog file to open.
     */
    public void openLocalCatalog() {
        openCatalogWindow();
        _navigator.open();
    }


    /**
     * Display the FITS table at the given HDU index.
     */
    public void displayFITSTable(int hduIndex) {
        FITSImage fitsImage = getFitsImage();
        if (fitsImage != null && hduIndex > 0 && hduIndex < fitsImage.getNumHDUs()) {
            try {
                TableQueryResult table = NavigatorFITSTable.getTable(getFilename(), fitsImage.getFits(), hduIndex);
                showNavigatorFrame(null);
                openCatalogWindow(table.getCatalog());

                // update the FITS header display, if needed
                FITSKeywordsFrame fitsKeywordsFrame = getFitsKeywordsFrame();
                if (fitsKeywordsFrame != null) {
                    fitsKeywordsFrame.getFITSKeywords().updateDisplay(hduIndex);
                }
            } catch (Exception e) {
                DialogUtil.error(this, e);
            }
        }
    }

    /**
     * Deletes the FITS table at the given HDU index.
     */
    public void deleteFITSTable(int hduIndex) {
        FITSImage fitsImage = getFitsImage();
        if (fitsImage != null && hduIndex > 0 && hduIndex < fitsImage.getNumHDUs()) {
            try {
                NavigatorFITSTable.deleteTable(fitsImage.getFits(), hduIndex);
                setSaveNeeded(true);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    }

    /**
     * Save (or update) the given table as a FITS table in the current FITS image.
     *
     * @param table the table to save in the FITS image in a FITS table HDU
     */
    public void saveFITSTable(TableQueryResult table) {
        FITSImage fitsImage = getFitsImage();
        if (fitsImage == null) {
            DialogUtil.error(this, "This operation is only supported on FITS files.");
            return;
        }

        try {
            TableQueryResult newTable = NavigatorFITSTable.saveWithImage(getFilename(), fitsImage.getFits(), table);
            if (newTable == null) {
                return;
            }

            setSaveNeeded(true);
            checkExtensions(true);

            // unplot the original table, since the FITS table will be plotted from now on
            TablePlotter plotter = _navigator.getPlotter();
            if (plotter != null) {
                plotter.unplot(table);
                //plotter.plot(newTable);
                _navigator.setQueryResult(newTable.getCatalog());
            }
        } catch (Exception e) {
            DialogUtil.error(this, e);
        }
    }


    /**
     * If the given catalog argument is null, display the catalog window ("Browse" mode),
     * otherwise query the catalog using the default arguments for the current image.
     *
     * @param cat the catalog
     */
    protected void showNavigatorFrame(Catalog cat) {
        if (cat != null) {
            _navigator.setAutoQuery(true);
            _navigator.setQueryResult(cat);
        } else {
            _navigator.setAutoQuery(false);
            SwingUtil.showFrame(_navigatorFrame);
        }
    }


    /**
     * Makes a NavigatorFrame
     */
    protected void makeNavigatorFrame() {
        _navigator = NavigatorManager.create();
        _navigatorFrame = SwingUtil.getFrame(_navigator);
        _navigator.setImageDisplay(this);
    }


    /**
     * This method is called before and after a new image is loaded, each time
     * with a different argument.
     *
     * @param before set to true before the image is loaded and false afterwards
     */
    protected void newImage(boolean before) {
        super.newImage(before);

        if (!before) {
            if (_navigatorFrame == null) {
                makeNavigatorFrame();
            }

            if (_navigatorFrame != null) {
                // Replot any previously plotted catalogs (from any image)
                // in coordinate system of the new image
                TablePlotter plotter = _navigator.getPlotter();
                if (plotter != null) {
                    plotter.replotAll();
                }

                // If this is the first time this image is being visited this session,
                // plot any catalog tables stored as FITS tables
                String filename = getFilename();
                FITSImage fitsImage = getFitsImage();
                if (fitsImage != null && filename != null) {
                    if (!_filesVisited.contains(filename)) {
                        _filesVisited.add(filename);
                        try {
                            NavigatorFITSTable.plotTables(filename, fitsImage.getFits(), _navigator);
                        } catch (Exception e) {
                            DialogUtil.error(this, e);
                        }
                    }
                }
            }
        }
    }


    /**
     * Cleanup when the window is no longer needed.
     */
    public void dispose() {
        super.dispose();

        if (_navigatorFrame != null) {
            _navigatorFrame.dispose();
        }
    }

    /**
     * Transform the image graphics using the given AffineTransform.
     */
    protected void transformGraphics(AffineTransform trans) {
        super.transformGraphics(trans);
        if (_navigator != null) {
            TablePlotter plotter = _navigator.getPlotter();
            if (plotter != null) {
                plotter.transformGraphics(trans);
            }
        }
    }


    /**
     * Save any current catalog overlays as a FITS table in the image file.
     */
    public void saveCatalogOverlaysWithImage() {
        if (_navigator != null) {
            TablePlotter plotter = _navigator.getPlotter();
            if (plotter != null) {
                TableQueryResult[] tables = plotter.getTables();
                if (tables != null) {
                    for (TableQueryResult table : tables) {
                        saveFITSTable(table);
                    }
                }
            }
        }
    }

    /**
     * Called when an object is selected in the Pick Object window.
     * <p/>
     * Add the currently selected object in the "Pick Object" window to the currently
     * displayed table, or create a new table if none is being displayed.
     */
    protected void pickedObject() {
        if (_navigatorFrame == null) {
            makeNavigatorFrame();
        }
        if (_navigator == null) {
            return;
        }
        PickObjectStatistics stats = getPickObjectPanel().getStatistics();
        if (stats == null) {
            DialogUtil.error("No object was selected");
            return;
        }
        _navigator.addPickedObjectToTable(stats, getPickObjectPanel().isUpdate());
    }


    // Other menu and toolbar actions
    public AbstractAction getCatalogBrowseAction() {
        return _catalogBrowseAction;
    }

    public AbstractAction getGridAction() {
        return _gridAction;
    }

    /**
     * Can be overridden in a derived class to filter the result of a catalog query.
     *
     * @param queryResult the result of a catalog query
     * @return the possibly filtered result
     */
    public QueryResult filterQueryResult(QueryResult queryResult) {
        return queryResult;
    }
}
