// Copyright 2003 Association for Universities for Research in Astronomy, Inc.,
// Observatory Control System, Gemini Telescopes Project.
//
// $Id: NavigatorManager.java,v 1.1.1.1 2009/02/17 22:49:56 abrighto Exp $
//
package jsky.navigator;

import javax.swing.JFrame;

import jsky.util.gui.SwingUtil;


/**
 * This class manages access to the Navigator window on behalf of clients.
 */
public final class NavigatorManager {

    /**
     * The single Navigator, shared for all instances
     */
    private static Navigator _navigator;


    /**
     * @return the Navigator instance, if it exists, otherwise null.
     */
    public static Navigator get() {
        return _navigator;
    }

    /**
     * Open the Navigator window, creating it if necessary, and return a reference to it.
     * @return the Navigator window
     */
    public static Navigator open() {
        if (_navigator == null && create() == null) {
            return null;
        }

        JFrame parent = SwingUtil.getFrame(_navigator);
        if (parent != null) {
            SwingUtil.showFrame(parent);
        }
        return _navigator;
    }


    /**
     * Create the Navigator window if necessary, and return a reference to it.
     * @return the Navigator window
     */
    public static Navigator create() {
        if (_navigator == null) {
            _navigator = new NavigatorFrame().getNavigator();
        }

        return _navigator;
    }
}
