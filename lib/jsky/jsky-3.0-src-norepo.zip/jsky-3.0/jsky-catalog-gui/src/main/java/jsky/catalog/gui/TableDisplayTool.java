/*
 * ESO Archive
 *
 * $Id: TableDisplayTool.java,v 1.6 2009/04/17 12:34:54 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/06/02  Created
 */

package jsky.catalog.gui;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.io.File;
import java.util.Vector;
import java.util.List;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import jsky.catalog.MemoryCatalog;
import jsky.catalog.QueryResult;
import jsky.catalog.TableQueryResult;
import jsky.util.I18N;
import jsky.util.IApplyCancel;
import jsky.util.PrintableWithDialog;
import jsky.util.Saveable;
import jsky.util.SaveableAsHTML;
import jsky.util.SaveableWithDialog;
import jsky.util.Storeable;
import jsky.util.gui.*;
import jsky.interop.SampHelper;


/**
 * Combines a TableDisplay component for displaying query results in
 * tabular form with a title and some buttons to perform various actions.
 */
public class TableDisplayTool extends JPanel
        implements QueryResultDisplay, Saveable, SaveableWithDialog, SaveableAsHTML,
        PrintableWithDialog, Storeable {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(TableDisplayTool.class);

    // File browser filters
    private static final ExampleFileFilter VOTABLE_FILTER = new ExampleFileFilter(new String[]{
            "xml", "vot"}, "VOTable XML File");
    private static final ExampleFileFilter FITS_FILTER = new ExampleFileFilter(new String[]{
            "fit", "fits", "fts"}, "FITS File (with Table Extensions)");
    private static final ExampleFileFilter SKYCAT_TSV_FILTER = new ExampleFileFilter(new String[]{
            "table", "scat", "cat"}, "Skycat Local Catalog File");

    // The catalog to use
    private TableQueryResult _table;

    // Set to true if the table data has been plotted
    private boolean _plotted = false;

    // Table for displaying query results
    private TableDisplay _tableDisplay;

    // Table for displaying query results
    private SortedJTable _sortedJTable;

    // The object to use to plot the table data
    private TablePlotter _plotter;

    // Title for query results table
    private JLabel _tableTitle;

    // Panel containing command buttons
    private JPanel _buttonPanel;

    // Panel buttons
    private JButton _plotButton;
    private JButton _unplotButton;
    private JButton _unplotAllButton;
    private JButton _configButton;

    // Frame  for _configPanel
    private TabbedPaneDialog _configureDialog;

    // Panel used to configure the table and plot symbol display
    private TabbedPanel _configPanel;

    // Panel inside configPanel used to select columns to display
    private TableColumnConfigPanel _tableConfig;

    // If true, ignore selection events on plot symbols or rows
    private boolean ignoreSelection = false;

    // reuse file chooser widget
    private static JFileChooser _fileChooser;

    // If true, broadcast row selections over SAMP or PLASTIC
    private static boolean _broadcastRowSelections = true;

    // Used to select a table row when the symbol is selected
    private SymbolSelectionListener _symbolListener = new SymbolSelectionListener() {

        public void symbolSelected(SymbolSelectionEvent e) {
            if (!ignoreSelection && e.getTable() == _table) {
                ignoreSelection = true;
                try {
                    _tableDisplay.selectRow(e.getRow());
                    _broadcastRowSelections();
                } catch (Exception ignored) {
                }
                ignoreSelection = false;
            }
        }

        public void symbolDeselected(SymbolSelectionEvent e) {
            if (!ignoreSelection && e.getTable() == _table) {
                ignoreSelection = true;
                try {
                    _tableDisplay.deselectRow(e.getRow());
                } catch (Exception ignored) {
                }
                ignoreSelection = false;
            }
        }
    };

    // Used to select a plot symbol when the table row is selected
    private ListSelectionListener _selectionListener = new ListSelectionListener() {

        public void valueChanged(ListSelectionEvent e) {
            if (e.getValueIsAdjusting() || ignoreSelection) {
                return;
            }
            ListSelectionModel model = _tableDisplay.getTable().getSelectionModel();
            int first = e.getFirstIndex();
            int last = e.getLastIndex();
            for (int i = first; i <= last; i++) {
                int index = _sortedJTable.getSortedRowIndex(i);
                if (model.isSelectedIndex(i)) {
                    _plotter.selectSymbol(_table, index);
                } else {
                    _plotter.deselectSymbol(_table, index);
                }
            }
            _broadcastRowSelections();
        }
    };

    /**
     * Broadcast the current table row selections to clients via SAMP
     */
    private void _broadcastRowSelections() {
        if (_broadcastRowSelections) {
            int[] rows = _tableDisplay.getTable().getSelectedRows();
            List<Integer> selectedRows = new ArrayList<Integer>(rows.length);
            for (int row : rows) {
                int index = _sortedJTable.getSortedRowIndex(row);
                selectedRows.add(index);
            }
            SampHelper sh = SampHelper.getInstance();
            if (sh != null) {
                sh.transmitSelectedRows(selectedRows);
            }
        }
    }


    /**
     * Create a TableDisplayTool for viewing the given table data.
     *
     * @param table              the table data
     * @param queryResultDisplay object used to display any query results resulting from following links
     * @param plotter            object used to plot the table data
     */
    public TableDisplayTool(TableQueryResult table, QueryResultDisplay queryResultDisplay,
                            TablePlotter plotter) {
        _table = table;
        _plotter = plotter;

        makeLayout(queryResultDisplay);

        // try to plot the table after it is displayed (make sure its the event thread)
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                plot();
            }
        });
    }


    /**
     * Do the window layout
     *
     * @param queryResultDisplay object used to display any query results resulting from following links
     */
    protected void makeLayout(QueryResultDisplay queryResultDisplay) {
        _tableDisplay = makeTableDisplay(_table, queryResultDisplay);
        _sortedJTable = _tableDisplay.getTable();

        _tableTitle = new JLabel("", JLabel.CENTER);
        updateTitle();

        _buttonPanel = makeButtonPanel();

        GridBagUtil layout = new GridBagUtil(this);
        layout.add(_tableTitle, 0, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.NONE,
                GridBagConstraints.CENTER,
                new Insets(3, 0, 3, 0));
        layout.add(_tableDisplay, 0, 1, 1, 1, 1.0, 1.0,
                GridBagConstraints.BOTH,
                GridBagConstraints.CENTER,
                new Insets(0, 0, 0, 0));
        layout.add(_buttonPanel, 0, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.HORIZONTAL,
                GridBagConstraints.CENTER,
                new Insets(5, 0, 0, 0));
    }

    /**
     * Create the TableDisplay or a derived widget.
     *
     * @param table              the table data
     * @param queryResultDisplay object used to display any query results resulting from following links in the table
     * @return the new TableDisplay object
     */
    protected TableDisplay makeTableDisplay(TableQueryResult table, QueryResultDisplay queryResultDisplay) {
        return new TableDisplay(table, queryResultDisplay);
    }


    /**
     * @return the table for displaying query results
     */
    public TableDisplay getTableDisplay() {
        return _tableDisplay;
    }


    /**
     * @return the new button panel
     */
    protected JPanel makeButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        _plotButton = new JButton(_I18N.getString("plot"));
        _plotButton.setToolTipText(_I18N.getString("plotTip"));
        panel.add(_plotButton);
        _plotButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                unplot();
                plot();
            }
        });

        _unplotButton = new JButton(_I18N.getString("unplot"));
        _unplotButton.setToolTipText(_I18N.getString("unplotTip"));
        panel.add(_unplotButton);
        _unplotButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                unplot();
            }
        });

        _unplotAllButton = new JButton(_I18N.getString("unplotAll"));
        _unplotAllButton.setToolTipText(_I18N.getString("unplotAllTip"));
        panel.add(_unplotAllButton);
        _unplotAllButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                unplotAll();
            }
        });

        _configButton = new JButton(_I18N.getString("configure"));
        _configButton.setToolTipText(_I18N.getString("configureTip"));
        panel.add(_configButton);
        _configButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                configure();
            }
        });

        return panel;
    }


    /**
     * @return the button panel
     */
    public JPanel getButtonPanel() {
        return _buttonPanel;
    }

    public JButton getPlotButton() {
        return _plotButton;
    }

    public JButton getUnplotButton() {
        return _unplotButton;
    }

    public JButton getUnplotAllButton() {
        return _unplotAllButton;
    }

    public JButton getConfigButton() {
        return _configButton;
    }

    /**
     * Sets whether table selections are broadcast over SAMP
     *
     * @param b true if row selections should be broadcast
     */
    public static void setBroadcastRowSelections(boolean b) {
        _broadcastRowSelections = b;
    }

    /**
     * Plot the contents of the table.
     */
    public void plot() {
        if (_plotter != null) {
            _tableDisplay.getTable().clearSelection(); // do this or add code to keep selections in sync
            _plotter.addSymbolSelectionListener(_symbolListener);
            _tableDisplay.getTable().getSelectionModel().addListSelectionListener(_selectionListener);
            try {
                _plotter.plot(_table);
                _plotted = true;
            } catch (Exception e) {
                //DialogUtil.error(e);
            }
        }
    }

    /**
     * Remove any plot symbols for this table.
     */
    public void unplot() {
        if (_plotter != null) {
            _plotter.removeSymbolSelectionListener(_symbolListener);
            _tableDisplay.getTable().getSelectionModel().removeListSelectionListener(_selectionListener);
            _plotter.unplot(_table);
            _plotted = false;
        }
    }

    /**
     * Remove all plot symbols.
     */
    public void unplotAll() {
        if (_plotter != null) {
            _plotter.removeSymbolSelectionListener(_symbolListener);
            _plotter.unplotAll();
            _plotted = false;
        }
    }


    /**
     * Replot any plot symbols for this table.
     */
    public void replot() {
        unplot();
        plot();
    }


    /**
     * @return the TableQueryResult corresponding to this object
     */
    public TableQueryResult getTable() {
        return _table;
    }

    /**
     * @return the table for displaying query results
     */
    protected SortedJTable getSortedJTable() {
        return _sortedJTable;
    }

    /**
     * @return the object to use to plot the table data
     */
    public TablePlotter getPlotter() {
        return _plotter;
    }

    /**
     * Set the object to use to plot the table data
     *
     * @param plotter used to plot the table data
     */
    public void setPlotter(TablePlotter plotter) {
        _plotter = plotter;
    }

    /**
     * Pop up a dialog to configure the plot symbols and table display.
     */
    public void configure() {
        if (_configureDialog != null) {
            _configureDialog.setVisible(true);
            return;
        }

        String title = _I18N.getString("configureTableDisplay");
        _configureDialog = new TabbedPaneDialog(SwingUtil.getFrame(this), title);
        _configPanel = _configureDialog.getTabbedPanel();

        addTableColumnConfigPanel();

        if (_plotter != null) {
            addPlotterConfigPanel();
        }

        // make sure to get the frame size set correctly
        _configureDialog.pack();
        _configureDialog.setVisible(true);
    }

    /**
     * Add a panel to the config window to configure the symbol plotting
     */
    protected void addPlotterConfigPanel() {
        final JTabbedPane tabbedPane = _configPanel.getTabbedPane();
        final IApplyCancel symbolConfig = getPlotter().getConfigPanel(getTable());
        tabbedPane.add((JPanel) symbolConfig, _I18N.getString("plotSymbols"));

        ActionListener applyListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                symbolConfig.apply();
            }
        };
        ActionListener cancelListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                symbolConfig.cancel();
            }
        };
        _configPanel.getApplyButton().addActionListener(applyListener);
        _configPanel.getOKButton().addActionListener(applyListener);
        _configPanel.getCancelButton().addActionListener(cancelListener);
    }


    /**
     * Add a panel to the config window to configure the table columns
     */
    protected void addTableColumnConfigPanel() {
        JTabbedPane tabbedPane = _configPanel.getTabbedPane();
        _tableConfig = new TableColumnConfigPanel(_tableDisplay);
        tabbedPane.add(_tableConfig, _I18N.getString("showTableCols"));

        ActionListener applyListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                _tableConfig.apply();
            }
        };
        ActionListener cancelListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                _tableConfig.cancel();
            }
        };
        _configPanel.getApplyButton().addActionListener(applyListener);
        _configPanel.getOKButton().addActionListener(applyListener);
        _configPanel.getCancelButton().addActionListener(cancelListener);
    }


    /**
     * @return the panel used to configure the table and plot symbol display
     */
    public TabbedPanel getConfigPanel() {
        return _configPanel;
    }


    /**
     * Hide any popup windows associated with this window
     */
    public void hidePopups() {
        if (_configureDialog != null) {
            _configureDialog.setVisible(false);
        }
    }


    /**
     * Return the name of this component (based on the data being displayed)
     */
    public String getName() {
        if (_table != null) {
            return _table.getName();
        }
        return _I18N.getString("table");
    }


    /**
     * Display the given query results. Tabular data is displayed in
     * the table. Other query result types must be implemented in
     * a derived class.
     *
     * @param queryResult an object returned from the Catalog query method.
     */
    public void setQueryResult(QueryResult queryResult) {
        if (queryResult instanceof TableQueryResult) {
            if (_plotted && _plotter != null) {
                _plotter.unplot(_table);
            }

            _table = (TableQueryResult) queryResult;

            // check if more data was available than was returned
            String title = _table.getTitle() + " (" + _table.getRowCount() + (_table.isMore() ? "+)" : ")");
            _tableTitle.setText(title);
            _tableDisplay.setModel(_table);

            if (_plotter != null) {
                _plotter.plot(_table);
            }

            updateConfigPanel();
        }
    }

    /**
     * Update the table config panel, if needed
     */
    protected void updateConfigPanel() {
        if (_tableConfig != null) {
            _tableConfig.cancel();
        }
    }

    /**
     * Create and return a new file chooser to be used to select a local catalog file
     * to open.
     *
     * @return the new file chooser
     */
    protected JFileChooser makeFileChooser() {
        JFileChooser fileChooser = new JFileChooser(new File("."));

        fileChooser.addChoosableFileFilter(VOTABLE_FILTER);
        fileChooser.addChoosableFileFilter(FITS_FILTER);
        fileChooser.addChoosableFileFilter(SKYCAT_TSV_FILTER);

        fileChooser.setFileFilter(VOTABLE_FILTER);

        return fileChooser;
    }


    /**
     * Pop up a dialog to ask the user for a file name, and then save the contents of the
     * table to the selected file.
     */
    public void saveAs() {
        if (_table instanceof Saveable) {
            if (_fileChooser == null) {
                _fileChooser = makeFileChooser();
            }
            int option = _fileChooser.showSaveDialog(this);
            if (option == JFileChooser.APPROVE_OPTION && _fileChooser.getSelectedFile() != null) {
                File file = _fileChooser.getSelectedFile();
                String filename = file.getAbsolutePath();
                if (!file.getName().contains(".")) {
                    FileFilter filter = _fileChooser.getFileFilter();
                    if (filter == VOTABLE_FILTER) {
                        filename += ".vot";
                    } else if (filter == FITS_FILTER) {
                        filename += ".fits";
                    }
                }
                saveAs(filename);
            }
        } else {
            DialogUtil.error(_I18N.getString("saveNotSupportedForTableType") + ": " + _table.getClass());
        }
    }


    /**
     * Save the table to the given file.
     */
    public void saveAs(String filename) {
        if (_table instanceof Saveable) {
            try {
                File file = new File(filename);
                if (file.exists()) {
                    // File already exists.  Prompt for overwrite
                    String msg = _I18N.getString("fileOverWritePrompt", filename);
                    int ans = DialogUtil.confirm(msg);
                    if (ans != JOptionPane.YES_OPTION) {
                        return;
                    }
                }
                ((Saveable) _table).saveAs(filename);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        } else {
            DialogUtil.error(_I18N.getString("saveNotSupportedForTableType") + ": " + _table.getClass());
        }
    }


    /**
     * Save the table to the given file in HTML format.
     */
    public void saveAsHTML(String filename) {
        try {
            File file = new File(filename);
            if (file.exists()) {
                // File already exists.  Prompt for overwrite
                String msg = _I18N.getString("fileOverWritePrompt", filename);
                int ans = DialogUtil.confirm(msg);
                if (ans != JOptionPane.YES_OPTION) {
                    return;
                }
            }
            _tableDisplay.saveAsHTML(filename);
        } catch (Exception e) {
            DialogUtil.error(e);
        }
    }

    /**
     * Display a print dialog to print the contents of this object.
     */
    public void print() throws PrinterException {
        _tableDisplay.print(_tableTitle.getText());
    }

    /**
     * Update the table and frame titles to show the table title and number of rows
     */
    protected void updateTitle() {
        if (_table != null) {
            String titleString = _table.getTitle() + " (" + _table.getRowCount() + ")";
            setName(titleString);
            _tableTitle.setText(titleString);
        }
    }


    /**
     * Add an empty row to the table.
     */
    public void addRow() {
        addRow(null);
    }

    /**
     * Add a row to the table.
     *
     * @param v the vector for the row
     */
    public void addRow(Vector v) {
        _tableDisplay.getTable().addRow(v);
        _tableDisplay.update();
        updateTitle();
    }

    /**
     * Update a row in the table with the new data.
     * An exception will be thrown if the row index is
     * out of range or the vector has the wrong size.
     *
     * @param rowIndex the row index
     * @param v the row values
     */
    public void updateRow(int rowIndex, Vector v) {
        TableQueryResult table = _tableDisplay.getTableQueryResult();
        for (int colIndex = 0; colIndex < v.size(); colIndex++) {
            table.setValueAt(v.get(colIndex), rowIndex, colIndex);
        }
        _tableDisplay.update();
    }

    /**
     * @param rowIndex the row index
     * @return the vector for the given row.
     */
    public Vector getRow(int rowIndex) {
        DefaultTableModel model = (DefaultTableModel) _tableDisplay.getTableQueryResult();
        return (Vector) model.getDataVector().get(rowIndex);
    }


    /**
     * Delete the selected rows.
     */
    public void deleteSelectedRows() {
        SortedJTable t = _tableDisplay.getTable();
        int[] selected = t.getSelectedRows();
        t.removeRows(selected);
        _tableDisplay.update();
        if (_plotter != null && _plotted) {
            unplot();
            plot();
        }
        updateTitle();
    }


    /**
     * Set the editable state of the cells in the displayed table.
     * @param b true if editable
     */
    public void setTableCellsEditable(boolean b) {
        TableQueryResult queryResult = _tableDisplay.getTableQueryResult();
        if (queryResult instanceof MemoryCatalog) {
            ((MemoryCatalog) queryResult).setReadOnly(!b);
        }
    }


    /**
     * @return the number of rows in the table.
     */
    public int getRowCount() {
        return _tableDisplay.getTableQueryResult().getRowCount();
    }


    /**
     * Store the current settings in a serializable object and return the object.
     */
    public Object storeSettings() {
        return _tableDisplay.storeSettings();
    }

    /**
     * Restore the settings previously stored.
     */
    public boolean restoreSettings(Object obj) {
        return _tableDisplay.restoreSettings(obj);
    }
}

