package jsky.interop;

import org.astrogrid.samp.gui.IndividualCallActionManager;
import org.astrogrid.samp.gui.GuiHubConnector;
import org.astrogrid.samp.gui.SubscribedClientListModel;
import org.astrogrid.samp.Client;
import org.astrogrid.samp.Message;
import org.astrogrid.samp.Subscriptions;
import org.astrogrid.samp.httpd.ServerResource;

import javax.swing.JMenu;
import java.util.Map;
import java.util.HashMap;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;

import jsky.util.Resources;
import jsky.catalog.gui.CatalogNavigator;
import jsky.catalog.QueryResult;
import jsky.catalog.Catalog;
import jsky.catalog.TableQueryResult;
import uk.ac.starlink.votable.VOTableWriter;
import uk.ac.starlink.fits.FitsTableWriter;
import uk.ac.starlink.table.StarTableWriter;
import uk.ac.starlink.table.StarTable;


/**
 * TableSendActionManager which will transmit a table. A selection of table formats (table.load.*) is available
 * as required -
 * currently only votable and fits are offered, but it is a one-liner to add other supported formats.
 *
 * @author Mark Taylor (original), Allan Brighton (modified for JSky)
 */
public class TableSendActionManager extends IndividualCallActionManager {

// From a mail from Mark Taylor: new spectrum type, similar to PLASTIC version:
//
//      MType:
//         spectrum.load.ssa (later changed to: spectrum.load.ssa-generic)
//      Parameters:
//         url (string):
//            URL of the spectrum to load
//         meta (map):
//            Additional metadata describing the spectral data found
//            at the URL.  Key->value pairs represent either
//            Utypes or UCDs as defined or used in some version of
//            the SSA specification or its predecessors.
//            For example "Access.Format" (SSA 1.0 MIME type Utype)
//            or "VOX:Spectrum_Format" (pre-1.0 SSA MIME type UCD).
//         spectrum-id (string) optional:
//            Identifier which may be used to refer to the loaded spectrum
//            in subsequent messages
//         name (string) optional:
//            Name which may be used to label the loaded spectrum in the
//            application UI
//      Return Values:
//         none
//
// See http://www.ivoa.net/cgi-bin/twiki/bin/view/IVOA/SampMTypes#spectrum_load_ssa_generic for more recent description.


    /**
     * Supported table send formats.
     */
    private static final Sender[] SENDERS = new Sender[]{
            new Sender("table.load.votable", "text/xml;x-votable", new VOTableWriter(), ".vot"),
            new Sender("table.load.votable", "spectrum/votable", new VOTableWriter(), ".vot"),
            new Sender("table.load.fits", "spectrum/fits", new FitsTableWriter(), ".fits"),
            new Sender("spectrum.load.ssa-generic", "spectrum/votable", new VOTableWriter(), ".vot"),
            new Sender("spectrum.load.ssa-generic", "spectrum/fits", new FitsTableWriter(), ".fits"),
    };

    // Reference to catalog window
    private CatalogNavigator _navigator;

    // The URL of the table, if known (otherwise the displayed table is used)
    private URL _url;

    // The expected format/mime type, if known, may be null
    private String _format;

    // Maps UCD to column value for the selected row (may be empty)
    private Map _ucdMap;

    // Used to generate unique id
    private static int _idCount;

    // Maps table id to samp id (The SAMP id has more restrictions on the format)
    private static Map<String, String> _idMap = new HashMap<String, String>();


    /**
     * Constructor.
     *
     * @param parent    parent component
     * @param connector hub connector
     * @param url       the URL of the table to send, or null to use the displayed table
     * @param format    the expected format/mime type, if known, may be null
     * @param ucdMap    maps UCD to column value for the current table row (may be empty)
     */
    public TableSendActionManager(CatalogNavigator parent, GuiHubConnector connector, URL url,
                                  String format, Map ucdMap) {
        super(parent, connector, new SubscribedClientListModel(connector, getSendMtypes()));
        _navigator = parent;
        _url = url;
        _format = format;
        _ucdMap = ucdMap;
    }

    /**
     * Returns the Message object which is to be transmitted by this manager to a given client.  This is called by the
     * action returned by {@link #getSendAction}.
     *
     * @param client target
     * @return message
     */
    @Override
    protected Map createMessage(Client client) throws Exception {
        Sender sender = getSender(client, _format);
        if (sender != null) {
            if (_url != null) {
                // message for a table referenced by a cell in another table
                String sampId = createSampId();
                return sender.createMessage(_navigator, _url, sampId, _ucdMap);
            } else {
                // message to send currently displayed table
                String sampId = getSampId();
                StarTable table = _navigator.getStarTable();
                if (table != null) {
                    String label = sampId;
                    QueryResult queryResult = _navigator.getQueryResult();
                    if (queryResult instanceof Catalog) {
                        label = ((Catalog) queryResult).getTitle();
                    }
                    return sender.createMessage(_navigator, table, label, sampId, _ucdMap);
                }
            }
        }
        return null;
    }

    /**
     * Returns the SAMP id for the current table, if known, otherwise a new unique id
     *
     * @return opaque ID string
     */
    private String getSampId() {
        QueryResult queryResult = _navigator.getQueryResult();
        if (queryResult instanceof TableQueryResult) {
            String tableId = ((TableQueryResult) queryResult).getId();
            if (tableId != null) {
                String sampId = _idMap.get(tableId);
                if (sampId != null) {
                    return sampId;
                }
                sampId = createSampId();
                _idMap.put(tableId, sampId);
                return sampId;
            }
        }
        return createSampId();
    }

    /**
     * Returns a new unique SAMP ID.
     *
     * @return opaque ID string
     */

    private String createSampId() {
        return "jsky"
                + Integer.toString(System.identityHashCode(this) & 0xffff, 16)
                + "-"
                + ++_idCount;
    }


    /**
     * Returns the SAMP id for the given table id, if known, otherwise null.
     *
     * @param tableId the value of the id field in a TableQueryResult
     * @return the SAMP id used when sending the table
     */
    static String getSampId(String tableId) {
        if (tableId != null) {
            String sampId = _idMap.get(tableId);
            if (sampId != null) {
                return sampId;
            }
        }
        return null;
    }


    /**
     * Returns a Sender object which can send a table to a given client.
     *
     * @param client target client
     * @param format a format string, such as spectrum/fits or spectrum/votable
     * @return sender
     */
    private Sender getSender(Client client, String format) {
        Subscriptions subs = client.getSubscriptions();
        for (Sender sender : SENDERS) {
            if (subs.isSubscribed(sender.getMtype())
                    && (format == null || format.equals(sender.getFormat()))) {
                return sender;
            }
        }
        return null;
    }


    public JMenu createSendMenu() {
        JMenu menu = super.createSendMenu("Send Table to...");
        menu.setToolTipText("Send table to a single other registered client using SAMP");
        menu.setIcon(Resources.getIcon("phone2.gif"));
        return menu;
    }

    /**
     * Returns the array of MTypes which this sender can use to send tables.
     *
     * @return mtype list
     */
    private static String[] getSendMtypes() {
        String[] mtypes = new String[SENDERS.length];
        for (int i = 0; i < SENDERS.length; i++) {
            mtypes[i] = SENDERS[i].getMtype();
        }
        return mtypes;
    }

    /**
     * Encapsulates format-specific details of how a table is sent over SAMP.
     */
    private static class Sender {
        private final String _mtype;
        private final String _format;
        private final StarTableWriter _writer;
        private final String _extension;

        /**
         * Constructor.
         *
         * @param mtype     MType of table send message
         * @param format    data format handled
         *                  (value of format column, such as "spectrum/fits" or "spectrum/votable")
         * @param writer    serializer for table
         * @param extension suggested file extension (including dot) for table URL
         */
        Sender(String mtype, String format, StarTableWriter writer, String extension) {
            _mtype = mtype;
            _format = format;
            _writer = writer;
            _extension = extension;
        }

        /**
         * Returns the MType used by this sender.
         *
         * @return MType
         */
        public String getMtype() {
            return _mtype;
        }

        /**
         * Returns the format handled, which is
         * a value from the format column of the originating VOTABLE,
         * such as "spectrum/fits" or "spectrum/votable".
         *
         * @return format string
         */
        public String getFormat() {
            return _format;
        }

        /**
         * Returns a message suitable for sending a table.
         *
         * @param navigator main catalog GUI: used to register the url and table id for later reference
         * @param table     table to send
         * @param label     informative (uniqueness not essential)
         * @param sampId    table ID, unique to relevant parts of table state @return send message
         * @param ucdMap    maps UCD to column value for the current table row (may be empty)
         * @return the message
         * @throws java.io.IOException on error
         */
        protected Message createMessage(CatalogNavigator navigator, StarTable table, String label,
                                        String sampId, Map ucdMap) throws IOException {
            String name = "t" + sampId + _extension;
            URL turl = JSkyServer.getInstance().addResource(name, createResource(table));
            navigator.registerTable(turl, sampId);
            if (_mtype.startsWith("spectrum")) {
                return new Message(_mtype)
                        .addParam("url", turl.toString())
                        .addParam("id", sampId)
                        .addParam("meta", ucdMap);
            } else {
                return new Message(_mtype)
                        .addParam("url", turl.toString())
                        .addParam("table-id", sampId)
                        .addParam("name", label);
            }
        }

        /**
         * Returns a message suitable for sending a table.
         *
         * @param navigator main catalog GUI: used to register the url and table id for later reference
         * @param url       the URL of the table
         * @param sampId    table ID, unique to relevant parts of table state @return send message
         * @param ucdMap    maps UCD to column value for the current table row (may be empty)
         * @return the message
         * @throws java.io.IOException on error
         */
        protected Message createMessage(CatalogNavigator navigator, URL url,
                                        String sampId, Map ucdMap) throws IOException {
            navigator.registerTable(url, sampId);
            if (_mtype.startsWith("spectrum")) {
                return new Message(_mtype)
                        .addParam("url", url.toString())
                        .addParam("id", sampId)
                        .addParam("meta", ucdMap);
            } else {
                return new Message(_mtype)
                        .addParam("url", url.toString())
                        .addParam("table-id", sampId)
                        .addParam("name", sampId);
            }
        }

        /**
         * Obtains a (somewhat) persistent resource object via which a table can be made available to external
         * processes.
         *
         * @param table table
         * @return servable resource
         */
        private ServerResource createResource(final StarTable table) {
            return new ServerResource() {
                public long getContentLength() {
                    return -1L;
                }

                public String getContentType() {
                    return _writer.getMimeType();
                }

                public void writeBody(OutputStream out) throws IOException {
                    _writer.writeStarTable(table, out);
                }
            };
        }

        public String toString() {
            return _mtype;
        }
    }
}
