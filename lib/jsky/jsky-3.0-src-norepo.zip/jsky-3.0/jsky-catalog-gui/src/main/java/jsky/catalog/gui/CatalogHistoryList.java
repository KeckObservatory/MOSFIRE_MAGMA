/*
 * Copyright 2003 Association for Universities for Research in Astronomy, Inc.,
 * Observatory Control System, Gemini Telescopes Project.
 *
 * $Id: CatalogHistoryList.java,v 1.1.1.1 2009/02/17 22:49:47 abrighto Exp $
 */

package jsky.catalog.gui;

import java.util.LinkedList;
import java.util.ListIterator;

import jsky.util.Preferences;

import javax.swing.JComponent;
import java.util.Iterator;
import java.util.List;

/**
 * Manages a list of catalogs for the history menu
 */
public class CatalogHistoryList {

    // Base filename for serialization of the history list
    private static final String HISTORY_LIST_NAME = "catalogHistoryList";

    // List of CatalogHistoryItem, for previously viewed catalogs or query results.
    private LinkedList<CatalogHistoryItem> _historyList;

    // Max number of items in the history list
    private int _maxHistoryItems = 20;


    /**
     * Constructor
     */
    public CatalogHistoryList() {
        _load();

        // arrange to save the history list for the next session on exit
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                _save(true);
            }
        });
    }


    /**
     * Add the given item to the history stack, removing duplicates.
     *
     * @param historyItem the item to add
     */
    public void add(CatalogHistoryItem historyItem) {
        // remove duplicates from history list
        for (CatalogHistoryItem item : new LinkedList<CatalogHistoryItem>(_historyList)) {
            if (item.getName().equals(historyItem.getName())) {
                _historyList.remove(item);
            }
        }
        _historyList.addFirst(historyItem);
        if (_historyList.size() > _maxHistoryItems) {
            _historyList.removeLast();
        }
    }


    /**
     * @return the max number of items in the history list.
     */
    public int getMaxHistoryItems() {
        return _maxHistoryItems;
    }

    /**
     * Set the max number of items in the history list.
     * @param n max number of items
     */
    public void setMaxHistoryItems(int n) {
        _maxHistoryItems = n;
    }

    /**
     * @return an iterator over the history list
     */
    public Iterator<CatalogHistoryItem> iterator() {
        return _historyList.iterator();
    }


    /**
     * Make the history list empty
     */
    public void clear() {
        _historyList = new LinkedList<CatalogHistoryItem>();
        _save(false);
    }

//    // This method is called after the history list is deserialized to remove any
//    // items in the list that can't be accessed.
//    private void _cleanup() {
//        ListIterator<CatalogHistoryItem> it = _historyList.listIterator(0);
//        CatalogDirectory catDir = CatalogNavigator.getCatalogDirectory(false);
//        while (it.hasNext()) {
//            CatalogHistoryItem item = it.next();
//            if (item.getURLStr() == null && catDir.findCatalog(item.getName()) == null) {
//                it.remove();
//            }
//        }
//    }

    // Try to load the history list from a file, and create an empty list if that fails. */
    private void _load() {
        try {
            //noinspection unchecked
            _historyList = (LinkedList<CatalogHistoryItem>) Preferences.getPreferences().deserialize(HISTORY_LIST_NAME);
//            _cleanup();
        } catch (Exception e) {
            _historyList = new LinkedList<CatalogHistoryItem>();
        }
    }

    // Merge the _historyList with current serialized version (another instance
    // may have written it since we read it last).
    private LinkedList<CatalogHistoryItem> _merge() {
        List<CatalogHistoryItem> savedHistory = _historyList;
        _load();

        // Go through the list in reverse, since add() inserts at the start of the list
        ListIterator it = savedHistory.listIterator(savedHistory.size());
        while (it.hasPrevious()) {
            add((CatalogHistoryItem) it.previous());
        }
        return _historyList;
    }


    // Save the current history list to a file.
    // If merge is true, merge the list with the existing list on disk.
    private void _save(boolean merge) {
        try {
            LinkedList<CatalogHistoryItem> l;
            if (merge) {
                l = _merge();
            } else {
                l = _historyList;
            }
            Preferences.getPreferences().serialize(HISTORY_LIST_NAME, l);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the item for the given query component, if found, otehrwise null
     * @param queryComp the query component window
     */
    public CatalogHistoryItem getItemForQueryComponent(JComponent queryComp) {
        for(CatalogHistoryItem item : _historyList) {
            if (item.getQueryComponent() == queryComp) {
                return item;
            }
        }
        return null;
    }
}

