package jsky.catalog.gui;

import jsky.catalog.CatalogDirectory;
import jsky.catalog.Catalog;
import jsky.util.StringUtil;

import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;

/**
 * A tree model for the catalog tree, which displays a (possibly filtered) view
 * of a catalog hierarchy.
 */
public class CatalogTreeModel extends DefaultTreeModel {

    // A wildcard expression to filter the tree nodes
    private String _filter;

    // Set of catalog types to display (values defined in Catalog interface)
    private Set<String> _types;

    // Helps find the tree node for a given catalog
    private Map<Catalog, DefaultMutableTreeNode> _nodeMap;

    /**
     * Initizlize with the top level catalog directory and optional filter information.
     *
     * @param catDir top level list of catalogs
     * @param filter wildcard expression to match against catalog names
     * @param types  a set of catalog types, such as {@link Catalog#CATALOG},
     *               {@link Catalog#ARCHIVE}, {@link Catalog#IMAGE_SERVER}, , {@link Catalog#NAME_SERVER}
     */
    public CatalogTreeModel(CatalogDirectory catDir, String filter, Set<String> types) {
        super(new DefaultMutableTreeNode(catDir));
        _filter = filter;
        _types = types;
        _nodeMap = new HashMap<Catalog, DefaultMutableTreeNode>();
        _updateModel();
    }

    // Recursively add tree nodes to match the catalog directory structure
    private void addNodes(DefaultMutableTreeNode root) {
        CatalogDirectory catDir = (CatalogDirectory) root.getUserObject();
        List<Catalog> list = catDir.getCatalogs();
        for (Catalog cat : list) {
            boolean isDir = cat instanceof CatalogDirectory && ((CatalogDirectory)cat).getNumCatalogs() > 0;
            if (isDir || _matches(cat)) {
                DefaultMutableTreeNode node = new DefaultMutableTreeNode(cat);
                root.add(node);
                if (!_nodeMap.containsKey(cat)) {
                    _nodeMap.put(cat, node);
                }
                if (isDir) {
                    addNodes(node);
                }
            }
        }
    }

    // Returns true if the given catalog should be displayed, based on the
    // selected filter string and the selected catalog types
    private boolean _matches(Catalog cat) {
        if (_filter != null && _filter.length() != 0) {
            if (!StringUtil.match(_filter, cat.getName())) {
                return false;
            }
        }
        return _types.contains(cat.getType());
    }

    // Updates the tree model after a change in the underlying catalog directory
    private void _updateModel() {
        DefaultMutableTreeNode rootTreeNode = (DefaultMutableTreeNode) getRoot();
        CatalogDirectory dir = (CatalogDirectory)rootTreeNode.getUserObject();

        rootTreeNode.removeAllChildren();
        _nodeMap.clear();
        _nodeMap.put(dir, rootTreeNode);
        addNodes(rootTreeNode);
    }

    /**
     * Returns the path to the given catalog, or null if not found
     *
     * @param cat the catalog
     * @return the tree path or null
     */
    public TreePath getTreePath(Catalog cat) {
        DefaultMutableTreeNode node = _nodeMap.get(cat);
        if (node != null) {
            return new TreePath(node.getPath());
        }
        return null;
    }

    /**
     * Returns the tree node for the given catalog
     *
     * @param cat the catalog
     * @return the tree node or null if not found
     */
    public DefaultMutableTreeNode getTreeNode(Catalog cat) {
        return _nodeMap.get(cat);
    }
}
