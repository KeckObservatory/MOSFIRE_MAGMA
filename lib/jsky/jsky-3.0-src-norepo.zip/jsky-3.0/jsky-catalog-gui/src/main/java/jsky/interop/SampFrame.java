package jsky.interop;

import org.astrogrid.samp.gui.GuiHubConnector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.Icon;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import javax.swing.KeyStroke;
import javax.swing.ImageIcon;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;

import jsky.util.Resources;
import jsky.util.Preferences;

/**
 * Frame displaying SAMP status and controls.
 *
 * @author Mark Taylor
 * @version $Id: SampFrame.java,v 1.1 2009/03/12 21:56:18 abrighto Exp $
 */
public class SampFrame extends JFrame {
    /**
     * Content pane of frame
     */
    private JPanel contentPane = null;

    /**
     * Hub connector.
     */
    private GuiHubConnector hubConnector;

    /**
     * Action buttons container.
     */
    protected JPanel actionBar = new JPanel();

    /**
     * Constructor.
     */
    public SampFrame(GuiHubConnector hubConnector) {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(new BorderLayout());
        this.hubConnector = hubConnector;
        initUI();
        initFrame();
    }

    /**
     * Initialise the main part of the user interface.
     */
    private void initUI() {
        //  Menubar and toolbars.
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        //  File menu.
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        menuBar.add(fileMenu);

//        //  Help menu.
//        HelpFrame.createHelpMenu( "samp-window", "Help on window", menuBar, null );

        //  Main part is a monitor panel derived from the connector.
        contentPane.add(hubConnector.createMonitorPanel(),
                BorderLayout.CENTER);

        //  Action bar uses a BoxLayout and is placed at the south.
        contentPane.add(actionBar, BorderLayout.SOUTH);

        //  Add an action to connect and/or start hub.
        Icon connectIcon = Resources.getIcon("connect.gif");
        Action connectAction = hubConnector.createRegisterOrHubAction(this, null);
        connectAction.putValue(Action.SMALL_ICON, connectIcon);
        actionBar.add(new JButton(connectAction));

        //  Add an action to close the window (appears in File menu
        //  and action bar).
        Icon closeIcon = Resources.getIcon("close.gif");
        Action closeAction = new CloseAction("Close", closeIcon);
        fileMenu.add(closeAction).setMnemonic(KeyEvent.VK_C);
        JButton closeButton = new JButton(closeAction);
        actionBar.add(closeButton);
    }

    /**
     * Inititalise frame properties.
     */
    private void initFrame() {
        setTitle("SAMP Status");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setIconImage(new ImageIcon(Resources.getResource("images/samp.gif")).getImage());
        pack();
        Preferences.manageLocation(this);
        Preferences.manageSize(contentPane, new Dimension(550, 600), "sampStatus");
        setVisible(true);
    }

    /**
     * Close the window.
     */
    protected void closeWindowEvent() {
        this.dispose();
    }

    /**
     * Inner class defining Action for closing window.
     */
    protected class CloseAction extends AbstractAction {
        public CloseAction(String name, Icon icon) {
            super(name, icon);
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke("control W"));
        }

        public void actionPerformed(ActionEvent ae) {
            closeWindowEvent();
        }
    }
}
