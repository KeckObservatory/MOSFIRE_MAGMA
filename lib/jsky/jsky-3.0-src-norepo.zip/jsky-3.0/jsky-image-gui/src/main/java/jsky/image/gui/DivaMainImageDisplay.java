/*
 * ESO Archive
 *
 * $Id: DivaMainImageDisplay.java,v 1.10 2009/04/16 20:00:31 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/05/03  Created
 */

package jsky.image.gui;

import com.sun.media.jai.codec.BMPEncodeParam;
import com.sun.media.jai.codec.JPEGEncodeParam;
import com.sun.media.jai.codec.PNGEncodeParam;
import com.sun.media.jai.codec.PNMEncodeParam;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFEncodeParam;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import javax.swing.*;
import javax.swing.event.ChangeListener;

import jsky.coords.WorldCoordinateConverter;
import jsky.coords.WorldCoords;
import jsky.image.ImageChangeEvent;
import jsky.image.ImageProcessor;
import jsky.image.fits.codec.FITSImage;
import jsky.image.fits.gui.FITSHDUChooser;
import jsky.image.fits.gui.FITSHDUChooserFrame;
import jsky.image.fits.gui.FITSKeywordsFrame;
import jsky.image.graphics.MeasureBand;
import jsky.image.graphics.gui.CanvasDraw;
import jsky.image.graphics.gui.FITSGraphics;
import jsky.util.FileUtil;
import jsky.util.I18N;
import jsky.util.Preferences;
import jsky.util.SwingWorker;
import jsky.util.Resources;
import jsky.util.gui.DialogUtil;
import jsky.util.gui.ExampleFileFilter;
import jsky.util.gui.ProgressBarFilterInputStream;
import jsky.util.gui.ProgressException;
import jsky.util.gui.ProgressPanel;
import jsky.util.gui.SwingUtil;

import nom.tam.fits.FitsException;
import nom.tam.fits.ImageHDU;
import nom.tam.util.BufferedFile;

import diva.canvas.GraphicsPane;

/**
 * Implements the main image display window and provides methods
 * to implement each of the menu items in the ImageDisplayMenuBar class.
 *
 * @author Allan Brighton
 * @version $Revision: 1.10 $
 */
public class DivaMainImageDisplay extends DivaGraphicsImageDisplay implements MainImageDisplay {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(DivaMainImageDisplay.class);

    /**
     * Panel used to display download progress information
     */
    private ProgressPanel _progressPanel;

    /**
     * file chooser dialog
     */
    private JFileChooser _fileChooser;

    /**
     * Save dialog window
     */
    private ImageSaveDialog _saveDialog;

    /**
     * Print dialog window
     */
    private ImagePrintDialog _printDialog;

    /**
     * Name of image file, if any
     */
    private String _filename;

    /**
     * Set to true if the image has been modified and needs saving
     */
    private boolean _saveNeeded = false;

    /**
     * The URL for the image, if one was specified (after downloading, if possible)
     */
    private URL _url;

    /**
     * The original image URL (before downloading, for history)
     */
    private URL _origURL;

    /**
     * The base title string for the image frame
     */
    private String _title = _I18N.getString("imageDisplay");

    /**
     * Manages interactive drawing on the image canvas
     */
    private CanvasDraw _canvasDraw;

    /**
     * Top level frame for setting cut levels
     */
    private ImageCutLevelsFrame _imageCutLevelsFrame;

    /**
     * Top level frame for viewing the FITS keywords.
     */
    private FITSKeywordsFrame _fitsKeywordsFrame;

    /**
     * Top level frame for viewing image properties
     */
    private ImagePropertiesFrame _imagePropertiesFrame;

    /**
     * Top level frame for manipulating image colormaps
     */
    private ImageColorsFrame _imageColorsFrame;

    /**
     * Top level frame for selecting image objects (stars, galaxies)
     */
    private PickObjectFrame _pickObjectFrame;

    /**
     * Pick Object panel, if initialized
     */
    private PickObject _pickObjectPanel;

    /**
     * Top level window for manipulating FITS extensions
     */
    private FITSHDUChooserFrame _fitsHDUChooserFrame;

    /**
     * Panel for manipulating FITS extensions
     */
    private FITSHDUChooser _fitsHDUChooser;

    /**
     * Used to save graphics to a FITS table in the image and reload it again later.
     */
    private FITSGraphics _fitsGraphics;

    /**
     * Event passed to change listeners
     */
    private ImageChangeEvent _imageChangeEvent = new ImageChangeEvent(this);

    /**
     * Utility object used to control background thread
     */
    private SwingWorker _worker;

    // Manages the list of images previously viewed
    private ImageHistoryList _historyList;


    /**
     * Action to use for the "Open" menu and toolbar items
     */
    private AbstractAction _openAction = new AbstractAction(
            _I18N.getString("open"),
            Resources.getIcon("Open24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("imageOpenTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                open();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    // Action to use for the "Open URL..." menu and toolbar items
    private AbstractAction _openUrlAction = new AbstractAction(
            _I18N.getString("openURL")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("openURLTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            openURL();
        }
    };

    // Action to use for the "Clear" menu and toolbar items
    private AbstractAction _clearAction = new AbstractAction(
            _I18N.getString("clearImage")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("clearImageTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            clear();
        }
    };


    /**
     * Action to use for the "Save" menu and toolbar items
     */
    private AbstractAction _saveAction = new AbstractAction(
            _I18N.getString("save"),
            Resources.getIcon("Save24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("saveImageFileTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                save(true);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "Save as..." menu and toolbar items
     */
    private AbstractAction _saveAsAction = new AbstractAction(
            _I18N.getString("saveAs"),
            Resources.getIcon("SaveAs24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("saveAsImageFileTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                saveAs();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "Print Preview..." menu and toolbar items
     */
    private AbstractAction _printPreviewAction = new AbstractAction(
            _I18N.getString("printPreview"),
            Resources.getIcon("PrintPreview24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("printPreviewTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                printPreview();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "Print..." menu and toolbar items
     */
    private AbstractAction _printAction = new AbstractAction(
            _I18N.getString("print") + "...",
            Resources.getIcon("Print24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("prinTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                print();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "Cut Levels..." menu and toolbar items
     */
    private AbstractAction _cutLevelsAction = new AbstractAction(
            _I18N.getString("cutLevels"),
            Resources.getIcon("CutLevels24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("cutLevelsTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                editCutLevels();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "Colors..." menu and toolbar items
     */
    private AbstractAction _colorsAction = new AbstractAction(
            _I18N.getString("colors"),
            Resources.getIcon("Palette.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("colorsTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                editColors();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "FITS Extensions..." menu and toolbar items
     */
    private AbstractAction _fitsExtensionsAction = new AbstractAction(
            _I18N.getString("fitsExt"),
            Resources.getIcon("colmeta0.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("fitsExtTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                viewFitsExtensions();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Initialize with the given Diva GraphicsPane (contains the layers used to draw the image
     * and graphcs. Note that you need to call setParentFrame() if you use this version.
     *
     * @param pane the Diva GraphicsPane to use (contains the layers used to display the
     *             image and graphics)
     */
    public DivaMainImageDisplay(GraphicsPane pane) {
        super(pane, new ImageProcessor(), "Main Image");

        _historyList = new ImageHistoryList(this);
        setDownloadState(false);
        updateEnabledStates();

        new MeasureBand(this);
        _canvasDraw = new CanvasDraw(this);
        _fitsGraphics = new FITSGraphics(this);
    }

    /**
     * Default constructor. Note that you need to call setParentFrame() if you use this version).
     */
    public DivaMainImageDisplay() {
        this(new GraphicsPane());
    }


    /**
     * Open up another window like this one and return a reference to it.
     *
     * @return the new window
     */
    public ImageDisplayControlFrame newWindow() {
        ImageDisplayControlFrame f = new ImageDisplayControlFrame();
        f.getImageDisplayControl().getImageDisplay().setTitle(getTitle());
        f.setVisible(true);
        return f;
    }


    /**
     * @return the object that manages interactive drawing on the image
     */
    public CanvasDraw getCanvasDraw() {
        return _canvasDraw;
    }


    /**
     * Set the image file to display.
     */
    public void setFilename(String fileOrUrl) {
        if (fileOrUrl.startsWith("http:")) {
            setURL(FileUtil.makeURL(null, fileOrUrl));
            return;
        }
        if (fileOrUrl.startsWith("file:")) {
            fileOrUrl = FileUtil.makeURL(null, fileOrUrl).getPath();
        }
        if (!checkSave()) {
            return;
        }
        _canvasDraw.clear();

        _historyList.addToHistory();
        _filename = fileOrUrl;
        _url = _origURL = FileUtil.makeURL(null, fileOrUrl);

        // free up any previously opened FITS images
        FITSImage fitsImage = getFitsImage();
        if (fitsImage != null) {
            fitsImage.close();
            fitsImage.clearTileCache();
            clearFitsImage();
        }

        // load non FITS images with JAI, but try to load FITS files using the
        // the FITS I/O library, which is more efficient when using its own RandomAccess I/O
        if (isJAIImageType(_filename)) {
            try {
                setImage(JAI.create("fileload", _filename));
            } catch (Exception e) {
                DialogUtil.error(e);
                _filename = null;
                _url = _origURL = null;
                clear();
            }
        } else {
            try {
                fitsImage = new FITSImage(_filename);
                initFITSImage(fitsImage);
                setImage(fitsImage);
            } catch (Exception e) {
                // fall back to JAI method
                try {
                    setImage(JAI.create("fileload", _filename));
                } catch (Exception ex) {
                    DialogUtil.error(e);
                    _filename = null;
                    _url = _origURL = null;
                    clear();
                }
            }
        }
        updateTitle();
    }

    /**
     * Set the image file to display and use the given URL for the image history
     * (the URL is used if the file is deleted).
     */
    public void setFilename(String fileOrUrl, URL url) {
        setFilename(fileOrUrl);
        _origURL = url;
    }

    /**
     * Return the image file name, if there is one.
     */
    public String getFilename() {
        return _filename;
    }

    /**
     * @param filename the file name to check
     * @return true if the given filename has a suffix that indicates that it is
     *         not a FITS file and is one of the standard JAI supported image types.
     */
    public boolean isJAIImageType(String filename) {
        return filename.endsWith("jpg")
                || filename.endsWith("jpeg")
                || filename.endsWith("gif")
                || filename.endsWith("tif")
                || filename.endsWith("tiff")
                || filename.endsWith("ppm")
                || filename.endsWith("png")
                || filename.endsWith("pgm")
                || filename.endsWith("pnm")
                || filename.endsWith("bmp");
    }


    /**
     * Clear the image display.
     */
    public void clear() {
        super.clear();
        _canvasDraw.clear();
        updateEnabledStates();
    }

    /// These are implemented in a subclass 
    public void displayFITSTable(int hdu) {
    }

    public void deleteFITSTable(int hdu) {
    }


    /**
     * Return the name of the object being displayed, if known, otherwise null.
     */
    public String getObjectName() {
        FITSImage fitsImage = getFitsImage();
        if (fitsImage != null) {
            Object o = fitsImage.getKeywordValue("OBJECT");
            if (o instanceof String) {
                return o.toString();
            }
        }
        return null;
    }


    /**
     * Set the URL for the image to display. This method first tries to download the
     * URL to a temporary file, since files can be displayed more efficiently. If
     * that does not work, it tries to load the URL directly.
     */
    public void setURL(URL url) {
        _origURL = url;
        String s = url.getProtocol();
        if (s.equals("file")) {
            setFilename(url.getFile());
        } else if (s.equals("http")) {
            downloadImageToTempFile(url);
        } else {
            DialogUtil.error("Unsupported URL syntax: " + s);
        }
    }

    /**
     * Return the image URL, if there is one.
     */
    public URL getURL() {
        return _url;
    }


    /**
     * Called after a new FITSImage object was created to do FITS specific initialization
     *
     * @param fitsImage the new FITSImage object
     * @throws java.io.IOException        on read error
     * @throws nom.tam.fits.FitsException on FITS error
     */
    protected void initFITSImage(FITSImage fitsImage) throws IOException, FitsException {
        int numHDUs = fitsImage.getNumHDUs();
        if (numHDUs >= 2 && fitsImage.isEmpty() && (fitsImage.getHDU(1) instanceof ImageHDU)) {
            fitsImage.setHDU(1);
        }

        // If the user previously set the image scale, restore it here to avoid doing it twice
        ImageHistoryItem hi = _historyList.getImageHistoryItem(new File(_filename));
        float scale;
        if (hi != null) {
            scale = hi.scale;
            addChangeListener(hi); // This will restore the history settings for the image
        } else {
            scale = getScale();
        }
        if (scale != 1.0F) {
            fitsImage.setScale(scale);
        }
    }


    /**
     * Update the display to show the contents of the currently loaded image file.
     */
    public void updateImageData() {
        if (_filename != null) {
            setFilename(_filename);
        } else if (_url != null) {
            setURL(_url);
        }
    }


    /**
     * Make the download progress panel if needed, and display it
     */
    protected void initProgressPanel() {
        if (_progressPanel == null) {
            JFrame parent = SwingUtil.getFrame(this);
            _progressPanel = ProgressPanel.makeProgressPanel("Downloading image data ...", parent);
            _progressPanel.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    if (_worker != null) {
                        _worker.interrupt();
                        _worker = null;
                    }
                }
            });
        }
        _progressPanel.start();
    }


    /**
     * Load an image directly from the given URL in a separate thread, so the user can monitor progress
     * and cancel it, if needed.
     *
     * @param url points to the image file
     */
    protected void loadImageFromURL(final URL url) {
        if (!checkSave()) {
            return;
        }

        _historyList.addToHistory();
        _url = _origURL = url;
        _filename = null;
        initProgressPanel();

        _worker = new SwingWorker() {

            public Object construct() {
                setDownloadState(true);
                try {
                    ProgressBarFilterInputStream in = _progressPanel.getLoggedInputStream(url);
                    InputStream stream = SeekableStream.wrapInputStream(in, true);
                    setImage(JAI.create("stream", stream));
                } catch (Exception e) {
                    return e;
                }
                return null;
            }

            public void finished() {
                _progressPanel.stop();
                Object o = getValue();
                if ((o instanceof Exception) && !(o instanceof ProgressException)) {
                    DialogUtil.error((Exception) o);
                }
                setDownloadState(false);
                _worker = null;
            }
        };
        _worker.start();
    }


    /**
     * Download the given URL to a temporary file in a separate thread and then
     * display the image file when done.
     *
     * @param url points to the image file
     */
    protected void downloadImageToTempFile(final URL url) {
        //System.out.println("XXX downloadImageToTempFile: " + url);
        initProgressPanel();
        _worker = new SwingWorker() {

            String filename;

            public Object construct() {
                setDownloadState(true);
                try {
                    String dir = Preferences.getPreferences().getCacheDir().getPath();
                    File file = File.createTempFile("jsky", ".tmp", new File(dir));
                    //file.deleteOnExit();
                    ProgressBarFilterInputStream in = _progressPanel.getLoggedInputStream(url);
                    FileOutputStream out = new FileOutputStream(file);
                    FileUtil.copy(in, out);
                    in.close();
                    out.close();
                    filename = file.toString();
                } catch (Exception e) {
                    return e;
                }
                return null;
            }

            public void finished() {
                _progressPanel.stop();
                setDownloadState(false);
                _worker = null;
                Object o = getValue();
                if ((o instanceof Exception) && !(o instanceof ProgressException)) {
                    DialogUtil.error((Exception) o);
                    return;
                }
                if (!_progressPanel.isInterrupted()) {
                    setFilename(filename);
                }
            }

        };
        _worker.start();
    }


    /**
     * Set the state of the menubar/toolbar actions
     *
     * @param downloading set to true if an image is being downloaded
     */
    protected void setDownloadState(boolean downloading) {
        _historyList.setDownloadState(downloading);
        if (downloading) {
            _openAction.setEnabled(false);
        } else {
            _openAction.setEnabled(true);
        }
    }


    /**
     * Update the enabled states of some menu/toolbar actions.
     */
    protected void updateEnabledStates() {
        boolean fileLoaded = (_filename != null);
        boolean imageLoaded = (fileLoaded || _url != null);
        _saveAction.setEnabled(fileLoaded && _saveNeeded);
        _saveAsAction.setEnabled(imageLoaded);
        _cutLevelsAction.setEnabled(imageLoaded);
        _colorsAction.setEnabled(imageLoaded);
    }


    /**
     * If an image was previously loaded in this session with a center near the
     * given ra,dec coordinates, reload it, otherwise generate a blank image
     * with the center at those coordinates (in J2000).
     *
     * @param ra  the RA coordinate for the image (J2000)
     * @param dec the Dec coordinate for the image (J2000)
     * @return true if an image was loaded
     */
    public boolean loadCachedImage(double ra, double dec) {
        return _historyList.loadCachedImage(ra, dec);
    }


    /**
     * Add history items (for previously loaded images) to the given menu
     *
     * @param menu the target menu
     */
    public void addHistoryMenuItems(JMenu menu) {
        _historyList.addHistoryMenuItems(menu);
    }


    /**
     * register to receive change events from this object whenever the
     * image or cut levels are changed.
     */
    public void addChangeListener(ChangeListener l) {
        listenerList.add(ChangeListener.class, l);
    }


    /**
     * Stop receiving change events from this object.
     */
    public void removeChangeListener(ChangeListener l) {
        listenerList.remove(ChangeListener.class, l);
    }


    /**
     * Notify any listeners of a change in the image or cut levels.
     *
     * @param e the event
     */
    protected void fireChange(ImageChangeEvent e) {
        Object[] listeners = listenerList.getListenerList();
        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == ChangeListener.class) {
                ((ChangeListener) listeners[i + 1]).stateChanged(e);
            }
        }
        e.reset();
    }

    /**
     * @return true if this is the main application window (enables exit menu item)
     */
    public boolean isMainWindow() {
        return true;
    }

    /**
     * Exit the application (called from exit menu).
     */
    public void exit() {
        if (!checkSave()) {
            return;
        }
        System.exit(0);
    }


    /**
     * This method is called before and after a new image is loaded, each time
     * with a different argument.
     *
     * @param before set to true before the image is loaded and false afterwards
     */
    protected void newImage(boolean before) {
        super.newImage(before);
        if (!before) {
//            // If there are multiple images and/or tables in the image file, pop up
//            // a dialog to select one. (Wait a bit, in case main image window is not
//            // up yet.)
//            SwingUtilities.invokeLater(new Runnable() {
//                public void run() {
//                    checkExtensions(false);
//                }
//            });

            // check for graphics items saved in a FITS binary table named ".GRAPHICS"
            // (also produced by skycat)
            _fitsGraphics.loadGraphicsFromImage(".GRAPHICS");

            FITSImage fitsImage = getFitsImage();
            _fitsExtensionsAction.setEnabled(fitsImage != null && fitsImage.getNumHDUs() > 1);

            updateEnabledStates();
        }

        // notify listeners that a new image was (or will be) loaded
        _imageChangeEvent.setNewImage(true);
        _imageChangeEvent.setBefore(before);
        fireChange(_imageChangeEvent);
    }

    /**
     * This method updates the source image for this window, which is
     * scaled to the correct magnification before displaying.
     */
    protected void updateImage(PlanarImage im) {
        super.updateImage(im);
        if (im == null) {
            fireChange(_imageChangeEvent);
            return;
        }

        fireChange(_imageChangeEvent);
    }


    /**
     * Set the origin of the image to display in canvas coordinates.
     */
    public void setOrigin(Point2D.Double origin) {
        super.setOrigin(origin);
        _imageChangeEvent.setNewOrigin(true);
    }


    /**
     * Set the scale (zoom factor) for the image.
     * This also adjusts the origin so that the center of the image remains about the same.
     */
    public void setScale(float scale) {
        super.setScale(scale);
        _imageChangeEvent.setNewScale(true);
    }


    /**
     * If there are multiple images and/or tables in the image file, pop up
     * a dialog to select the one to display.
     *
     * @param show if true, always show the window, if there are any extensions,
     *             otherwise, just update the window if it is already showing
     *             or show it if the primary extension is empty.
     */
    public void checkExtensions(boolean show) {
        FITSImage fitsImage = getFitsImage();
        int numHDUs;
        if (fitsImage == null || (numHDUs = fitsImage.getNumHDUs()) <= 1) {
            if (_fitsHDUChooser != null) {
                _fitsHDUChooser.clear();
                _fitsHDUChooser.setShow(false);
            }
            return;
        }

        // Must be more than one FITS extension: update and show the window if it was already open
        if (!show) {
            show = (_fitsHDUChooserFrame != null && _fitsHDUChooserFrame.isVisible());
        }

        // check the primary HDU to see if it is empty
        int currentHDU = fitsImage.getCurrentHDUIndex();
        boolean skipEmptyPrimary = (numHDUs >= 2)
                && currentHDU == 0
                && fitsImage.isEmpty()
                && (fitsImage.getHDU(1) instanceof ImageHDU);

        if (!show) {
            show = skipEmptyPrimary && numHDUs > 2;
        }

        if (!show && numHDUs <= 1) {
            return;
        }

        // pop up a window to choose the HDU to view
        if (_fitsHDUChooser != null) {
            _fitsHDUChooser.updateDisplay(fitsImage);
        } else {
            _fitsHDUChooserFrame = new FITSHDUChooserFrame(this, fitsImage);
            _fitsHDUChooser = _fitsHDUChooserFrame.getFitsHDUChooser();
        }

        if (skipEmptyPrimary) {
            _fitsHDUChooser.selectImage(1);
        }

        _fitsHDUChooser.setShow(show);
    }


    /**
     * Save the current image graphics to a binary FITS table in the current image
     */
    public void saveGraphicsWithImage() {
        try {
            _fitsGraphics.saveGraphicsWithImage(".GRAPHICS");
            setSaveNeeded(true);
        } catch (Exception e) {
            DialogUtil.error(e);
        }
    }


    /**
     * Close the window
     */
    public void close() {
        if (isMainWindow()) {
            if (!checkSave()) {
                return;
            }
            dispose();
        } else {
            JFrame parent = SwingUtil.getFrame(this);
            if (parent != null) {
                parent.setVisible(false);
            }
        }
    }

    /**
     * Cleanup when the window is no longer needed.
     */
    public void dispose() {
        if (_imageCutLevelsFrame != null) {
            _imageCutLevelsFrame.dispose();
        }

        if (_imagePropertiesFrame != null) {
            _imagePropertiesFrame.dispose();
        }

        if (_imageColorsFrame != null) {
            _imageColorsFrame.dispose();
        }

        if (_pickObjectFrame != null) {
            _pickObjectFrame.dispose();
        }

        if (_fitsHDUChooserFrame != null) {
            _fitsHDUChooserFrame.dispose();
        }
        JFrame parent = SwingUtil.getFrame(this);
        if (parent != null) {
            parent.dispose();
        }
    }


    /**
     * Pop up a dialog window for displaying and setting the image cut levls.
     */
    public void editCutLevels() {
        if (_imageCutLevelsFrame != null) {
            SwingUtil.showFrame(_imageCutLevelsFrame);
        } else {
            _imageCutLevelsFrame = new ImageCutLevelsFrame(this);
        }
    }


    /**
     * Pop up a dialog window for displaying and setting the image colors.
     */
    public void editColors() {
        if (_imageColorsFrame != null) {
            SwingUtil.showFrame(_imageColorsFrame);
        } else {
            _imageColorsFrame = new ImageColorsFrame(this);
        }
    }


    /**
     * Pop up a dialog window to select objects (stars, galaxies) in the image
     */
    public void pickObject() {
        if (_pickObjectFrame != null) {
            SwingUtil.showFrame(_pickObjectFrame);
        } else {
            // create new frame
            _pickObjectFrame = new PickObjectFrame(this);
            _pickObjectPanel = _pickObjectFrame.getPickObject();
            _pickObjectPanel.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    pickedObject();
                }
            });
        }

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                _pickObjectPanel.pickObject();
            }
        });
    }

    /**
     * Called when an object is selected in the Pick Object window.
     */
    protected void pickedObject() {
    }


    /**
     * Pop up a dialog window for displaying a table of the FITS extensions
     */
    public void viewFitsExtensions() {
        FITSImage fitsImage = getFitsImage();
        if (fitsImage != null && fitsImage.getNumHDUs() > 1) {
            checkExtensions(true);
        } else {
            DialogUtil.error("There are no FITS extensions for this image.");
        }
    }

    /**
     * Pop up a dialog window for displaying the FITS Keywords.
     */
    public void viewFitsKeywords() {
        if (_fitsKeywordsFrame != null) {
            SwingUtil.showFrame(_fitsKeywordsFrame);
            _fitsKeywordsFrame.getFITSKeywords().updateDisplay();
        } else {
            _fitsKeywordsFrame = new FITSKeywordsFrame(this);
        }
    }

    /**
     * Pop up a dialog window for displaying the image properties.
     */
    public void viewImageProperties() {
        if (_imagePropertiesFrame != null) {
            SwingUtil.showFrame(_imagePropertiesFrame);
            _imagePropertiesFrame.getImageProperties().updateDisplay();
        } else {
            _imagePropertiesFrame = new ImagePropertiesFrame(this);
        }
    }

    /**
     * Display a file chooser to select a filename to display
     */
    public void open() {
        if (_fileChooser == null) {
            _fileChooser = makeImageFileChooser();
        }
        int option = _fileChooser.showOpenDialog(this);
        if (option == JFileChooser.APPROVE_OPTION && _fileChooser.getSelectedFile() != null) {
            setFilename(_fileChooser.getSelectedFile().getAbsolutePath());
        }
    }


    /**
     * Create and return a new file chooser to be used to select an image file
     * to display.
     *
     * @return the new file chooser
     */
    public static JFileChooser makeImageFileChooser() {
        JFileChooser fileChooser = new JFileChooser(new File("."));

        ExampleFileFilter fitsFilter = new ExampleFileFilter(new String[]{
                "fits", "fits.gz", "fits.Z", "hfits"}, "FITS Image Files");
        fileChooser.addChoosableFileFilter(fitsFilter);

        ExampleFileFilter jpgFilter = new ExampleFileFilter(new String[]{
                "jpg", "jpeg"}, "JPEG Compressed Image Files");
        fileChooser.addChoosableFileFilter(jpgFilter);

        ExampleFileFilter gifFilter = new ExampleFileFilter("gif", "GIF Image Files");
        fileChooser.addChoosableFileFilter(gifFilter);

        ExampleFileFilter tifFilter = new ExampleFileFilter(new String[]{"tif", "tiff"}, "TIFF Image Files");
        fileChooser.addChoosableFileFilter(tifFilter);

        ExampleFileFilter ppmFilter = new ExampleFileFilter(new String[]{"ppm", "png", "pgm"}, "PPM Image Files");
        fileChooser.addChoosableFileFilter(ppmFilter);

        fileChooser.setFileFilter(fitsFilter);

        return fileChooser;
    }


    /**
     * Display a dialog to enter a URL to display
     */
    public void openURL() {
        String urlStr = DialogUtil.input("Enter the World Wide Web location (URL) to display:");
        if (urlStr != null) {
            URL url;
            try {
                url = new URL(urlStr);
            } catch (Exception e) {
                DialogUtil.error(e);
                return;
            }
            setURL(url);
        }
    }

    // used below to avoid a calling while in progress
    private boolean _inBlankImage = false;

    /**
     * Display a blank image with the given center coordinates
     * (15' * 60 seconds/minutes).
     *
     * @param ra  RA center coordinate in deg J2000
     * @param dec Dec center coordinate in deg J2000
     */
    public void blankImage(double ra, double dec) {
        if (!_inBlankImage) {
            _inBlankImage = true;
            try {
                if (!checkSave()) {
                    return;
                }
                _historyList.addToHistory();
                _filename = null;
                _url = null;
                _origURL = null;
                super.blankImage(ra, dec);
                updateEnabledStates();
            } finally {
                _inBlankImage = false;
            }
        }
    }


    /**
     * Set to true if the image file has been modified and needs saving.
     */
    public void setSaveNeeded(boolean b) {
        _saveNeeded = b;
        updateEnabledStates();

        // fire a change event for the edit state
        _imageChangeEvent.setEditStateChanged(true);
        fireChange(_imageChangeEvent);
    }

    /**
     * @return true if the image file has been modified and needs saving.
     */
    public boolean isSaveNeeded() {
        return _saveNeeded;
    }


    /**
     * If the current image file has been modified (by adding or deleting a FITS extension,
     * for example), ask the user to confirm saving it.
     *
     * @return false if the user pressed Cancel when asked to save the file,
     *         otherwise true
     */
    public boolean checkSave() {
        if (_saveNeeded) {
            String s = _filename;
            if (s != null) {
                s = new File(s).getName(); // don't display the full path
            } else {
                if (_url != null) {
                    s = _url.toString();
                } else {
                    s = "unknown";
                }
            }
            int ans = DialogUtil.confirm("Save changes to '" + s + "'?");
            if (ans == JOptionPane.YES_OPTION) {
                save(false);
            } else if (ans == JOptionPane.CANCEL_OPTION) {
                return false;
            }

            setSaveNeeded(false);
        }
        return true;
    }


    /**
     * Save any changes to the current image file.
     *
     * @param reload if true, reload the image from the file after saving
     */
    public void save(boolean reload) {
        if (_filename != null) {
            saveAs(_filename, reload);
        } else {
            saveAs();
        }
    }


    /**
     * Pop up a dialog to ask the user for a file name, and then save the image
     * to the selected file.
     */
    public void saveAs() {
        if (_saveDialog == null) {
            _saveDialog = new ImageSaveDialog(this);
        }
        _saveDialog.save();
    }

    /**
     * Save the current image to the given file, using an image format
     * based on the file suffix, which should be one of ".fits", ".jpg",
     * ".png", or ".tif".
     *
     * @param filename the name of the file to save to
     * @param reload   if true, reload the image from the file after saving
     */
    public void saveAs(String filename, boolean reload) {
        String s = filename.toLowerCase();
        String tmpFile = filename + ".TMP";

        // under windows, an existing file must first be deleted?
        File tf = new File(tmpFile);
        if (tf.exists() && !tf.delete()) {
            DialogUtil.error("Can't delete temp file: " + tmpFile);
            return;
        }


        if (s.endsWith(".jpeg") || s.endsWith(".jpg")) {
            JAI.create("filestore", getDisplayImage(), tmpFile, "JPEG", new JPEGEncodeParam());
        } else if (s.endsWith(".png")) {
            JAI.create("filestore", getImage(), tmpFile, "PNG", new PNGEncodeParam.Gray());
        } else if (s.endsWith(".pnm")) {
            JAI.create("filestore", getImage(), tmpFile, "PNM", new PNMEncodeParam());
        } else if (s.endsWith(".tiff") || s.endsWith(".tif")) {
            JAI.create("filestore", getImage(), tmpFile, "TIFF", new TIFFEncodeParam());
        } else if (s.endsWith(".bmp")) {
            JAI.create("filestore", getDisplayImage(), tmpFile, "BMP", new BMPEncodeParam());
        } else {
            // assume FITS format
            FITSImage fitsImage = getFitsImage();
            if (fitsImage != null && _url != null) {
                try {
                    BufferedFile bf = new BufferedFile(tmpFile, "rw");
                    fitsImage.getFits().write(bf);
                    bf.close();

                    // under Windows, this is necessary to avoid an error
                    fitsImage.getFits().getStream().close();
                } catch (Exception e) {
                    DialogUtil.error(e);
                }
            } else {
                // XXX the FITS codec code for the call below is not implemented yet...
                // XXX wait for new Image I/O package
                //JAI.create("filestore", getImage(), tmpFile, "FITS", new FITSEncodeParam());

                DialogUtil.error("Can't determine image format for: " + filename);
            }
        }

        // backup file if it exists
        File file = new File(filename);
        if (file.exists()) {
            File backup = new File(filename + ".BAK");
            if (backup.exists() && !backup.delete()) {
                DialogUtil.error("Can't delete backup file: " + backup);
                return;
            }

            if (!file.renameTo(backup)) {
                DialogUtil.error("Rename " + file + " to " + backup + " failed");
                return;
            }
        }

        // Rename tmpFile to filename
        if (!new File(tmpFile).renameTo(file)) {
            DialogUtil.error("Rename " + tmpFile + " to " + file + " failed");
            return;
        }

        setSaveNeeded(false);

        if (reload) {
            // make sure we are viewing the new file
            _historyList.setNoStack(true);
            try {
                setFilename(filename);
            } catch (Exception e) {
                DialogUtil.error(e);
            }
            _historyList.setNoStack(false);
        }
    }


    /**
     * Paint the image and graphics to the given graphics object (for save and print features)
     */
    public void paintImageAndGraphics(Graphics2D g2D) {
        getCanvasPane().paint(g2D);
    }


    /**
     * Display a preview of the what the printed image view will look like.
     */
    public void printPreview() {
        if (_printDialog == null) {
            _printDialog = new ImagePrintDialog(this);
        }
        _printDialog.preview();
    }

    /**
     * Pop up a dialog for printing the image.
     */
    public void print() {
        try {
            if (_printDialog == null) {
                _printDialog = new ImagePrintDialog(this);
            }
            _printDialog.print();
        } catch (Exception e) {
            DialogUtil.error(e);
        }
    }

    /**
     * Set the frame's basic title string. (Other info, the file name, etc. may still be appended).
     *
     * @param s the basic title string
     */
    public void setTitle(String s) {
        _title = s;
        updateTitle();
    }

    /**
     * @return the frame's title.
     */
    public String getTitle() {
        return _title;
    }

    /**
     * Set the frame's title.
     */
    protected void updateTitle() {
        String s = _title;
        if (_filename != null) {
            s += " - " + new File(_filename).getName();
        }
        JFrame parent = getParentFrame();
        if (parent != null) {
            parent.setTitle(s);
        }
    }

    /**
     * @return the top level parent frame (used to close the window)
     */
    public JFrame getParentFrame() {
        return SwingUtil.getFrame(this);
    }

    // These are for the GenericToolBarTarget interface
    public AbstractAction getOpenAction() {
        return _openAction;
    }

    public AbstractAction getOpenUrlAction() {
        return _openUrlAction;
    }

    public AbstractAction getClearAction() {
        return _clearAction;
    }

    public AbstractAction getBackAction() {
        return _historyList.getBackAction();
    }

    public AbstractAction getForwAction() {
        return _historyList.getForwAction();
    }

    // Other menu actions
    public AbstractAction getColorsAction() {
        return _colorsAction;
    }

    public AbstractAction getFitsExtensionsAction() {
        return _fitsExtensionsAction;
    }

    public AbstractAction getCutLevelsAction() {
        return _cutLevelsAction;
    }

    public AbstractAction getSaveAction() {
        return _saveAction;
    }

    public AbstractAction getSaveAsAction() {
        return _saveAsAction;
    }

    public AbstractAction getPrintPreviewAction() {
        return _printPreviewAction;
    }

    public AbstractAction getPrintAction() {
        return _printAction;
    }

    /**
     * @return the top level frame for setting cut levels
     */
    public ImageCutLevelsFrame getImageCutLevelsFrame() {
        return _imageCutLevelsFrame;
    }

    /**
     * @return the top level frame for viewing the FITS keywords.
     */
    public FITSKeywordsFrame getFitsKeywordsFrame() {
        return _fitsKeywordsFrame;
    }

    /**
     * @return the top level frame for viewing image properties
     */
    public ImagePropertiesFrame getImagePropertiesFrame() {
        return _imagePropertiesFrame;
    }

    /**
     * @return the top level frame for manipulating image colormaps
     */
    public ImageColorsFrame getImageColorsFrame() {
        return _imageColorsFrame;
    }

    /**
     * @return the top level frame for selecting image objects (stars, galaxies)
     */
    public PickObjectFrame getPickObjectFrame() {
        return _pickObjectFrame;
    }

    /**
     * @return the Pick Object panel, if initialized
     */
    public PickObject getPickObjectPanel() {
        return _pickObjectPanel;
    }

    /**
     * @return the top level frame for manipulating FITS extensions
     */
    public FITSHDUChooserFrame getFitsHDUChooserFrame() {
        return _fitsHDUChooserFrame;
    }

    /**
     * @return the panel for manipulating FITS extensions
     */
    public FITSHDUChooser getFitsHDUChooser() {
        return _fitsHDUChooser;
    }

    /**
     * @return the object used to save graphics to a FITS table in the image and reload it again later.
     */
    public FITSGraphics getFitsGraphics() {
        return _fitsGraphics;
    }

    /**
     * Return the default min and max search radius to use for catalog searches, in arcmin.
     *
     * @param centerPos    the center position for the radius
     * @param useImageSize if true, use the image size to get the search radius
     * @return an array containing the min and max radius values
     */
    public double[] getDefaultSearchRadius(WorldCoords centerPos, boolean useImageSize) {
        Point2D.Double p1 = new Point2D.Double(1., 1.);
        WorldCoordinateConverter wcs = getWCS();
        wcs.imageToWorldCoords(p1, false);
        double equinox = wcs.getEquinox();
        WorldCoords origin = new WorldCoords(p1, equinox);

        double maxRadius = centerPos.dist(origin);
        return new double[]{0., maxRadius};
    }

    /**
     * Return the default min and max magnitude values to use for catalog searches, or null
     * if there is no default.
     *
     * @return an array containing the min and max mag values
     */
    public double[] getDefaultSearchMagRange() {
        return null; // no defaults here
    }

    /**
     * If the image was downloaded from an image server, this method returns the original URL used.
     *
     * @return the original image URL
     */
    public URL getOrigURL() {
        return _origURL;
    }

    /**
     * Clears the history list
     */
    public void clearHistory() {
        _historyList.clearHistory();
    }

}


