// $Id: CoordsGridLayer.java,v 1.3 2009/04/21 13:31:17 abrighto Exp $

//package alma.obsprep.guiutil.jsky.navigator;
package jsky.image.graphics;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jsky.coords.CoordinateConverter;
import jsky.coords.DMS;
import jsky.coords.HMS;
import jsky.image.gui.MainImageDisplay;
import diva.canvas.CanvasLayer;
import diva.canvas.VisibleComponent;

/**
 * A class of layer to draw coorinate grids.
 * Grid lines are drawn as contour lines.
 *
 * @author yatagai
 * @version $Revision: 1.3 $
 */
public class CoordsGridLayer extends CanvasLayer implements VisibleComponent {

    /**
     * true if the image contains one of the pole (Dec = 90[deg] or -90[deg])
     */
    boolean polar = false;

    /**
     * coordinates are calculated every NSKIP pixels
     */
    protected final int NSKIP = 10;

    private MainImageDisplay imageDisplay;
    private ContourPlot contour;

    /**
     * for the VisibleComponent interface
     */
    private boolean visible = false;

    /**
     * The constructor
     */
    public CoordsGridLayer() {
        contour = new ContourPlot();
    }

    /**
     * @param imageDisplay
     */
    public void setImageDisplay(MainImageDisplay imageDisplay) {
        this.imageDisplay = imageDisplay;
    }

    /* (non-Javadoc)
     * @see diva.canvas.VisibleComponent#paint(java.awt.Graphics2D)
     */
    public void paint(Graphics2D g) {
        paintGrid(g);
    }

    /* (non-Javadoc)
     * @see diva.canvas.VisibleComponent#paint(java.awt.Graphics2D, java.awt.geom.Rectangle2D)
     */
    public void paint(Graphics2D g, Rectangle2D region) {
        paintGrid(g);
    }

    /* (non-Javadoc)
     * @see diva.canvas.VisibleComponent#isVisible()
     */
    public boolean isVisible() {
        return visible;
    }

    /* (non-Javadoc)
     * @see diva.canvas.VisibleComponent#setVisible(boolean)
     */
    public void setVisible(boolean b) {
        visible = b;
    }

    /**
     * The main part of drawing / erasing grid lines
     *
     * @param g
     */
    public void paintGrid(Graphics2D g) {
        if (!isVisible() || !imageDisplay.isWCS()) {
            return;
        }

        Point2D size = getCanvasPane().getSize();
        Dimension d = new Dimension((int) size.getX(), (int) size.getY());
        int x = (int) size.getX();
        int y = (int) size.getY();
        int nx = x / NSKIP + 1;
        int ny = y / NSKIP + 1;
        double lon[][] = new double[ny][nx];
        double lat[][] = new double[ny][nx];
        List<Double> lonLevels = new ArrayList<Double>();
        List<Double> latLevels = new ArrayList<Double>();

        calcCoords(lon, lat, lonLevels, latLevels);

        double lonArr[] = new double[lonLevels.size()];
        String lonLabels[] = new String[lonLevels.size()];
        for (int i = 0; i < lonArr.length; i++) {
            lonArr[i] = lonLevels.get(i);
            double v = (lonArr[i] >= 0 ? lonArr[i] : lonArr[i] + 360);
            lonLabels[i] = (new HMS(v / 15.0)).toString();
        }
        double latArr[] = new double[latLevels.size()];
        String latLabels[] = new String[latLevels.size()];
        for (int i = 0; i < latArr.length; i++) {
            latArr[i] = latLevels.get(i);
            latLabels[i] = (new DMS(latArr[i])).toString();
        }

        if (polar) {
            drawRadial(g);
        } else {
            contour.setData(lon, lonArr, lonLabels);
            contour.paint(g, d);
        }
        contour.setData(lat, latArr, latLabels);
        contour.paint(g, d);
    }

    /**
     * Calculate coordinates used to draw lines as contours
     *
     * @param lon
     * @param lat
     * @param lonLevels
     * @param latLevels
     */
    private void calcCoords(double[][] lon, double[][] lat, List<Double> lonLevels, List<Double> latLevels) {
        CoordinateConverter converter = imageDisplay.getCoordinateConverter();
        Point2D.Double p;
        double plon, plat;
        Point2D size = getCanvasPane().getSize();
        int nx = lon[0].length;
        int ny = lon.length;
        int x, y;
        for (int iy = 0; iy < ny; iy++) {
            for (int ix = 0; ix < nx; ix++) {
                x = (int) size.getX() * ix / (nx - 1);
                y = (int) size.getY() * iy / (ny - 1);
                p = new Point2D.Double(x, y);
                converter.screenToWorldCoords(p, false);
                plon = p.getX();
                plat = p.getY();
                lon[iy][ix] = plon;
                lat[iy][ix] = plat;
            }
        }

        calcLevels(lon, lonLevels, true);
        calcLevels(lat, latLevels, false);
    }

    /**
     * Drawing longitude lines when the images contains one of the pole.
     * This is needed as the contouring can not handle properly for
     * such a case around [360,0] boundary.
     *
     * @param g
     */
    private void drawRadial(Graphics g) {
        double levels[] = {0.0, 45, 90.0, 135, 180.0, 215, 270.0, 305};
        CoordinateConverter converter = imageDisplay.getCoordinateConverter();
        Point2D size = getCanvasPane().getSize();
        int nx = (int) size.getX();
        int ny = (int) size.getY();
        double lon[][] = new double[ny][nx];
        double lat[][] = new double[ny][nx];
        Point2D.Double p;
        for (int iy = 0; iy < ny; iy++) {
            for (int ix = 0; ix < nx; ix++) {
                p = new Point2D.Double(ix, iy);
                converter.screenToWorldCoords(p, false);
                lon[iy][ix] = p.x;
                lat[iy][ix] = p.y;
            }
        }

        double maxlat = 0.0;
        int px = 0, py = 0;

        // to search the polar point
        for (int iy = 0; iy < ny; iy++) {
            for (int ix = 0; ix < nx; ix++) {
                if (Math.abs(lat[iy][ix]) > maxlat) {
                    maxlat = Math.abs(lat[iy][ix]);
                    px = ix;
                    py = iy;
                }
            }
        }

        List<Point2D.Double> outerPoint = new ArrayList<Point2D.Double>();
        List<Double> outerLon = new ArrayList<Double>();
        int ix, iy;
        iy = 0;
        for (ix = 0; ix < nx; ix++) {
            outerPoint.add(new Point2D.Double(ix, iy));
            outerLon.add(lon[iy][ix]);
        }
        ix = nx - 1;
        for (iy = 0; iy < ny; iy++) {
            outerPoint.add(new Point2D.Double(ix, iy));
            outerLon.add(lon[iy][ix]);
        }
        iy = ny - 1;
        for (ix = nx - 1; ix >= 0; ix--) {
            outerPoint.add(new Point2D.Double(ix, iy));
            outerLon.add(lon[iy][ix]);
        }
        ix = 0;
        for (iy = ny - 1; iy >= 0; iy--) {
            outerPoint.add(new Point2D.Double(ix, iy));
            outerLon.add(lon[iy][ix]);
        }
        outerPoint.add(new Point2D.Double(0, 0));
        outerLon.add(lon[0][0]);

        for (double level : levels) {
            int index = where(outerLon, level);
            if (index != -1) {
                Point2D pt = outerPoint.get(index);
                g.drawLine(px, py, (int) pt.getX(), (int) pt.getY());
            }

        }
    }

    /**
     * Tell the pixel in the bounding of the display which has the
     * given longitude.
     *
     * @param lon
     * @param level
     * @return
     */
    private int where(List<Double> lon, double level) {
        Iterator<Double> it = lon.iterator();
        double prev = it.next();
        while (it.hasNext()) {
            Double elm = it.next();
            if (Math.abs(prev - elm) > 180.0) {
                if (prev > 180.0) {
                    prev = 0.0;
                } else {
                    prev = 360.0;
                }
            }
            if ((prev - level) * (elm - level) <= 0) {
                return lon.indexOf(elm);
            }
            prev = elm;
        }
        return -1;
    }

    /**
     * Calculates grid line levels
     *
     * @param data lon or lat
     * @param levels an ArrayList to contain the result
     * @param lon true if calculating levels for longitude
     */
    private void calcLevels(double data[][], List<Double> levels, boolean lon) {
        double max = -Double.MAX_VALUE;
        double min = Double.MAX_VALUE;
        boolean shifted = false;
        for (double[] d : data) {
            for (int ix = 0; ix < data[0].length; ix++) {
                max = Math.max(max, d[ix]);
                min = Math.min(min, d[ix]);
            }
        }

        if (lon) {
            polar = false;
            if ((max - min) > 180.0) {
                max = -Double.MAX_VALUE;
                min = Double.MAX_VALUE;
                double v, vv;
                for (int iy = 0; iy < data.length; iy++) {
                    for (int ix = 0; ix < data[0].length; ix++) {
                        vv = data[iy][ix];
                        v = (vv - 180 > 0 ? (vv - 360) : vv);
                        max = Math.max(max, v);
                        min = Math.min(min, v);
                        data[iy][ix] = v;
                    }
                }
                shifted = true;
            }
        }

        if (shifted && (max - min) > 180.0) {
            // include a polar point
            polar = true;
            return;
        }

        double digit = 1000.0;
        double range = (max - min) / digit;

        while (range < 1.0) {
            range *= 10.0;
            digit /= 10.0;
        }

        // the number of lines is determined here
        int n = (int) range;
        double step;
        switch (n) {
            case 1:
                step = 0.25;
                break;
            case 2:
                step = 0.5;
                break;
            case 3:
            case 4:
                step = 1.25;
                break;
            default:
                step = 2.5;
        }
        step *= digit;

        double level = (int) (min / step) * step;
        while (level < max) {
            levels.add(level);
            level += step;
        }
    }
}
