//package alma.obsprep.ot.editors.spatialvisual;
package jsky.image.graphics;

import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.RectangularShape;
import java.util.Iterator;

import diva.canvas.CanvasUtilities;
import diva.canvas.Figure;
import diva.canvas.FigureDecorator;
import diva.canvas.Site;
import diva.canvas.event.LayerEvent;
import diva.canvas.interactor.DragInteractor;
import diva.canvas.interactor.GrabHandle;
import diva.canvas.interactor.GrabHandleFactory;
import diva.canvas.interactor.Manipulator;

/**
 * A manipulator which attaches a grab handles to one of the bounds
 * of the child figure.  It renders the grab handle and
 * gives it a chance to intercept picks.
 * <p/>
 * This class is based on the diva.canvas.interactor.CircleManipulator.java
 *
 * @author yatagai
 * @version $Revision: 1.3 $
 */

public class RectangleManipulator extends Manipulator {

    // The geometry "helper"
//    private RectangleGeometry _geometry;

    /**
     * Construct a new manipulator that uses rectangular grab-handles.
     */
    public RectangleManipulator() {
        this(new RectangleGrabHandleFactory());
    }

    /**
     * Construct a new manipulator using the given grab-handle factory.
     * @param f used to make the grab handles
     */
    public RectangleManipulator(GrabHandleFactory f) {
        setGrabHandleFactory(f);
        setHandleInteractor(new Rotater());
    }

    /**
     * Return the geometry of this manipulator
     * @return the geometry
     */
    private RectangleGeometry getGeometry() {
        Figure child = getChild();
        if (child instanceof RotatableCanvasFigure) {
            return ((RotatableCanvasFigure)child).getGeometry();
        }
        return null;
    }

    /**
     * Create a new instance of this manipulator. The new
     * instance will have the same grab handle, and interactor
     * for grab-handles, as this one.
     */
    @Override
    public FigureDecorator newInstance(Figure f) {
        RectangleManipulator m = new RectangleManipulator();
        m.setGrabHandleFactory(getGrabHandleFactory());
        m.setHandleInteractor(getHandleInteractor());
        return m;
    }

    /**
     * Refresh the geometry. This adjusts the bounds of the geometry
     * to match the bounds of the child figure.
     */
    @Override
    public void refresh() {
        RectangleGeometry geometry = getGeometry();
        if (geometry != null) {
            geometry.refresh(getChild()); // XXX?
        }
    }

    /**
     * Set the child figure. If we have a grab-handle, lose it.
     * Then get a rectangle geometry object and create a grab-handle
     * on one of its sites.
     */
    @Override
    public void setChild(Figure child) {
        super.setChild(child);
        clearGrabHandles();

        // Process new child
        if (child != null) {
            // Create the geometry defining the sites
            RectangleGeometry geometry = getGeometry();
            if (geometry == null) {
                return;
            }
            Iterator i = geometry.sites();
            while (i.hasNext()) {
                // Create a grab handle and set up the interactor
                Site site = (Site) i.next();
                GrabHandle g = getGrabHandleFactory().createGrabHandle(site);
                g.setParent(this);
                g.setInteractor(getHandleInteractor());
                addGrabHandle(g);
            }

            // Move them where they should be - ?
            relocateGrabHandles();

//            // Set the minimum size
//            // TODO HY: this is bogus: set it in the interactor instead!
//            if (g != null) {
//                geometry.setMinimumSize(4 * g.getSize());
//            }

        }
    }

    /**
     * Implements rotation for image figures
     */
    protected static class Rotater extends DragInteractor {

        @Override
        public void translate(LayerEvent e, double dx, double dy) {

            AffineTransform af = new AffineTransform();

            GrabHandle grabHandle = (GrabHandle) e.getFigureSource();
            RectangleManipulator manipulator = (RectangleManipulator) grabHandle.getParent();
            RectangleGeometry geometry = manipulator.getGeometry();
            RotatableCanvasFigure roi = (RotatableCanvasFigure) manipulator.getChild();

            Point2D p = geometry.getRotateCenter();
            double cx = p.getX();
            double cy = p.getY();

            int id = grabHandle.getSite().getID();

            if (id == 0) {
                double x = e.getLayerX();
                double y = e.getLayerY();

                double x1 = x - dx - cx;
                double x2 = x - cx;
                double y1 = y - dy - cy;
                double y2 = y - cy;

                /////////////////////
                // Rotating Handle //
                /////////////////////
                double angle = Math.atan2(y2, x2) - Math.atan2(y1, x1);

                // Transform the child.
                af.setToRotation(angle, cx, cy);
                roi.transform(af);

            } else if (roi.isResizable()) {
                ///////////////////
                // Resize Handle //
                ///////////////////
                RectangularShape r1 = (RectangularShape) geometry.getRect().clone();

                // translating the grab handle
                grabHandle.translate(dx, dy);

                // transform the child roi
                RectangularShape r2 = geometry.getRect();
                double angle = geometry.getRotateAngle();
                af.concatenate(AffineTransform.getRotateInstance(angle, cx, cy));
                af.concatenate(CanvasUtilities.computeTransform(r1, r2));
                af.concatenate(AffineTransform.getRotateInstance(-angle, cx, cy));
                roi.transform(af);
            }
        }
    }
}

