// $Id: RectangleGrabHandleFactory.java,v 1.2 2009/03/30 11:56:38 abrighto Exp $

package jsky.image.graphics;

import diva.canvas.Site;
import diva.canvas.interactor.GrabHandle;
import diva.canvas.interactor.GrabHandleFactory;

// copied from diva.canvas.interactor.BasicGrabhandleFactory
/**
 * A factory that creates grab-handles for rotatable rectangles.
 *
 * @version $Revision: 1.2 $
 * @author yatagai
 *
 */

public class RectangleGrabHandleFactory implements GrabHandleFactory {
    public GrabHandle createGrabHandle(Site s) {
    	if (s.getID() == 0)
    		return new RectangleGrabHandle(s, java.awt.Color.green);
    	else
    		return new RectangleGrabHandle(s, java.awt.Color.blue);
    }
}


