/*
 * $Id: SelectedAreaListener.java,v 1.2 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.graphics;

import java.awt.geom.Rectangle2D;
import java.util.EventListener;

/**
 * This defines the interface for listening for area selection events.
 *
 * @version $Revision: 1.2 $
 * @author Allan Brighton
 */
public abstract interface SelectedAreaListener extends EventListener {

    /**
     * Invoked when an area of the canvas has been dragged out.
     */
    public void setSelectedArea(Rectangle2D r);

}
