/*
 * $Id: FITSKeywordsFrame.java,v 1.2 2009/04/21 13:31:17 abrighto Exp $
 */


package jsky.image.fits.gui;

import java.awt.BorderLayout;
import javax.swing.JFrame;

import jsky.image.gui.MainImageDisplay;
import jsky.util.Preferences;


/**
 * Provides a top level window for an FITSKeywords panel.
 *
 * @version $Revision: 1.2 $
 * @author Allan Brighton
 */
public class FITSKeywordsFrame extends JFrame {

    private FITSKeywords fitsKeywords;


    /**
     * Create a top level window containing an FITSKeywords panel.
     */
    public FITSKeywordsFrame(MainImageDisplay imageDisplay) {
        super("FITS Keywords");
        fitsKeywords = new FITSKeywords(imageDisplay);
        getContentPane().add(fitsKeywords, BorderLayout.CENTER);
        pack();
        Preferences.manageLocation(this);
        setVisible(true);
        setDefaultCloseOperation(HIDE_ON_CLOSE);

    }

    /**
     * Update the display from the current image
     */
    public void updateDisplay() {
        fitsKeywords.updateDisplay();
    }

    /** Return the internal panel object */
    public FITSKeywords getFITSKeywords() {
        return fitsKeywords;
    }
}

