/*
 * $Id: FITSGraphics.java,v 1.8 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.image.graphics.gui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import java.util.ListIterator;
import java.util.List;
import java.util.ArrayList;

import jsky.coords.CoordinateConverter;
import jsky.graphics.CanvasFigure;
import jsky.image.fits.codec.FITSImage;
import jsky.image.graphics.DivaImageGraphics;
import jsky.image.graphics.ImageFigure;
import jsky.image.graphics.ImageLabel;
import jsky.image.graphics.RoiFigure;
import jsky.image.gui.DivaMainImageDisplay;
import jsky.util.TclUtil;
import jsky.util.gui.DialogUtil;

import nom.tam.fits.BasicHDU;
import nom.tam.fits.BinaryTable;
import nom.tam.fits.BinaryTableHDU;
import nom.tam.fits.Fits;
import nom.tam.fits.FitsException;
import nom.tam.fits.FitsFactory;
import nom.tam.fits.Header;
import nom.tam.fits.TableHDU;

import diva.canvas.Figure;
import diva.canvas.interactor.Interactor;
import diva.util.java2d.Polygon2D;
import diva.util.java2d.Polyline2D;


/**
 * This class allows you to save the current image graphics to a FITS binary table and
 * reload it again later.
 *
 * @author Allan Brighton
 * @version $Revision: 1.8 $
 */
public class FITSGraphics {

    /**
     * The target image display.
     */
    protected DivaMainImageDisplay imageDisplay;

    /**
     * Object managing image graphics
     */
    protected DivaImageGraphics graphics;

    /**
     * User interface object managing a list of graphics objects.
     */
    protected CanvasDraw canvasDraw;

    /**
     * Maps a skycat pattern (pat0..15) index to CanvasDraw composite index
     */
    protected static final int[] PATTERNS = {
            10, 9, 8, 6, 4, 2, 1, 0, 9, 8, 7, 6, 5, 4, 3, 1
    };


    /**
     * Initialize with the image display object.
     *
     * @param imageDisplay used to access the JCanvas and DivaImageGraphics objects
     */
    public FITSGraphics(DivaMainImageDisplay imageDisplay) {
        this.imageDisplay = imageDisplay;
        graphics = (DivaImageGraphics) imageDisplay.getCanvasGraphics();
        canvasDraw = imageDisplay.getCanvasDraw();
    }


    /**
     * Save the current image graphics to a binary FITS table with the given name
     * in the current image.
     */
    public void saveGraphicsWithImage(String extName) throws FitsException {
        FITSImage fitsImage = imageDisplay.getFitsImage();
        if (fitsImage == null) {
            DialogUtil.error("Graphics can only be saved in a FITS image");
            return;
        }

        List<Figure> figureList = canvasDraw.getFigureList();
        int n = figureList.size();
        List<String> typeList = new ArrayList<String>(n);
        List<String> coordList = new ArrayList<String>(n);
        List<String> configList = new ArrayList<String>(n);

        ListIterator it = figureList.listIterator(0);
        int i = 0;
        while (it.hasNext()) {
            CanvasFigure cfig = (CanvasFigure) it.next();
            if (cfig instanceof ImageFigure) {
                ImageFigure fig = (ImageFigure) cfig;
                Shape shape = fig.getShape();
                Paint fill = fig.getFillPaint();
                Paint outline = fig.getStrokePaint();
                float lineWidth = fig.getLineWidth();
                Composite composite = fig.getComposite();
                try {
                    String type = getType(shape);
                    String coords = getCoords(shape);
                    String config = getConfig(fill, outline, (int) lineWidth, composite);
                    typeList.add(type);
                    coordList.add(coords);
                    configList.add(config);
                } catch (Exception e) {
                    continue; // ignore unsupported figures
                }
            } else if (cfig instanceof ImageLabel) {
                ImageLabel fig = (ImageLabel) cfig;
                Font font = fig.getFont();
                String text = fig.getString();
                Paint fill = fig.getFillPaint();
                typeList.add("text");
                coordList.add(getCoords((Point2D.Double) fig.getAnchorPoint()));
                configList.add(getConfig(text, font, fill));
            }
            i++;
        }

        Fits fits = fitsImage.getFits();
        _deleteBinaryTable(fits, extName);
        BinaryTable table = new BinaryTable();
        FitsFactory.setUseAsciiTables(false);
        table.addColumn(typeList.toArray(new String[typeList.size()]));
        table.addColumn(coordList.toArray(new String[coordList.size()]));
        table.addColumn(configList.toArray(new String[configList.size()]));
        BinaryTableHDU hdu = (BinaryTableHDU) Fits.makeHDU(table);
        hdu.getHeader().addValue("EXTNAME", extName, "Contains saved JSkyCat graphics");
        hdu.setColumnName(0, "type", null);
        hdu.setColumnName(1, "coords", null);
        hdu.setColumnName(2, "config", null);
        deleteHDU(extName);
        fits.addHDU(hdu);
        imageDisplay.checkExtensions(true);
    }

    /**
     * Deletes the existing FITS binary table with the given name.
     *
     * @param fits    the FITS image
     * @param extName the name of the FITS binary table
     */
    private void _deleteBinaryTable(Fits fits, String extName) {
        int n = fits.getNumberOfHDUs();
        for (int i = 0; i < n; i++) {
            try {
                BasicHDU hdu = fits.getHDU(i);
                if (hdu instanceof BinaryTableHDU) {
                    if (extName.equals(hdu.getHeader().getStringValue("EXTNAME"))) {
                        fits.deleteHDU(i);
                        break;
                    }
                }
            } catch (Exception ignore) {
            }
        }
    }


    /**
     * If a binary table with the given name is found in the current image,
     * load the previously saved image graphics from it.
     *
     * @param extName the name of the FITS table holding the graphics info (".GRAPHICS")
     */
    public void loadGraphicsFromImage(String extName) {
        FITSImage fitsImage = imageDisplay.getFitsImage();
        if (fitsImage == null) {
            return;
        }
        int n = fitsImage.getNumHDUs();
        if (n <= 1) {
            return;
        }

        for (int i = 0; i < n; i++) {
            BasicHDU hdu = fitsImage.getHDU(i);
            if (hdu instanceof TableHDU) {
                Header header = hdu.getHeader();
                String name = header.getStringValue("EXTNAME");
                if (name != null && name.equals(extName)) {
                    try {
                        loadGraphicsFromImage((TableHDU) hdu);
                    } catch (Exception e) {
                        DialogUtil.error(e);
                    }
                    return;
                }
            }
        }
    }


    /**
     * Load previously saved graphics from the given FITS binary table.
     *
     * @param hdu the HDU of the FITS table holding the graphics information
     * @throws nom.tam.fits.FitsException on error
     */
    public void loadGraphicsFromImage(TableHDU hdu) throws FitsException {
        int nrows = hdu.getNRows();
        int ncols = hdu.getNCols();

        if (nrows <= 0) {
            return;
        }

        if (ncols < 3) {
            return;
        }

        // The table items are in Tcl list format, the graphics syntax was originally based on Tk, but has been extended
        // in the java version to support Path2D (path) and composites (for fill).
        for (int rowNum = 0; rowNum < nrows; rowNum++) {
            Object[] row = hdu.getRow(rowNum);

            // shape name
            String type = (String) row[0];

            // image coordinates
            double[] c = getCoords(TclUtil.splitList((String) row[1]));

            // item config
            String[] config = TclUtil.splitList((String) row[2]);

            Shape shape = null;
            Paint fill = null;
            Paint outline = Color.white;
            float lineWidth = 1;
            Composite composite = null;
            Font font = CanvasDraw.FONTS[3];
            String text = null;
            Interactor interactor = graphics.getRoiSelectionInteractor();

            // parse the configuration options: {-opt arg} {-opt arg} ...
            for (String aConfig : config) {
                String[] optArg = TclUtil.splitList(aConfig);
                if (optArg.length != 2) {
                    continue;
                }
                if (optArg[0].equals("-fill")) {
                    fill = getColor(optArg[1]);
                } else if (optArg[0].equals("-outline")) {
                    outline = getColor(optArg[1]);
                } else if (optArg[0].equals("-width")) {
                    lineWidth = Float.parseFloat(optArg[1]);
                } else if (optArg[0].equals("-font")) {
                    font = getFont(optArg[1]);
                } else if (optArg[0].equals("-text")) {
                    text = optArg[1];
                } else if (optArg[0].equals("-stipple")) {
                    composite = getStipple(optArg[1]);
                } else if (optArg[0].equals("-composite")) {
                    composite = getComposite(optArg[1]);
                }
            }

            // parse the shape
            if ("rectangle".equals(type)) {
                // rectangle x1 y1 x2 y2
                shape = getRectangle(c);
            } else if ("oval".equals(type)) {
                // oval x1 y1 x2 y2
                shape = getEllipse(c);
            } else if (type.equals("line")) {
                // line x1 y1... xn yn
                if (outline == null) {
                    outline = fill;
                }
                fill = null;
                shape = getPolyline(c);
                if (((Polyline2D)shape).getVertexCount() == 2) {
                    interactor = graphics.getLineInteractor();
                }
            } else if ("polygon".equals(type)) {
                // polygon x1 y1 ... xn yn
                shape = getPolygon(c);
            } else if ("text".equals(type) && text != null) {
                // text x y
                c = imageToScreenCoords(c);
                Point2D.Double pos = new Point2D.Double(c[0], c[1]);
                ImageLabel fig = new ImageLabel(text, pos, fill, font, graphics.getSelectionInteractor());
                canvasDraw.addFigure(fig);
            } else if ("path".equals(type)) {
                shape = getPath(c);
            }

            if (shape != null) {
//                ImageFigure fig = new ImageFigure(shape, fill, outline, lineWidth, interactor);
                RoiFigure fig = new RoiFigure(shape, fill, outline, lineWidth, interactor);
                if (composite != null) {
                    fig.setComposite((AlphaComposite) composite);
                }
                canvasDraw.addFigure(fig);
            }
        }
    }

    /**
     * @param coords x, y, width, height, in image coordinates
     * @return a screen coordinate rectangle for the given image coordinates
     */
    protected Rectangle2D.Double getRectangle(double[] coords) {
        double[] c = imageToScreenCoords(coords);
        return new Rectangle2D.Double(c[0], c[1], c[2] - c[0], c[3] - c[1]);
    }

    /**
     * @param coords x, y, width, height, in image coordinates
     * @return a screen coordinate ellipse for the given image coordinates
     */
    protected Ellipse2D.Double getEllipse(double[] coords) {
        double[] c = imageToScreenCoords(coords);
        return new Ellipse2D.Double(c[0], c[1], c[2] - c[0], c[3] - c[1]);
    }

    /**
     * @param coords x0,y0, x1,y1, ..., in image coordinates
     * @return a screen coordinate polyline for the given image coordinates
     */
    protected Polyline2D.Double getPolyline(double[] coords) {
        double[] c = imageToScreenCoords(coords);
        // line x1 y1... xn yn
        if (c.length == 4) {
            return new Polyline2D.Double(c[0], c[1], c[2], c[3]);
        }
        if (c.length > 4) {
            Polyline2D.Double p = new Polyline2D.Double(c.length);
            p.moveTo(c[0], c[1]);
            for (int i = 2; i < c.length; i += 2) {
                p.lineTo(c[i], c[i + 1]);
            }
            return p;
        }
        return null;
    }

    /**
     * @param coords x0,y0, x1,y1, ..., in image coordinates
     * @return a screen coordinate polygon for the given image coordinates
     */
    protected Polygon2D.Double getPolygon(double[] coords) {
        double[] c = imageToScreenCoords(coords);
        Polygon2D.Double p = new Polygon2D.Double(c.length);
        p.moveTo(c[0], c[1]);
        for (int i = 2; i < c.length; i += 2) {
            p.lineTo(c[i], c[i + 1]);
        }
        return p;
    }

    /**
     * @param coords <type> x0,y0, x1,y1, ..., where type is one of the path iterator types (SEG_LINETO, SEQ_QUADTO, ...)
     *               and x0,y0, x1,y1, ... are the coordinates of the segment (there can be multiple segments)
     * @return a screen coordinate Path2D for the given array, which is based on image coordinates
     */
    protected Path2D.Double getPath(double[] coords) {
        Path2D.Double p = new Path2D.Double();
        for (int i = 0; i < coords.length; i++) {
            int subPathType = (int) coords[i];
            if (subPathType == PathIterator.SEG_MOVETO) {
                double[] c = imageToScreenCoords(coords, i + 1, 2);
                p.moveTo(c[0], c[1]);
                i += 2;
            } else if (subPathType == PathIterator.SEG_LINETO) {
                double[] c = imageToScreenCoords(coords, i + 1, 2);
                p.lineTo(c[0], c[1]);
                i += 2;
            } else if (subPathType == PathIterator.SEG_QUADTO) {
                double[] c = imageToScreenCoords(coords, i + 1, 4);
                p.quadTo(c[0], c[1], c[2], c[3]);
                i += 4;
            } else if (subPathType == PathIterator.SEG_CUBICTO) {
                double[] c = imageToScreenCoords(coords, i + 1, 6);
                p.curveTo(c[0], c[1], c[2], c[3], c[4], c[5]);
                i += 6;
            } else if (subPathType == PathIterator.SEG_CLOSE) {
                p.closePath();
            }
        }
        return p;
    }

    /**
     * Delete the table HDU with the given name, if found.
     */
    public void deleteHDU(String extName) {
        FITSImage fitsImage = imageDisplay.getFitsImage();
        int n = fitsImage.getNumHDUs();
        for (int i = 0; i < n; i++) {
            BasicHDU hdu = fitsImage.getHDU(i);
            if (hdu instanceof TableHDU) {
                Header header = hdu.getHeader();
                String name = header.getStringValue("EXTNAME");
                if (name != null && name.equals(extName)) {
                    try {
                        fitsImage.getFits().deleteHDU(i);
                    } catch (Exception e) {
                        DialogUtil.error(e);
                    }
                    return;
                }
            }
        }
    }


    /**
     * Converts the given String formatted array to doubles
     *
     * @param coords space separated values
     * @return array of doubles
     */
    protected double[] getCoords(String[] coords) {
        double[] c = new double[coords.length];
        for (int i = 0; i < c.length; i++) {
            c[i] = Double.parseDouble(coords[i]);
        }
        return c;
    }

    /**
     * Converts the given array of image coordinate pairs to screen coordinates and
     * return the new array.
     *
     * @param coords image coordinate pairs (x0,y0, x1,y1, ...)
     * @return screen coordinate array
     */
    protected double[] imageToScreenCoords(double[] coords) {
        return imageToScreenCoords(coords, 0, coords.length);
    }

    /**
     * Converts the given array of image coordinate pairs starting at the given offset to screen coordinates and
     * return the new array.
     *
     * @param coords image coordinate pairs (x0,y0, x1,y1, ...)
     * @param offset the index in the coords array of of the first value to convert
     * @param length the number of values to convert and include in the result
     * @return screen coordinate array of size "length"
     */
    protected double[] imageToScreenCoords(double[] coords, int offset, int length) {
        CoordinateConverter coordinateConverter = imageDisplay.getCoordinateConverter();
        double[] c = new double[length];
        Point2D.Double p = new Point2D.Double();

        for (int i = 0; i < length; i += 2) {
            p.x = coords[i + offset];
            p.y = coords[i + offset + 1];
            coordinateConverter.imageToScreenCoords(p, false);
            c[i] = p.x;
            c[i + 1] = p.y;
        }
        return c;
    }


    /**
     * Return a color for the given name
     */
    protected Color getColor(String s) {
        String[] ar = CanvasDraw.COLOR_NAMES;
        int n = ar.length - 1; // ignore null color at end
        for (int i = 0; i < n; i++) {
            if (ar[i].equals(s)) {
                return CanvasDraw.COLORS[i];
            }
        }
        if (s.startsWith("grey")) {
            // skycat used a number of gray levels, just use light and dark gray here
            try {
                int i = Integer.parseInt(s.substring(4));
                if (i > 50) {
                    return Color.lightGray;
                }
                return Color.darkGray;
            } catch (Exception ignored) {
            }
        }
        return Color.white;  // default to white
    }

    /**
     * Return the name of the given color
     */
    protected String getColorName(Color c) {
        Color[] ar = CanvasDraw.COLORS;
        int n = ar.length - 1; // ignore null color at end
        for (int i = 0; i < n; i++) {
            if (ar[i] == c) {
                return CanvasDraw.COLOR_NAMES[i];
            }
        }
        return "white";
    }


    /**
     * Return a font for the given name
     */
    protected Font getFont(String s) {
        return Font.decode(s);
    }

    /**
     * Return a composite for the given skycat stipple name (pat0..pat15)
     */
    protected Composite getStipple(String s) {
        if (s.startsWith("pat")) {
            // try one of the skycat patterns: pat0..pat15
            try {
                int i = Integer.parseInt(s.substring(3));
                return CanvasDraw.COMPOSITES[PATTERNS[i]];
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    /**
     * Return a composite for the given composite string as defined in CanvasDraw (0%,100%).
     */
    protected Composite getComposite(String s) {
        if (s.endsWith("%")) {
            for (int i = 0; i < CanvasDraw.COMPOSITE_NAMES.length; i++) {
                if (s.equals(CanvasDraw.COMPOSITE_NAMES[i])) {
                    return CanvasDraw.COMPOSITES[i];
                }
            }
        }
        return null;
    }

    /**
     * Return the name corresponding to the given composite.
     */
    protected String getCompositeName(Composite composite) {
        Composite[] ar = CanvasDraw.COMPOSITES;
        int n = ar.length;
        for (int i = 0; i < n; i++) {
            if (ar[i] == composite) {
                return CanvasDraw.COMPOSITE_NAMES[i];
            }
        }
        return CanvasDraw.COMPOSITE_NAMES[0];
    }


    /**
     * Return the Tk canvas item type name corresponding to the given shape.
     */
    protected String getType(Shape shape) {
        if (shape instanceof Rectangle2D) {
            return "rectangle";
        }
        if (shape instanceof Polyline2D) {
            return "line";
        }
        if (shape instanceof Ellipse2D) {
            return "oval";
        }
        if (shape instanceof Polygon2D) {
            return "polygon";
        }
        if (shape instanceof Path2D) {
            return "path";
        }
        throw new RuntimeException("Unsupported shape for saved graphics: " + shape);
    }

    /**
     * Returns the coordinates of the given screen coordinate shape as a string in
     * image coordinates. For rectangles and ellipses, this is: x y width height.
     * For Path2D, the integer path type is inserted before the coordinates of each segment.
     *
     * @param shape the shape in screen coordinates
     * @return a space separated list of image coordinate values for the given screen coordinate shape.
     */
    protected String getCoords(Shape shape) {
        double[] coords = null;
        if (shape instanceof RectangularShape) {
            RectangularShape r = (RectangularShape) shape;
            coords = new double[4];
            coords[0] = r.getX();
            coords[1] = r.getY();
            coords[2] = coords[0] + r.getWidth();
            coords[3] = coords[1] + r.getHeight();
            return convertCoords(coords, coords.length);
        }

        if (shape instanceof Polyline2D) {
            Polyline2D p = (Polyline2D) shape;
            int n = p.getVertexCount();
            coords = new double[n * 2];
            for (int i = 0; i < n; i++) {
                coords[i * 2] = p.getX(i);
                coords[i * 2 + 1] = p.getY(i);
            }
            return convertCoords(coords, coords.length);
        }

        if (shape instanceof Polygon2D) {
            Polygon2D p = (Polygon2D) shape;
            int n = p.getVertexCount();
            coords = new double[n * 2];
            for (int i = 0; i < n; i++) {
                coords[i * 2] = p.getX(i);
                coords[i * 2 + 1] = p.getY(i);
            }
            return convertCoords(coords, coords.length);
        }

        // For Path2D, the integer path type is inserted before the coordinates of each segment 
        if (shape instanceof Path2D) {
            Path2D p = (Path2D) shape;
            StringBuffer buf = new StringBuffer();
            coords = new double[6];
            PathIterator pathIter = p.getPathIterator(null);
            while (!pathIter.isDone()) {
                int subPathType = pathIter.currentSegment(coords);
                buf.append(subPathType).append(" ");
                if (subPathType == PathIterator.SEG_MOVETO || subPathType == PathIterator.SEG_LINETO) {
                    buf.append(convertCoords(coords, 2)).append(" ");
                } else if (subPathType == PathIterator.SEG_QUADTO) {
                    buf.append(convertCoords(coords, 4)).append(" ");
                } else if (subPathType == PathIterator.SEG_CUBICTO) {
                    buf.append(convertCoords(coords, 6)).append(" ");
                }
                pathIter.next();
            }
            return buf.toString();
        }

        throw new RuntimeException("Unsupported shape for saved graphics: " + shape);
    }

    /**
     * Converts the given screen coordinates to image coordinates and returns a string with the
     * results, where the values are separated by spaces.
     *
     * @param coords an array x,y of coordinate pairs in screen coordinates
     * @param length the number of coordinate values to process (the rest are ignored)
     * @return a string containing the coordinates separated by spaces
     */
    protected String convertCoords(double[] coords, int length) {
        CoordinateConverter coordinateConverter = imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double();
        for (int i = 0; i < length; i += 2) {
            p.x = coords[i];
            p.y = coords[i + 1];
            coordinateConverter.screenToImageCoords(p, false);
            coords[i] = p.x;
            coords[i + 1] = p.y;
        }

        // convert to Tcl list format
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < length; i++) {
            buf.append(Double.toString(coords[i])).append(' ');
        }
        return buf.toString();
    }

    /**
     * Return a Tcl formatted (space separated) list of two image coordinate values
     * for the given screen coordinate point.
     */
    protected String getCoords(Point2D.Double p) {
        CoordinateConverter coordinateConverter = imageDisplay.getCoordinateConverter();
        coordinateConverter.screenToImageCoords(p, false);
        return Double.toString(p.getX()) + " " + Double.toString(p.getY());
    }

    /**
     * Return a Tcl formatted list of Tk canvas item style configuration options
     * and values for the given arguments.
     * <p/>
     * Example "{-fill red} {-outline black} {-width 2} {-composite 20%}"
     * <p/>
     * Note: the return value is Tk canvas "style", but may contain other options,
     * such as -composite.
     */
    protected String getConfig(Paint fill, Paint outline, int lineWidth, Composite composite) {
        StringBuffer buf = new StringBuffer();
        if (fill != null) {
            buf.append("{-fill ");
            buf.append(getColorName((Color) fill));
            buf.append("} ");
        }
        if (outline != null) {
            buf.append("{-outline ");
            buf.append(getColorName((Color) outline));
            buf.append("} ");
        }
        if (lineWidth != 1) {
            buf.append("{-width ");
            buf.append(Integer.toString(lineWidth));
            buf.append("} ");
        }
        if (composite != null) {
            buf.append("{-composite ");
            buf.append(getCompositeName(composite));
            buf.append("} ");
        }
        return buf.toString();
    }

    /**
     * Return a Tcl formatted list of Tk canvas item style configuration options
     * and values for the given arguments.
     * <p/>
     * Example "{-text {some text}} {-font Dialog-italic-14} {-fill white}"
     */
    protected String getConfig(String text, Font font, Paint fill) {
        StringBuffer buf = new StringBuffer();
        if (text != null) {
            buf.append("{-text {");
            buf.append(text);
            buf.append("}} ");
        }
        if (font != null) {
            buf.append("{-font {");
            String style = font.isItalic() ? "italic" : (font.isBold() ? "bold" : "plain");
            buf.append(font.getFontName()).append("-").append(style).append("-").append(font.getSize());
            buf.append("}} ");
        }
        if (fill != null) {
            buf.append("{-fill ");
            buf.append(getColorName((Color) fill));
            buf.append("} ");
        }
        return buf.toString();
    }

}

