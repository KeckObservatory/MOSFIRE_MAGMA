// $Id: RoiFigure.java,v 1.4 2009/04/08 17:17:55 abrighto Exp $

//package alma.obsprep.ot.editors.spatialvisual.mapper;
package jsky.image.graphics;

import java.awt.Color;
import java.awt.Shape;
import java.awt.Paint;
import java.awt.geom.AffineTransform;

import diva.canvas.interactor.Interactor;

/**
 * The abstract super class of ImageFigures to be used for
 * ROI patterns.
 *
 * @version $Revision: 1.4 $
 * @author yatagai
 * @author Allan Brighton (changes)
 *
 */
public class RoiFigure extends ImageFigure implements RotatableCanvasFigure {
	
    protected static final Color DEFAULT_FILL = null;
	protected static final float DEFAULT_LINE_WIDTH = 2.0f;
	protected static final Color DEFAULT_LINE_COLOR = Color.white;

    // The figure's outline geometry, used for rotating
    private RectangleGeometry _geometry;

    // True if the figure should be resizable
    private boolean _resizable = true;


    public RoiFigure(Shape shape) {
		super(shape, DEFAULT_FILL, DEFAULT_LINE_COLOR, DEFAULT_LINE_WIDTH, null);
	}

    /**
     * Create an image figure with the given shape, fill, outline and line width.
     *
     * @param shape      the shape to draw
     * @param fill       the paint to use to fill the shape
     * @param outline    the paint to use for the outline
     * @param lineWidth  the width of the shape lines in pixels
     * @param interactor determines the behavior of the figure (may be null)
     */
	public RoiFigure(Shape shape, Paint fill, Paint outline, float lineWidth, Interactor interactor) {
		super(shape, fill, outline, lineWidth, interactor);
        updateGeometry();
	}

	@Override
	public void translate(double dx, double dy) {
		super.translate(dx, dy);
		_geometry.translate(dx, dy);
		repaint();
	}

    @Override
    public void transform(AffineTransform at) {
        super.transform(at);
        _geometry.transform(at);
        repaint();
    }

    public RectangleGeometry getGeometry() {
		return _geometry;
	}

	public void setGeometry(RectangleGeometry geometry) {
		_geometry = geometry;
	}

    /**
     * Updates the figure's geometry. This method should be called when a figure's shape
     * changes, such as when adding lines to a polyline.
     */
    public void updateGeometry() {
        setGeometry(new RectangleGeometry(this, getShape()));
    }

    /**
     * @return true if the figure should be resizable
     */
    public boolean isResizable() {
        return _resizable;
    }

    /**
     * @param resizable set to true if the figure should be resizable
     */
    public void setResizable(boolean resizable) {
        _resizable = resizable;
    }



	@Override
	public String toString() {
		return getClass().getSimpleName() + "@" + hashCode();
	}
	
	public void setEditable(boolean editable) {
        if (!editable) {
			setInteractor(null);
			repaint();
		}
    }
}
