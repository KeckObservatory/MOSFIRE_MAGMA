/*
 * $Id: ImageFigureGroup.java,v 1.4 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.image.graphics;

import diva.canvas.Figure;
import diva.canvas.AbstractFigureContainer;
import diva.canvas.ZList;
import diva.canvas.BasicZList;
import diva.canvas.interactor.Interactor;

import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.awt.Shape;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.List;
import java.util.Iterator;

import jsky.graphics.CanvasFigure;
import jsky.graphics.CanvasFigureGroup;
import jsky.graphics.CanvasFigureListener;
import jsky.graphics.CanvasFigureListenerManager;
import diva.canvas.interactor.SelectionInteractor;


/**
 * Represents a group of figures, that are treated like a single figure.
 *
 * @author Allan Brighton
 * @version $Revision: 1.4 $
 */
public class ImageFigureGroup extends AbstractFigureContainer implements CanvasFigureGroup {

    /**
     * An arbitrary object to store with the figure for later reference
     */
    private Object _clientData;

    /**
     * Manages a list of listeners for figure events
     */
    private CanvasFigureListenerManager _listenerManager;

    /**
     * The child figures.
     */
    private ZList _children;

    /**
     * Optional linked list of slave figures, which should be moved with this figure.
     */
    private List<CanvasFigure> _slaves;

    /**
     * True if figure should not be deleted when a new image is loaded.
     */
    private boolean _persistent;

    /**
     * The figure's outline geometry, used for rotating
     */
    private RectangleGeometry _geometry;

    /**
     * True if the figure should be resizable
     */
    private boolean _resizable = true;

    
    /**
     * Create an image figure group with the given shape, fill, outline and line width.
     *
     * @param interactor determines the selection behavior of the figure group (may be null)
     */
    public ImageFigureGroup(Interactor interactor) {
        _children = new BasicZList();
        _listenerManager = new CanvasFigureListenerManager(this);
        updateGeometry();

        if (interactor != null) {
            setInteractor(interactor);
        }
    }


    /**
     * Add a figure to the group.
     */
    public void add(Figure f) {
        _children.add(f);
        f.setParent(this);
        f.repaint();
        updateGeometry();
    }

    /**
     * Insert a figure at the given position.
     * @param index position to insert at
     * @param f the figure to add
     */
    public void add(int index, Figure f) {
        _children.add(index, f);
        f.setParent(this);
        f.repaint();
        updateGeometry();
    }

    /**
     * Remove a figure from the group.
     */
    public void remove(Figure f) {
        f.repaint();
        f.setParent(null);
        _children.remove(f);
        f.repaint();
        updateGeometry();
    }


    /**
     * Test if the given figure is a child of this composite.
     * Note that this method, although provided, should not actually
     * be used for performance reasons -- instead, test if the parent
     * of the child is the same as this composite.
     */
    public boolean contains(Figure f) {
        return _children.contains(f);
    }

    /**
     * Return an iteration of the children, in an undefined order.
     */
    public Iterator figures() {
        return _children.figures();
    }

    /**
     * Return an iteration of the children, from back to front. This
     * is the order in which the children are painted.  
     */
    public Iterator figuresFromBack() {
        return _children.figuresFromBack();
    }

    /**
     * Return an iteration of the children, from front to back. This
     * is the order in which events are intercepted.
     */
    public Iterator figuresFromFront() {
        return _children.figuresFromFront();
    }

    /**
     * Return the number of elements in this container.
     */
    public int getFigureCount() {
        return _children.getFigureCount();
    }

    /** Get the shape of this figure. 
     */
    public Shape getShape() {
        return _children.getBounds();
    }

    /** Replace the first figure, which must be a child, with the
     * second, which must not be a child.
     */
    protected void replaceChild(Figure child, Figure replacement) {
        repaint();
        _children.set(_children.indexOf(child), replacement);
        repaint();
    }

    /**
     * Store an arbitrary object with the figure for later reference
     */
    public void setClientData(Object o) {
        _clientData = o;
    }

    /**
     * Return the client data object, or null if none was set
     */
    public Object getClientData() {
        return _clientData;
    }


    /**
     * Return the bounds of this figure, ignoring the label, if there is one.
     */
    public Rectangle2D getBoundsWithoutLabel() {
        return getBounds();  // not applicable here
    }

    /**
     * Return true if the figure is selected.
     */
    public boolean isSelected() {
        return (getInteractor() instanceof SelectionInteractor);
    }

    /**
     * Set the visibility flag of this object. If the flag is false,
     * then the object will not be painted on the screen.
     */
    public void setVisible(boolean flag) {
        super.setVisible(flag);
        repaint();
    }


    /**
     * @return true if this figure should not be deleted when a new image is loaded
     */
    public boolean isPersistent() {
        return _persistent;
    }

    /**
     * @param persistent set to true if this figure should not be deleted when a new image is loaded
     */
    public void setPersistent(boolean persistent) {
        _persistent = persistent;
    }

    /**
     * Add a listener for events on the canvas figure
     */
    public void addCanvasFigureListener(CanvasFigureListener listener) {
        _listenerManager.addCanvasFigureListener(listener);
    }

    /**
     * Remove a listener for events on the canvas figure
     */
    public void removeCanvasFigureListener(CanvasFigureListener listener) {
        _listenerManager.removeCanvasFigureListener(listener);
    }

    /**
     * Fire an event on the canvas figure.
     *
     * @param eventType one of the CanvasFigure constants: SELECTED, DESELECTED, RESIZED, MOVED
     */
    public void fireCanvasFigureEvent(int eventType) {
        _listenerManager.fireCanvasFigureEvent(eventType);
    }

    /**
     * Add a slave figure. When this figure is moved, the slaves will also move.
     */
    public void addSlave(CanvasFigure fig) {
        if (_slaves == null) {
            _slaves = new LinkedList<CanvasFigure>();
        }
        _slaves.add(fig);
    }

    /**
     * Translate the figure with by the given distance.
     * As much as possible, this method attempts
     * to preserve the type of the shape: if the shape of this figure
     * is an of RectangularShape or Polyline, then the shape may be
     * modified directly. Otherwise, a general transformation is used
     * that loses the type of the shape, converting it into a
     * GeneralPath.
     */
    @Override
    public void translate(double dx, double dy) {
        super.translate(dx, dy);

        _geometry.translate(dx, dy);
//        repaint();

        if (_slaves != null) {
            ListIterator it = _slaves.listIterator(0);
            while (it.hasNext()) {
                Figure fig = (Figure) it.next();
                fig.translate(dx, dy);
            }
//            repaint();
        }
    }


    @Override
    public void transform(AffineTransform at) {
        super.transform(at);
        _geometry.transform(at);
//        repaint();
    }

    public RectangleGeometry getGeometry() {
		return _geometry;
	}

	public void setGeometry(RectangleGeometry geometry) {
		_geometry = geometry;
	}


    /**
     * Updates the figure's geometry. This method should be called when a figure's shape
     * changes, such as when adding lines to a polyline.
     */
    public void updateGeometry() {
        setGeometry(new RectangleGeometry(this, getBounds()));
    }

	@Override
	public String toString() {
		return getClass().getSimpleName() + "@" + hashCode();
	}

	public void setEditable(boolean editable) {
        if (!editable) {
			setInteractor(null);
			repaint();
		}
    }

    /**
     * @return true if the figure should be resizable
     */
    public boolean isResizable() {
        return _resizable;
    }

    /**
     * @param resizable set to true if the figure should be resizable
     */
    public void setResizable(boolean resizable) {
        _resizable = resizable;
    }


}


