/*
 * $Id: CanvasFigureEvent.java,v 1.2 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.graphics;

import java.util.EventObject;


/**
 * This event is generated when a canvas figure is seletced, deselected,
 * resized or dragged.
 *
 * @version $Revision: 1.2 $
 * @author Allan Brighton
 */
public class CanvasFigureEvent extends EventObject {

    public CanvasFigureEvent(CanvasFigure fig) {
        super(fig);
    }

    /** Return the figure for the event. */
    public CanvasFigure getFigure() {
        return (CanvasFigure) getSource();
    }
}
