/*
 * $Id: CanvasFigureGroup.java,v 1.2 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.graphics;

import jsky.image.graphics.RotatableCanvasFigure;
import diva.canvas.Figure;

/**
 * This defines an abstract interface for a group of canvas figures that should be
 * displayed and selected together as a unit.
 *
 * @version $Revision: 1.2 $
 * @author Allan Brighton
 */
public abstract interface CanvasFigureGroup extends RotatableCanvasFigure {

    /**
     * Add a figure to the group.
     * @param fig figure to add
     */
    public void add(Figure fig);

    /**
     * Remove a figure from the group.
     * @param fig figure to remove
     */
    public void remove(Figure fig);
}

