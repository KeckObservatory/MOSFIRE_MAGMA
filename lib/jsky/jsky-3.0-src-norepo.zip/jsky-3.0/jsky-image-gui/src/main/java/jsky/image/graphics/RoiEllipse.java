//package alma.obsprep.ot.editors.spatialvisual.mapper;
package jsky.image.graphics;

import diva.canvas.interactor.Interactor;

import java.awt.geom.Ellipse2D;
import java.awt.Paint;

/**
 * Implementation of figures for ellipse shape ROIs
 *
 * @version $Revision: 1.3 $
 * @author yatagai
 *
 */

// $Id: RoiEllipse.java,v 1.3 2009/04/08 17:17:55 abrighto Exp $
public class RoiEllipse extends RoiRectangle {
	
    public RoiEllipse(Ellipse2D ellipse, Paint fill, Paint color, float lineWidth, Interactor interactor) {
        super(ellipse, fill, color, lineWidth, interactor);
    }

	public RoiEllipse(Ellipse2D ellipse) {
		this(ellipse, DEFAULT_FILL, DEFAULT_LINE_COLOR, DEFAULT_LINE_WIDTH, null);
	}

	public RoiEllipse(double x, double y, double width, double height) {
		this(new Ellipse2D.Double(x, y, width, height));
	}
}
