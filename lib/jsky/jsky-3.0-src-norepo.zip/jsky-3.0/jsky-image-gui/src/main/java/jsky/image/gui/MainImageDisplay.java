/*
 * $Id: MainImageDisplay.java,v 1.5 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.image.gui;

import java.awt.Graphics2D;
import java.net.URL;
import javax.swing.event.ChangeListener;

import jsky.coords.WorldCoords;
import jsky.util.gui.GenericToolBarTarget;

/**
 * This defines the interface for a main application image display window.
 *
 * @author Allan Brighton
 * @version $Revision: 1.5 $
 */
public abstract interface MainImageDisplay
        extends GraphicsImageDisplay, GenericToolBarTarget {

    /**
     * Set the image file to display.
     * @param fileOrUrl a file name or URL
     */
    public void setFilename(String fileOrUrl);

    /**
     * Set the image file to display, and indicate that the file was downloaded from
     * the given URL (for image history recording).
     * @param fileOrUrl a file name or URL
     * @param url the original URL, if downloaded from an image server
     */
    public void setFilename(String fileOrUrl, URL url);

    /**
     * @return the image file name, if there is one.
     */
    public String getFilename();

    /**
     * Set the URL for the image to display.
     * @param url points to the image
     */
    public void setURL(URL url);

    /**
     * @return the image URL, if there is one, otherwise null.
     */
    public URL getURL();

    /**
     * If the image was downloaded from an image server, this method returns the original URL used.
     *
     * @return the original image URL
     */
    public URL getOrigURL();

    /**
     * Update the display to show the contents of the currently loaded image file.
     */
    public void updateImageData();

    /**
     * Display the FITS table at the given HDU index (if supported).
     * @param hdu HDU index
     */
    public void displayFITSTable(int hdu);

    /**
     * Deletes the FITS table at the given HDU index (if supported).
     * @param hdu the HDU index
     */
    void deleteFITSTable(int hdu);

    /**
     * @return the name of the object being displayed, if known, otherwise null.
     */
    public String getObjectName();

    /**
     * Paint the image and graphics to the given graphics object (for save and print features)
     * @param g2D used to draw on the image
     */
    public void paintImageAndGraphics(Graphics2D g2D);

    /**
     * register to receive change events from this object whenever the
     * image or cut levels are changed.
     * @param l the listener
     */
    public void addChangeListener(ChangeListener l);

    /**
     * Stop receiving change events from this object.
     * @param l the listener
     */
    public void removeChangeListener(ChangeListener l);

    /**
     * Set to true if the image has been modified and needs saving.
     * @param b true if image was modified
     */
    public void setSaveNeeded(boolean b);

    /**
     * If the current image file has been modified (by adding or deleting a FITS extension,
     * for example), ask the user to confirm saving it.
     *
     * @return false if the user pressed Cancel when asked to save the file,
     *         otherwise true
     */
    public boolean checkSave();

    /**
     * Pop up a dialog to ask the user for a file name, and then save the image
     * to the selected file.
     */
    public void saveAs();

    /**
     * Save the current image to the given file, using an image format
     * based on the file suffix, which should be one of ".fits", ".jpg",
     * ".png", or ".tif".
     * 
     * @param filename file to save to
     * @param reload if true, reload the image from the file after saving
     */
    public void saveAs(String filename, boolean reload);

    /**
     * Pop up a dialog for printing the image.
     */
    public void print();

    /**
     * Return the default min and max search radius values to use for catalog searches, in arcmin.
     *
     * @param centerPos    the center position for the radius
     * @param useImageSize if true, use the image size to get the search radius
     * @return an array containing the min and max radius values
     */
    double[] getDefaultSearchRadius(WorldCoords centerPos, boolean useImageSize);

    /**
     * Return the default min and max magnitude values to use for catalog searches, or null
     * if there is no default.
     *
     * @return an array containing the min and max mag values
     */
    double[] getDefaultSearchMagRange();
}
