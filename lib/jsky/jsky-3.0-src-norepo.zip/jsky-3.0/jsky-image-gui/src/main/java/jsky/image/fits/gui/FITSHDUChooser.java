/*
 * ESO Archive
 *
 * $Id: FITSHDUChooser.java,v 1.8 2009/04/16 15:54:37 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/12/10  Created
 */

package jsky.image.fits.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.media.jai.PlanarImage;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableColumn;

import jsky.image.fits.codec.FITSImage;
import jsky.image.gui.MainImageDisplay;
import jsky.util.gui.BusyWin;
import jsky.util.gui.DialogUtil;
import jsky.util.gui.SwingUtil;

import nom.tam.fits.AsciiTableHDU;
import nom.tam.fits.BasicHDU;
import nom.tam.fits.BinaryTableHDU;
import nom.tam.fits.Header;
import nom.tam.fits.ImageHDU;
import uk.ac.starlink.table.gui.NumericCellRenderer;


/**
 * Displays a window listing the HDU extensions in the current
 * FITS image and allows the user to select the one to display.
 *
 * @author Allan Brighton
 * @version $Revision: 1.8 $
 */
public class FITSHDUChooser extends JPanel {

    // main image display window
    private MainImageDisplay _imageDisplay;

    // Table displaying the HDU info
    private JTable _table;

    // Handle to FITSImage object
    private FITSImage _fitsImage;

    // Table column headings
    private static final String[] COLUMN_NAMES = {
            "HDU", "Type", "EXTNAME", "NAXIS", "NAXIS1", "NAXIS2", "NAXIS3", "CRPIX1", "CRPIX2"
    };

    // Number of columns in the table
    private static final int NUM_COLS = COLUMN_NAMES.length;

    // column indexes
    private static final int HDU_INDEX = 0;
    private static final int TYPE_INDEX = 1;
    private static final int EXTNAME_INDEX = 2;
    private static final int NAXIS_INDEX = 3;
    private static final int NAXIS1_INDEX = 4;
    private static final int NAXIS2_INDEX = 5;
    private static final int NAXIS3_INDEX = 6;
    private static final int CRPIX1_INDEX = 7;
    private static final int CRPIX2_INDEX = 8;

    // Table column classes
    private static final Class[] COLUMN_CLASSES = {
            Integer.class, String.class, String.class, Integer.class, Integer.class, Integer.class,
            Integer.class, Double.class, Double.class
    };


    // Table column widths
    private static final int[] COLUMN_WIDTHS = {
            50, 70, 200, 60, 60, 60, 60, 70, 70
    };

    // The data to display in the table
    private Object[][] _tableData;

    // Button to open a FITS extension
    private JButton _openButton;

    // Button to delete a FITS extension
    private JButton _deleteButton;

    // Checkbox option to show hidden HDUs
    private JCheckBox _showHiddenCheckBox;


    /**
     * Pop up a window displaying FITS HDU information and let the user choose the
     * HDU/extension to display.
     *
     * @param imageDisplay The image display window
     * @param fitsImage The FITSImage object returned by the "#fits_image" property for FITS images
     */
    public FITSHDUChooser(MainImageDisplay imageDisplay, FITSImage fitsImage) {
        _imageDisplay = imageDisplay;

        setLayout(new BorderLayout());
        add(_makeTablePane(), BorderLayout.CENTER);
        add(_makeButtonPanel(), BorderLayout.SOUTH);

        updateDisplay(fitsImage);
    }


    /**
     * Make and return the table panel displaying the HDU information
     */
    private JScrollPane _makeTablePane() {
        _table = new JTable();
        _table.setCellSelectionEnabled(false);
        _table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        _table.setRowSelectionAllowed(true);
        _table.setColumnSelectionAllowed(false);
        _table.setGridColor(Color.gray);
        _table.setRowHeight(20);
        
        // track double-clicks in table to select HDU for viewing
        _table.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent evt) {
                Point pt = evt.getPoint();
                int row = _table.rowAtPoint(pt);
                if (evt.getClickCount() == 2) {
                    _open(row);
                }
            }
        });

        _table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                _updateEnabledStates();
            }
        });

        // set preferred table size
        _table.setPreferredScrollableViewportSize(new Dimension(450, 90));

        return new JScrollPane(_table);
    }

    // Updates the enabled states of the dialog buttons
    private void _updateEnabledStates() {
        int[] rows = _table.getSelectedRows();
        int selectedRow = _table.getSelectedRow();
        _openButton.setEnabled(rows.length == 1);
        _deleteButton.setEnabled(rows.length > 0 && selectedRow != 0);

        TableModel model = _table.getModel();
        for(int rowIndex : rows) {
            // Only allow deleting binary tables for now, since they are also generated here
            String type = (String) model.getValueAt(rowIndex, TYPE_INDEX);
            if (!"binary".equalsIgnoreCase(type)) {
                _deleteButton.setEnabled(false);
                break;
            }
            // Don't allow deleting the special CATINFO table, which holds
            // catalog and plot symbl information. It should be deleted
            // automatically when not needed.
            String name = (String) model.getValueAt(rowIndex, EXTNAME_INDEX);
            if ("CATINFO".equalsIgnoreCase(name)) {
                _deleteButton.setEnabled(false);
                break;
            }
        }
    }

    /**
     * Returns true if the given HDU should be hidden, because it was generated
     * by this application.
     * @param hdu a FITS HDU
     * @return true if HDU should be hidden
     */
    protected boolean _isHidden(BasicHDU hdu) {
        if (_showHiddenCheckBox.isSelected()) {
            return false;
        }
        Header header = hdu.getHeader();
        String name = header.getStringValue("EXTNAME");
        return name != null && (name.equals("CATINFO") || name.startsWith("VOTMETA") || name.equals(".GRAPHICS"));
    }

    /**
     * Update the display with the latest information (after a new image was loaded).
     */
    public void updateDisplay(FITSImage fitsImage) {
        _fitsImage = fitsImage;
        int numRows = _fitsImage.getNumHDUs();
        _tableData = new Object[numRows][NUM_COLS];
        int count = 0;
        for (int row = 0; row < numRows; row++) {
            BasicHDU hdu = _fitsImage.getHDU(row);
            if (_isHidden(hdu)) {
                continue;
            }
            Header header = hdu.getHeader();
            _tableData[count][HDU_INDEX] = row;
            _tableData[count][TYPE_INDEX] = _getHDUType(hdu);
            _tableData[count][EXTNAME_INDEX] = header.getStringValue("EXTNAME");
            _tableData[count][NAXIS_INDEX] = header.getIntValue("NAXIS");
            _tableData[count][NAXIS1_INDEX] = header.getIntValue("NAXIS1");
            _tableData[count][NAXIS2_INDEX] = header.getIntValue("NAXIS2");
            _tableData[count][NAXIS3_INDEX] = header.getIntValue("NAXIS3");
            _tableData[count][CRPIX1_INDEX] = header.getDoubleValue("CRPIX1");
            _tableData[count][CRPIX2_INDEX] = header.getDoubleValue("CRPIX2");
            count++;
        }

        final int rowCount = count;
        _table.setModel(new AbstractTableModel() {

            public int getColumnCount() {
                return NUM_COLS;
            }

            public String getColumnName(int i) {
                return COLUMN_NAMES[i];
            }

            public Class getColumnClass(int i) {
                return COLUMN_CLASSES[i];
            }

            public int getRowCount() {
                return rowCount;
            }

            public Object getValueAt(int row, int col) {
                return _tableData[row][col];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        });

        // set column widths
        for (int i = 0; i < NUM_COLS; i++) {
            TableColumn col = _table.getColumn(COLUMN_NAMES[i]);
            col.setPreferredWidth(COLUMN_WIDTHS[i]);
            col.setCellRenderer(new NumericCellRenderer(COLUMN_CLASSES[i]));
        }

        _table.getSelectionModel().clearSelection();
        _deleteButton.setEnabled(false);
    }


    /**
     * Return a String describing the given HDU
     */
    private String _getHDUType(BasicHDU hdu) {
        if (hdu instanceof ImageHDU) {
            return "image";
        }
        if (hdu instanceof BinaryTableHDU) {
            return "binary";
        }
        if (hdu instanceof AsciiTableHDU) {
            return "ascii";
        }
        return "unknown";
    }


    /**
     * Displays the HDU corresponding to the given table row index
     */
    private void _open(int rowIndex) {
        if (rowIndex != -1) {
            BusyWin.setBusy(true);
            try {
                TableModel model = _table.getModel();
                int hdu = (Integer) model.getValueAt(rowIndex, HDU_INDEX);
                String type = (String) model.getValueAt(rowIndex, TYPE_INDEX);
                int naxis = (Integer) model.getValueAt(rowIndex, NAXIS_INDEX);
                if (type.equals("image")) {
                    if (naxis >= 2) {
                        selectImage(hdu);
                    }
                } else if (type.equals("binary") || type.equals("ascii")) {
                    _imageDisplay.displayFITSTable(hdu);
                }
            } finally {
                BusyWin.setBusy(false);
            }
        }
    }


    /**
     * Select the given image HDU and display it.
     */
    public void selectImage(int hdu) {
        try {
            _fitsImage.setHDU(hdu);
        } catch (Exception e) {
            throw new RuntimeException("Can't select FIT HDU# " + hdu + ": " + e.getMessage());
        }
        _imageDisplay.setImage(PlanarImage.wrapRenderedImage(_fitsImage));
    }


    /**
     * Return the JTable used to display the HDU information for the FITS file.
     */
    public JTable getTable() {
        return _table;
    }


    /**
     * Make the dialog button panel
     */
    private JPanel _makeButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        _openButton = new JButton("Open");
        _openButton.setToolTipText("Open and display the selected FITS HDU (header/data unit)");
        panel.add(_openButton);
        _openButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                _open();
            }
        });

        _deleteButton = new JButton("Delete");
        _deleteButton.setToolTipText("Delete the selected FITS HDU");
        panel.add(_deleteButton);
        _deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                _delete();
            }
        });

        JButton closeButton = new JButton("Close");
        closeButton.setToolTipText("Hide this window");
        panel.add(closeButton);
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ev) {
                _close();
            }
        });

        // Add a checkbox to show or hide the generated HDUs
        _showHiddenCheckBox = new JCheckBox("Show hidden HDUs");
        _showHiddenCheckBox.setToolTipText(
                "Show or hide generated FITS HDUs used to store additional VOTable or catalog information");
        _showHiddenCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateDisplay(_fitsImage);
            }
        });
        _showHiddenCheckBox.setMargin(new Insets(2, 10, 2, 1));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BorderLayout());
        buttonPanel.add(_showHiddenCheckBox, BorderLayout.WEST);
        buttonPanel.add(panel, BorderLayout.EAST);

        return buttonPanel;
    }


    /**
     * Open and display the selected extension.
     */
    private void _open() {
        _open(_table.getSelectedRow());
    }


    /**
     * Delete the selected extension.
     */
    private void _delete() {
        int[] hdus = _table.getSelectedRows();
        for (int i = hdus.length - 1; i >= 0; i--) {
            int hdu = hdus[i];
            if (hdu > 0 && hdu < _fitsImage.getNumHDUs()) {
                try {
                    _imageDisplay.deleteFITSTable(hdu);
                } catch (Exception e) {
                    DialogUtil.error(e);
                    return;
                }
                updateDisplay(_fitsImage);
            }
        }
    }


    /**
     * Close the window
     */
    private void _close() {
        JFrame parent = SwingUtil.getFrame(this);
        if (parent != null) {
            parent.setVisible(false);
        }
    }


    /**
     * Clear the table and remove any referenes to the image data
     */
    public void clear() {
        _table.setModel(new DefaultTableModel());
        _fitsImage = null;
    }


    /**
     * Show or hide the top level window
     */
    public void setShow(boolean show) {
        JFrame parent = SwingUtil.getFrame(this);
        if (parent != null) {
            parent.setVisible(show);
            if (show) {
                int hdu = _fitsImage.getCurrentHDUIndex();
                _table.getSelectionModel().setSelectionInterval(hdu, hdu);
                SwingUtil.showFrame(parent);
            }
        }
    }
}


