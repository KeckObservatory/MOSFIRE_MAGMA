// $Id: RectangleGeometry.java,v 1.3 2009/03/30 19:40:23 abrighto Exp $

//package alma.obsprep.ot.editors.spatialvisual;
package jsky.image.graphics;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.RectangularShape;
import java.util.Iterator;

import diva.canvas.AbstractSite;
import diva.canvas.Figure;
import diva.canvas.Site;
import diva.canvas.interactor.Geometry;


/**
 * A geometry for a rotatable rectangle.
 *
 * @author yatagai
 * @author Allan Brighton (changes)
 * @version $Revision: 1.3 $
 */

//copied and modified diva.canvas.interactor.CircleGeometry.java
public class RectangleGeometry implements Geometry {

    /**
     * The figure to which the sites are attached
     */
    private Figure _parentFigure;

    /**
     * The minimum size of the rectangle
     */
    private double _minSize = 10.0;

    /**
     * The overshoot of the x and y coordinates
     */
    private double _xOvershoot = 0;
    private double _yOvershoot = 0;

    /**
     * The defining rectangle
     */
    private RectangularShape _rect;

    /**
     * Used when shape is not rectangular (after rotation it becomes a Path2D)
     */
    private Shape _path;

    /**
     * The number of sites in the sites array.
     * Note: SwingConstants start at 1!
     */
    private static int _siteCount = 5;

    /**
     * The sites that exist so far
     */
    private RectangleSite _sites[] = new RectangleSite[_siteCount];

    // extensions for rotating
    private double _rotateAngle = 0.0;
    private Point2D _rotateCenter;

    /**
     * Create a new geometry object on the given figure and with the
     * given initial bounds.
     */
    public RectangleGeometry(Figure figure, Shape shape) {
        _parentFigure = figure;
        setShape(shape);
        setRotateCenter(new Point2D.Double(_rect.getCenterX(), _rect.getCenterY()));
    }

    /**
     * Get the single site with the given ID.
     */
    public Site getSite(int id) {
        if (_sites[id] == null) {
            _sites[id] = new RectangleSite(id);
        }
        return _sites[id];
    }

    /**
     * Get the minimum size of the rectangle.
     */
    public double getMinimumSize() {
        return _minSize;
    }

    /**
     * Get the figure to which this geometry object is attached.
     * Returns null if there isn't one.
     */
    public Figure getFigure() {
        return _parentFigure;
    }

    /**
     * Get the current shape that defines this geometry
     */
    public Shape getShape() {
        return _rect;
    }

    /**
     * Get the rotate angle
     *
     * @return in radians
     */
    public double getRotateAngle() {
        return _rotateAngle;
    }

    /**
     * Get the rotate angle
     *
     * @return in radians [-PI, PI]
     */
    public double getNormalizedRotateAngle() {
        double tmp = getRotateAngle() + Math.PI;
        double frac = tmp - Math.floor(tmp / (2 * Math.PI)) * (2 * Math.PI);
        return (frac - Math.PI);
    }

    /**
     * Get the current rectangle that defines this geometry. This
     * returns the same shape as getShape(), but as a RectangularShape.
     */
    public RectangularShape getRect() {
        return _rect;
    }

    /**
     * Set the minimum size of the rectangle. The default is 1.0.
     */
    public void setMinimumSize(double minimumSize) {
        _minSize = minimumSize;
    }

    /**
     * Set the shape that defines this geometry object.
     * The shape must be a RectangularShape, or an exception
     * will be thrown.
     */
    public void setShape(Shape shape) {
        _rect = shape.getBounds2D();
        _path = _rect;
    }

    public void refresh(Figure figure) {
        Shape shape = figure.getShape();
        if (shape instanceof RectangularShape) {
            _rect = figure.getBounds();
            _path = _rect;
        }
        else if (_path instanceof Path2D) {
            refresh((Path2D)_path);
        }
    }

    private void refresh(Path2D path) {
        double[] ret = calcGeom(path);
        double centerX = ret[0];
        double centerY = ret[1];
        double width = ret[2];
        double height = ret[3];

        if (_rect != null) {
            _rect.setFrameFromCenter(centerX, centerY, centerX + width / 2, centerY + height / 2);
        }

        setRotateCenter(new Point2D.Double(centerX, centerY));
        setRotateAngle(calcAngle(path));
    }

    private Point2D.Double[] getCorners(Path2D path) {
        Point2D.Double[] corners = new Point2D.Double[4];

        double coords[] = new double[6];
        PathIterator pathItr = path.getPathIterator(new AffineTransform());

        for (int i = 0; i < 4; i++) {
            pathItr.currentSegment(coords);
            corners[i] = new Point2D.Double(coords[0], coords[1]);
            pathItr.next();
        }
        return corners;
    }

    private double calcAngle(Path2D path) {
        Point2D.Double[] corners = getCorners(path);
        double dx = corners[1].x - corners[0].x;
        double dy = corners[1].y - corners[0].y;
        return Math.atan2(dy, dx);
    }

    private double[] calcGeom(Path2D path) {
        double[] ret = new double[4];

        Point2D.Double[] corners = getCorners(path);
        ret[0] = (corners[0].x + corners[2].x) / 2;
        ret[1] = (corners[0].y + corners[2].y) / 2;

        double dx = corners[1].x - corners[0].x;
        double dy = corners[1].y - corners[0].y;
        ret[2] = Math.sqrt(dx * dx + dy * dy);

        dx = corners[2].x - corners[1].x;
        dy = corners[2].y - corners[1].y;
        ret[3] = Math.sqrt(dx * dx + dy * dy);

        return ret;
    }


    /**
     * Return an iteration over the sites in this geometry object.
     */
    public Iterator sites() {
        return new Iterator() {
            // Note: SwingConstants start at 1!
            int cursor = 0;

            public boolean hasNext() {
                return cursor < _siteCount;
            }

            public Object next() {
                if (_sites[cursor] == null) {
                    _sites[cursor] = new RectangleSite(cursor);
                }
                return _sites[cursor++];
            }

            public void remove() {
                throw new UnsupportedOperationException(
                        "Site cannot be removed");
            }
        };
    }

    /**
     * Transform the geometry object
     * @param at the transformation
     */
    public void transform(AffineTransform at) {
        _path = at.createTransformedShape(_path);
    }

    /**
     * Translate the geometry object
     */
    public void translate(double x, double y) {
        translateRect(x, y);
        translateRotateCenter(x, y);
    }

    public void translateRect(double x, double y) {
        _rect.setFrame(_rect.getX() + x, _rect.getY() + y,
                _rect.getWidth(), _rect.getHeight());
    }

    public void translateRotateCenter(double dx, double dy) {
        _rotateCenter.setLocation(_rotateCenter.getX() + dx, _rotateCenter.getY() + dy);
    }

    public void setRotateAngle(double angle) {
        _rotateAngle = angle;
    }

    public Point2D getRotateCenter() {
        return _rotateCenter;
    }

    public void setRotateCenter(Point2D p) {
        _rotateCenter = p;
    }

    public void updateCenter() {
        // update rotateCenter
        Point2D c1 = new Point2D.Double(_rect.getCenterX(), _rect.getCenterY());

        AffineTransform af = new AffineTransform();
        af.setToRotation(_rotateAngle, _rotateCenter.getX(), _rotateCenter.getY());
        Point2D c2 = af.transform(c1, null);

        translateRect(c2.getX() - c1.getX(), c2.getY() - c1.getY());
        _rotateCenter = c2;
    }

    ///////////////////////////////////////////////////////////////////
    //// RectangleSite

    /**
     * RectangleSite is the local class that implements
     * an editable site of Rectangle objects.
     */
    public class RectangleSite extends AbstractSite {

        // Its id
        private int _id;

        private double _offX;
        private double _offY;

        /**
         * Create a new site with the given ID
         */
        RectangleSite(int id) {
            _id = id;
            offset();
        }

        private void offset() {
            switch (_id) {
                case 0:
                    _offX = _rect.getWidth() / 2;
                    _offY = _rect.getHeight() / 2;
                    return;
                case 1:
                    _offX = _rect.getWidth() / 2;
                    _offY = 0;
                    return;
                case 2:
                    _offX = 0;
                    _offY = -_rect.getHeight() / 2;
                    return;
                case 3:
                    _offX = -_rect.getWidth() / 2;
                    _offY = 0;
                    return;
                case 4:
                    _offX = 0;
                    _offY = _rect.getHeight() / 2;
            }
        }

        /**
         * Get the ID of this site.
         */
        @Override
        public int getID() {
            return _id;
        }

        /**
         * Get the figure to which this site is attached, or null
         * if it is not attached to a figure.
         */
        @Override
        public Figure getFigure() {
            return _parentFigure;
        }

        /**
         * Get the point location of the site.
         */
        @Override
        public Point2D getPoint() {
            offset();
            Point2D.Double point = new Point2D.Double(_rect.getCenterX() + _offX, _rect.getCenterY() + _offY);
            AffineTransform af = new AffineTransform();
            af.setToRotation(getRotateAngle(), getRotateCenter().getX(), getRotateCenter().getY());
            af.transform(point, point);
            return point;
        }

        /**
         * Get the x-coordinate of the site, in the local
         * coordinates of the containing pane.
         */
        @Override
        public double getX() {
            return getPoint().getX();
        }

        /**
         * Get the y-coordinate of the site, in the local
         * coordinates of the containing pane.
         */
        @Override
        public double getY() {
            return getPoint().getY();
        }

        /**
         * Translate the site by the indicated distance,
         * where distances are in the local coordinates of the
         * containing pane.
         */
        @Override
        public void translate(double dx, double dy) {

            Point2D p1 = getPoint();
            Point2D p2 = getPoint();
            p2.setLocation(p2.getX() + dx, p2.getY() + dy);
            AffineTransform af = new AffineTransform();
            af.setToRotation(-getRotateAngle(), getRotateCenter().getX(), getRotateCenter().getY());

            af.transform(p1, p1);
            af.transform(p2, p2);

            double x = p2.getX() - p1.getX();
            double y = p2.getY() - p1.getY();

            // Adjust the coordinates
            double x1 = _rect.getX();
            double y1 = _rect.getY();
            double x2 = x1 + _rect.getWidth();
            double y2 = y1 + _rect.getHeight();

            // Move the rectangle
            switch (_id) {
                case 0:
                    x2 += x;
                    y2 += y;
                    break;

                case 1:
                    x2 += x;
                    break;

                case 2:
                    y1 += y;
                    break;

                case 3:
                    x1 += x;
                    break;

                case 4:
                    y2 += y;
                    break;
            }

            // Constrain x
            switch (_id) {
                case 0:
                case 1:
                    if (x2 < x1 + _minSize || _xOvershoot < 0) {
                        _xOvershoot += x - (x1 + _minSize - (x2 - x));
                        x2 = x1 + _minSize;
                    } else {
                        _xOvershoot = 0;
                    }
                    break;
                case 3:
                    if (x1 > x2 - _minSize || _xOvershoot < 0) {
                        _xOvershoot += x - (x1 + _minSize - (x2 - x));
                        x1 = x2 - _minSize;
                    } else {
                        _xOvershoot = 0;
                    }
                    break;
            }

            // Constrain y
            switch (_id) {
                case 2:
                    if (y1 > y2 - _minSize || _yOvershoot < 0) {
                        _yOvershoot += y - (y1 + _minSize - (y2 - y));
                        y1 = y2 - _minSize;
                    } else {
                        _yOvershoot = 0;
                    }
                    break;
                case 0:
                case 4:
                    if (y2 < y1 + _minSize || _yOvershoot < 0) {
                        _yOvershoot += y - (y1 + _minSize - (y2 - y));
                        y2 = y1 + _minSize;
                    } else {
                        _yOvershoot = 0;
                    }
                    break;
            }

            // Set the rectangle
            _rect.setFrameFromDiagonal(x1, y1, x2, y2);

        }

        /**
         * Set the point location of the site
         */
        public void setPoint(Point2D point) {
            translate(point.getX() - getX(), point.getY() - getY());
        }

        @Override
        public String toString() {
            return "id=" + _id + ", _offX=" + _offX + ", _offY=" + _offY;
        }
    }
}


