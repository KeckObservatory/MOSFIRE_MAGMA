package jsky.image.gui;

import jsky.util.Resources;
import jsky.util.I18N;
import jsky.util.Preferences;
import jsky.util.gui.DialogUtil;
import jsky.coords.WorldCoordinateConverter;
import jsky.coords.WorldCoords;

import javax.swing.*;
import java.util.Stack;
import java.util.LinkedList;
import java.util.ListIterator;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FilenameFilter;

/**
 * Manages the list of {@link ImageHistoryItem} objects for each image viewed,
 * provides forward and backward stacks for navigation
 * and persistence between sessions.
 * 
 * @author Allan Brighton
 * @since Feb 10, 2009
 */
public class ImageHistoryList {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(ImageHistoryList.class);

    /**
     * Base filename for serialization of the history list
     */
    private static final String HISTORY_LIST_NAME = "imageHistoryList";


    /**
     * True if this is the first instance created by the application
     */
    private static boolean _firstTime = true;


    // The target image display
    private MainImageDisplay _imageDisplay;

    /**
     * Stack of ImageHistoryItem, used to go back to a previous image
     */
    private Stack<ImageHistoryItem> _backStack = new Stack<ImageHistoryItem>();

    /**
     * Stack of ImageHistoryItem, used to go forward to the next image
     */
    private Stack<ImageHistoryItem> _forwStack = new Stack<ImageHistoryItem>();

    /**
     * Set when the back or forward actions are active to avoid the normal history stack handling
     */
    private boolean _noStack = false;

    /**
     * List of ImageHistoryItem, for previously viewed images (shared by all instances of this class)
     */
    private LinkedList<ImageHistoryItem> _historyList;

    /**
     * Max number of items in the history list
     */
    private int _maxHistoryItems = 20;

    /**
     * Action to use for the "Back" menu and toolbar items
     */
    private AbstractAction _backAction = new AbstractAction(
            _I18N.getString("back"),
            Resources.getIcon("Back24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("imageBackTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                back();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Action to use for the "Forward" menu and toolbar items
     */
    private AbstractAction _forwAction = new AbstractAction(
            _I18N.getString("forward"),
            Resources.getIcon("Forward24.gif")) {
        {
            putValue(SHORT_DESCRIPTION, _I18N.getString("imageForwardTip"));
        }

        public void actionPerformed(ActionEvent evt) {
            try {
                forward();
            } catch (Exception e) {
                DialogUtil.error(e);
            }
        }
    };

    /**
     * Initialize with the target image display
     *
     * @param imageDisplay target image display
     */
    public ImageHistoryList(MainImageDisplay imageDisplay) {
        _imageDisplay = imageDisplay;

        // try to restore the history from the previous session
        loadHistory();
        cleanupHistoryList();
        if (_firstTime) {
            _firstTime = false;
            cleanupImageCache();
        }

        // arrange to save the history list for the next session on exit
        Runtime.getRuntime().addShutdownHook(new Thread() {

            public void run() {
                //addToHistory();
                saveHistory(true);
            }
        });
    }

    /**
     * Add the current URL to the history list
     */
    protected void addToHistory() {
        if (_imageDisplay.getFilename() == null) {
            return;
        }

        ImageHistoryItem historyItem = makeImageHistoryItem();

        if (!_noStack) {
            // add to the "Back" stack
            _backStack.push(historyItem);
            _backAction.setEnabled(true);
            if (_forwStack.size() != 0) {
                _forwStack.clear();
                _forwAction.setEnabled(false);
            }
        }
        addToHistory(historyItem);
    }

    /**
     * Add the given item to the history list, removing duplicates and
     * keeping the list size to a maximum of 20.
     *
     * @param historyItem the item to add
     */
    protected void addToHistory(ImageHistoryItem historyItem) {
        ListIterator it = ((LinkedList) _historyList.clone()).listIterator(0);
        for (int i = 0; it.hasNext(); i++) {
            ImageHistoryItem item = (ImageHistoryItem) it.next();
            if (item.title.equals(historyItem.title)) {
                _historyList.remove(i);
            }
        }
        _historyList.addFirst(historyItem);
        if (_historyList.size() > _maxHistoryItems) {
            ImageHistoryItem item = _historyList.removeLast();
            // remove the file, if it is in cache
            String cacheDir = Preferences.getPreferences().getCacheDir().getPath();
            if (item.filename.startsWith(cacheDir)) {
                new File(item.filename).deleteOnExit();
            }
        }
    }

    /**
     * Make and return an ImageHistoryItem for the current image
     *
     * @return the new history item
     */
    protected ImageHistoryItem makeImageHistoryItem() {
        // make the title
        double ra = Double.NaN, dec = Double.NaN;
        String radecStr = "";

        if (_imageDisplay.isWCS()) {
            WorldCoordinateConverter wcs = _imageDisplay.getWCS();
            WorldCoords center = new WorldCoords(wcs.getWCSCenter(), wcs.getEquinox());
            radecStr += center.toString();
            ra = center.getRaDeg();
            dec = center.getDecDeg();
        }

        String name = "";
        if (_imageDisplay.getFilename() != null) {
            name = new File(_imageDisplay.getFilename()).getName();
        }

        String object = _imageDisplay.getObjectName();
        if (object == null || object.startsWith("dss")) {
            object = "";
        } else {
            object = object + ": ";
        }

        String title = name;
        if (object.length() != 0 || radecStr.length() != 0) {
            title = title + " [" + object + radecStr + "]";
        }
        return new ImageHistoryItem(_imageDisplay, ra, dec, title,
                _imageDisplay.getOrigURL(), _imageDisplay.getFilename());
    }

    /**
     * @return the max number of items in the history list.
     */
    public int getMaxHistoryItems() {
        return _maxHistoryItems;
    }

    /**
     * Set the max number of items in the history list.
     *
     * @param n the max number of items to keep in the list
     */
    public void setMaxHistoryItems(int n) {
        _maxHistoryItems = n;
    }


    /**
     * Merge the historyList with current serialized version (another instance
     * may have written it since we read it last).
     *
     * @return the merged list
     */
    protected LinkedList mergeHistoryList() {
        Object[] items = _historyList.toArray();
        loadHistory();

        // Go through the list in reverse, since addToHistory inserts at the start of the list
        for (int i = items.length - 1; i >= 0; i--) {
            addToHistory((ImageHistoryItem) items[i]);
        }
        return _historyList;
    }


    /**
     * Clears the history list
     */
    public void clearHistory() {
        // remove the cached image files
        String cacheDir = Preferences.getPreferences().getCacheDir().getPath();
        for (ImageHistoryItem historyItem : _historyList) {
            if (historyItem.filename.startsWith(cacheDir)) {
                File file = new File(historyItem.filename);
                if (file.exists()) {
                    try {
                        //noinspection ResultOfMethodCallIgnored
                        file.delete();
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        _historyList = new LinkedList<ImageHistoryItem>();
        _backAction.setEnabled(false);
        _backStack.clear();
        _forwAction.setEnabled(false);
        _forwStack.clear();
        saveHistory(false);
    }


    /**
     * Save the current history list to a file.
     *
     * @param merge if true, merge the list with the existing list on disk.
     */
    protected void saveHistory(boolean merge) {
        try {
            LinkedList l;
            if (merge) {
                l = mergeHistoryList();
            } else {
                l = _historyList;
            }
            Preferences.getPreferences().serialize(HISTORY_LIST_NAME, l);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Try to load the history list from a file, and create an empty list if that fails.
     */
    protected void loadHistory() {
        try {
            //noinspection unchecked
            _historyList = (LinkedList<ImageHistoryItem>) Preferences.getPreferences().deserialize(HISTORY_LIST_NAME);
        } catch (Exception ignored) {
            _historyList = new LinkedList<ImageHistoryItem>();
        }
    }

    /**
     * Remove any items in the history list for files that no longer exist.
     */
    protected void cleanupHistoryList() {
        // remove dead items from the list
        ListIterator it = ((LinkedList) _historyList.clone()).listIterator(0);
        while (it.hasNext()) {
            ImageHistoryItem historyItem = (ImageHistoryItem) it.next();
            File file = new File(historyItem.filename);
            if (!file.exists()) {
                _historyList.remove(historyItem);
            }
        }
    }

    /**
     * Remove any files from the image cache that are no longer in the
     * history list.
     */
    protected void cleanupImageCache() {
        String cacheDir = Preferences.getPreferences().getCacheDir().getPath();
        File dir = new File(cacheDir);
        if (dir.isDirectory()) {
            // Just to be safe, use a filter to only remove files we created
            // (there shouldn't be any other files in the cache dir though)
            FilenameFilter filter = new FilenameFilter() {

                public boolean accept(File dir, String name) {
                    return name.startsWith("jsky");
                }
            };
            File[] files = dir.listFiles(filter);
            for (File file : files) {
                if (!fileInHistoryList(file)) {
                    //noinspection ResultOfMethodCallIgnored
                    file.delete();
                }

            }
        }
    }

    /**
     * Return true if the given file is referenced in the history list.
     *
     * @param file the file to look for
     * @return true if the file is in the list
     */
    public boolean fileInHistoryList(File file) {
        return getImageHistoryItem(file) != null;
    }

    /**
     * Return the ImageHistoryItem from the history list, or null if not found.
     *
     * @param file the file to look for
     * @return the history item
     */
    protected ImageHistoryItem getImageHistoryItem(File file) {
        ListIterator it = ((LinkedList) _historyList.clone()).listIterator(0);
        while (it.hasNext()) {
            ImageHistoryItem historyItem = (ImageHistoryItem) it.next();
            File f = new File(historyItem.filename);
            if (f.equals(file.getAbsoluteFile())) {
                return historyItem;
            }
        }
        return null;
    }

    /**
     * Go back to the previous image in the history list
     */
    public void back() {
        if (_backStack.size() == 0) {
            return;
        }

        if (!_imageDisplay.checkSave()) {
            return;
        }

        if (_imageDisplay.getFilename() != null) {
            _forwStack.push(makeImageHistoryItem());
            _forwAction.setEnabled(true);
        }

        ImageHistoryItem historyItem = _backStack.pop();
        if (_backStack.size() == 0) {
            _backAction.setEnabled(false);
        }

        ImageDisplayMenuBar.setCurrentImageDisplay(_imageDisplay);
        _noStack = true;
        try {
            historyItem.actionPerformed(null);
        } catch (Exception e) {
            DialogUtil.error(e);
        }
        _noStack = false;
    }


    /**
     * Go forward to the next image in the history list
     */
    public void forward() {
        if (_forwStack.size() == 0) {
            return;
        }

        if (!_imageDisplay.checkSave()) {
            return;
        }

        if (_imageDisplay.getFilename() != null) {
            _backStack.push(makeImageHistoryItem());
            _backAction.setEnabled(true);
        }

        ImageHistoryItem historyItem = _forwStack.pop();
        if (_forwStack.size() == 0) {
            _forwAction.setEnabled(false);
        }

        ImageDisplayMenuBar.setCurrentImageDisplay(_imageDisplay);
        _noStack = true;
        try {
            historyItem.actionPerformed(null);
        } catch (Exception e) {
            DialogUtil.error(e);
        }
        _noStack = false;
    }

    /**
     * Add history items (for previously loaded images) to the given menu
     *
     * @param menu the target menu
     */
    public void addHistoryMenuItems(JMenu menu) {
        ListIterator it = _historyList.listIterator(0);
        while (it.hasNext()) {
            ImageHistoryItem historyItem = (ImageHistoryItem) it.next();
            File file = new File(historyItem.filename);
            if (!file.exists()) {
                // remove dead item
                it.remove();
                continue;
            }
            menu.add(historyItem);
        }
    }

    /**
     * If an image was previously loaded in this session with a center near the
     * given ra,dec coordinates, reload it, otherwise generate a blank image
     * with the center at those coordinates (in J2000).
     *
     * @param ra  the RA coordinate for the image (J2000)
     * @param dec the Dec coordinate for the image (J2000)
     * @return true if an image was loaded
     */
    public boolean loadCachedImage(double ra, double dec) {
        LinkedList<ImageHistoryItem> l = new LinkedList<ImageHistoryItem>(_historyList);
        if (_imageDisplay.getFilename() != null) {
            l.add(0, makeImageHistoryItem()); // check the current image first
        }
        ListIterator it = l.listIterator(0);
        while (it.hasNext()) {
            ImageHistoryItem historyItem = (ImageHistoryItem) it.next();
            File file = new File(historyItem.filename);
            if (!file.exists()) {
                // remove dead item
                _historyList.remove(historyItem);
                continue;
            }
            if (historyItem.match(ra, dec)) {
                if (_imageDisplay.getFilename() != null && _imageDisplay.getFilename().equals(historyItem.filename)) {
                    return false; // already displaying the file
                }
                ImageDisplayMenuBar.setCurrentImageDisplay(_imageDisplay);
                historyItem.actionPerformed(null);
                return true;
            }
        }
        _imageDisplay.blankImage(ra, dec);
        return false;
    }

    /**
     * Set the state of the menubar/toolbar actions
     *
     * @param downloading set to true if an image is being downloaded
     */
    protected void setDownloadState(boolean downloading) {
        if (downloading) {
            _backAction.setEnabled(false);
            _forwAction.setEnabled(false);
        } else {
            _backAction.setEnabled(_backStack.size() > 0);
            _forwAction.setEnabled(_forwStack.size() > 0);
        }
    }

    public AbstractAction getBackAction() {
        return _backAction;
    }

    public AbstractAction getForwAction() {
        return _forwAction;
    }

    /**
     * Set true when the back or forward actions are active to avoid the normal history stack handling
     *
     * @param noStack if true, avoid the normal history stack handling
     */
    public void setNoStack(boolean noStack) {
        _noStack = noStack;
    }
}
