/*
 * $Id: DivaImageGraphics.java,v 1.8 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.image.graphics;

import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.Shape;
import java.awt.Paint;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Composite;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.lang.Runnable;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.List;
import javax.media.jai.JAI;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import diva.canvas.Figure;
import diva.canvas.FigureLayer;
import diva.canvas.GraphicsPane;
import diva.canvas.interactor.SelectionInteractor;
import diva.canvas.interactor.DragInteractor;
import diva.canvas.interactor.SelectionListener;
import diva.canvas.interactor.BoundsManipulator;
import diva.canvas.interactor.PathManipulator;
import diva.canvas.interactor.SelectionEvent;
import diva.canvas.interactor.SelectionModel;
import diva.canvas.interactor.Interactor;
import diva.canvas.event.LayerAdapter;
import diva.canvas.event.LayerEvent;
import diva.canvas.toolbox.BasicHighlighter;
import diva.canvas.toolbox.BasicFigure;
import jsky.coords.CoordinateConverter;
import jsky.graphics.CanvasFigure;
import jsky.graphics.CanvasFigureGroup;
import jsky.graphics.CanvasGraphics;
import jsky.graphics.SelectedAreaListener;
import jsky.image.gui.DivaGraphicsImageDisplay;
import jsky.image.gui.GraphicsImageDisplay;
import jsky.util.gui.BasicWindowMonitor;


/**
 * Implements drawing for image overlays. It is based on the Diva package.
 * <p/>
 * See <a href="http://www.gigascale.org/diva/">The Diva package</a>
 *
 * @author Allan Brighton
 * @version $Revision: 1.8 $
 */
public class DivaImageGraphics implements CanvasGraphics {

    /**
     * The image display that we are drawing on
     */
    private GraphicsImageDisplay _imageDisplay;

    /**
     * The Diva pane (with selection support) to draw on
     */
    private GraphicsPane _graphicsPane;

    /**
     * The Diva layer to draw on
     */
    private FigureLayer _figureLayer;

    /**
     * The Diva layer containing the image
     */
    private ImageLayer _imageLayer;

    /**
     * An interactor that allows selection, dragging and resizing figures
     */
    private SelectionInteractor _selectionInteractor;

    /**
     * An interactor that allows selection, dragging, rotating and resizing figures
     */
    private SelectionInteractor _roiSelectionInteractor;

    /**
     * An interactor for lines.
     */
    private SelectionInteractor _lineInteractor;

    /**
     * An interactor that allows dragging figures
     */
    private DragInteractor _dragInteractor;

    /**
     * An interactor that allows selecting figures, but not dragging or resizing
     */
    private SelectionInteractor _fixedSelectionInteractor;

    /**
     * An object that listens for changes in the figure selection
     */
    private SelectionListener _selectionListener;

    /**
     * Used for selecting all objects in a rectangular region
     */
    private SelectionDragger _selectionDragger;

    /**
     * Set of currently selected figures
     */
    private Set<CanvasFigure> _selectedSet;


    /**
     * Construct an object for drawing on the given image display.
     *
     * @param imageDisplay the image display to draw on
     */
    public DivaImageGraphics(DivaGraphicsImageDisplay imageDisplay) {
        _imageDisplay = imageDisplay;
        _graphicsPane = (GraphicsPane) imageDisplay.getCanvasPane();
        _graphicsPane.setAntialiasing(false);
        _imageLayer = _makeImageLayer();
        _graphicsPane.setBackgroundLayer(_imageLayer);
        _figureLayer = _graphicsPane.getForegroundLayer();
        _graphicsPane.getBackgroundEventLayer().addLayerListener(new LayerAdapter() {
            public void mousePressed(LayerEvent e) {
                clearSelection();
            }
        });

        // make the interactors, which determine how the user can interact with a figure
        _selectedSet = new HashSet<CanvasFigure>();
        _makeSelectionListener();
        _makeDragInteractor();
        _makeSelectionInteractor();
        _makeRoiSelectionInteractor();
        _makeLineInteractor();
        _makeFixedSelectionInteractor();
        _makeSelectionDragger();
    }

    /**
     * @return the Diva graphics pane.
     */
    public GraphicsPane getGraphicsPane() {
        return _graphicsPane;
    }

    /**
     * Make and return the image layer. This is the background layer used
     * to display the image, but can also be used by derived classes for
     * drawing directly on the image.
     *
     * @return teh image layer
     */
    private ImageLayer _makeImageLayer() {
        return new ImageLayer((DivaGraphicsImageDisplay) _imageDisplay);
    }

    /**
     * @return the Diva layer containing the image
     */
    public ImageLayer getImageLayer() {
        return _imageLayer;
    }

    /**
     * Make an Interactor for figures that may be selected, resized and moved.
     */
    private void _makeSelectionInteractor() {
        BoundsManipulator boundsManipulator = new BoundsManipulator();
        boundsManipulator.getHandleInteractor().addLayerListener(new LayerAdapter() {

            public void mouseReleased(LayerEvent e) {
                Figure fig = e.getFigureSource();
                if (fig instanceof CanvasFigure) {
                    ((CanvasFigure) fig).fireCanvasFigureEvent(CanvasFigure.RESIZED);
                }
            }
        });

        // Create a movable, resizable selection interactor
        _selectionInteractor = new SelectionInteractor();
        _selectionInteractor.setPrototypeDecorator(boundsManipulator);
        _selectionInteractor.getSelectionModel().addSelectionListener(_selectionListener);
        _selectionInteractor.addInteractor(_dragInteractor);
    }

    /**
     * Make an Interactor for figures that may be selected, resized and moved.
     */
    private void _makeRoiSelectionInteractor() {
        RectangleManipulator rectangleManipulator = new RectangleManipulator();
        rectangleManipulator.getHandleInteractor().addLayerListener(new LayerAdapter() {

            public void mouseReleased(LayerEvent e) {
                Figure fig = e.getFigureSource();
                if (fig instanceof CanvasFigure) {
                    ((CanvasFigure) fig).fireCanvasFigureEvent(CanvasFigure.RESIZED);
                }
            }
        });

        // Create a movable, resizable selection interactor
        _roiSelectionInteractor = new SelectionInteractor();
        _roiSelectionInteractor.setPrototypeDecorator(rectangleManipulator);
        // connect the different selection models
        _roiSelectionInteractor.setSelectionModel(_selectionInteractor.getSelectionModel());
        _roiSelectionInteractor.addInteractor(_dragInteractor);
    }

    /**
     * Make an Interactor for lines.
     */
    private void _makeLineInteractor() {
        PathManipulator pathManipulator = new PathManipulator();
        pathManipulator.getHandleInteractor().addLayerListener(new LayerAdapter() {

            public void mouseReleased(LayerEvent e) {
                Figure fig = e.getFigureSource();
                if (fig instanceof CanvasFigure) {
                    ((CanvasFigure) fig).fireCanvasFigureEvent(CanvasFigure.RESIZED);
                }
            }
        });

        // Create a movable, resizable selection interactor
        _lineInteractor = new SelectionInteractor(_selectionInteractor.getSelectionModel());
        _lineInteractor.setPrototypeDecorator(pathManipulator);
        _lineInteractor.getSelectionModel().addSelectionListener(_selectionListener);
        _lineInteractor.addInteractor(_dragInteractor);
    }


    /**
     * Make the object that listens for changes in the figure selection and
     * notifies the target figure listeners.
     */
    private void _makeSelectionListener() {
        _selectionListener = new SelectionListener() {

            public void selectionChanged(SelectionEvent e) {
                try {
                    Iterator it = e.getSelectionAdditions();
                    while (it.hasNext()) {
                        Object o = it.next();
                        if (o instanceof CanvasFigure) {
                            CanvasFigure f = (CanvasFigure) o;
                            _selectedSet.add(f);
                            f.fireCanvasFigureEvent(CanvasFigure.SELECTED);
                        }
                    }
                } catch (Exception ignored) {
                    // XXX got a null reference in Diva during testing...
                }
                try {
                    Iterator it = e.getSelectionRemovals();
                    while (it.hasNext()) {
                        Object o = it.next();
                        if (o instanceof CanvasFigure) {
                            CanvasFigure f = (CanvasFigure) o;
                            _selectedSet.remove(f);
                            ((CanvasFigure) o).fireCanvasFigureEvent(CanvasFigure.DESELECTED);
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        };
    }

    /**
     * @return the list of currently selected figures
     */
    public List<CanvasFigure> getSelectedFigures() {
        return new ArrayList<CanvasFigure>(_selectedSet);
    }


    /**
     * Make the drag interactor, for figures that may be dragged.
     */
    private void _makeDragInteractor() {
        _dragInteractor = new DragInteractor();
        _dragInteractor.addLayerListener(new LayerAdapter() {

            public void mouseReleased(LayerEvent e) {
                Figure fig = e.getFigureSource();
                if (fig instanceof CanvasFigure) {
                    ((CanvasFigure) fig).fireCanvasFigureEvent(CanvasFigure.MOVED);
                }
            }
        });
    }


    /**
     * Make the drag interactor, for figures that may be dragged.
     */
    private void _makeFixedSelectionInteractor() {
        // create an fixed position, unresizable interactor
        SelectionModel model = _selectionInteractor.getSelectionModel();
        _fixedSelectionInteractor = new SelectionInteractor(model);
        // highlighting will draw a partially see-through rectangle over the figure
        Composite composite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.75F);
        BasicHighlighter h = new BasicHighlighter(new Color(204, 204, 255), 1.0F, composite);
        _fixedSelectionInteractor.setPrototypeDecorator(h);
    }


    /**
     * Make the selection drag-selector (for selecting all objects in a rectangular region)
     */
    private void _makeSelectionDragger() {
        _selectionDragger = new SelectionDragger(_graphicsPane) {

            public void mouseReleased(LayerEvent e) {
                super.mouseReleased(e);
                setEnabled(false);
            }
        };
        _selectionDragger.addSelectionInteractor(_selectionInteractor);
        _selectionDragger.addSelectionInteractor(_lineInteractor);
        _selectionDragger.addSelectionInteractor(_fixedSelectionInteractor);
        _selectionDragger.setEnabled(false);
    }

    /**
     * @return the object used for selecting all objects in a rectangular region
     */
    public SelectionDragger getSelectionDragger() {
        return _selectionDragger;
    }

    /**
     * @return an interactor that allows dragging figures
     */
    public DragInteractor getDragInteractor() {
        return _dragInteractor;
    }

    /**
     * @return an interactor that allows selection, dragging and resizing figures
     */
    public SelectionInteractor getSelectionInteractor() {
        return _selectionInteractor;
    }

    /**
     * @return an interactor that allows selection, rotation, dragging and resizing figures
     */
    public SelectionInteractor getRoiSelectionInteractor() {
        return _roiSelectionInteractor;
    }

    /**
     * @return an interactor for lines
     */
    public SelectionInteractor getLineInteractor() {
        return _lineInteractor;
    }

    /**
     * @return an interactor that allows selecting figures, but not dragging or resizing
     */
    public SelectionInteractor getFixedSelectionInteractor() {
        return _fixedSelectionInteractor;
    }


    /**
     * Make and return a labeled figure with the given shape, fill, outline and
     * line width. The shape is expected to be in screen coordinates.
     * If a label is specified, it will be attached to the figure using
     * the given anchor argument for the relative position.
     * <p/>
     * The CoordinateConverter object in the image display class may be
     * used while constructing the shape to convert to screen coordinates.
     * <p/>
     * Event handling for figures is done through Diva Interactors.
     * A number of common interactors are defined in this class
     * for dragging and selecting figures. When selecting figures,
     * the Diva SelectionModel class can also be used to get notification
     * whenever the selection changes. When dragging figures, the DragIterator
     * class has listener methods that can notify you whenever a figure is
     * dragged.
     *
     * @param shape      the shape to draw
     * @param fill       the paint to use to fill the shape
     * @param outline    the paint to use for the outline
     * @param lineWidth  the width of the shape lines in pixels
     * @param label      an optional label text to be displayed with the figure (may be null)
     * @param anchor     {@link SwingConstants} value for label position
     * @param labelColor color of the label
     * @param font       the label's font
     * @param interactor determines the behavior of the figure (may be null)
     * @return the handle for  the figure
     * @see CoordinateConverter
     * @see GraphicsImageDisplay
     */
    public CanvasFigure makeLabeledFigure(Shape shape, Paint fill, Paint outline, float lineWidth,
                                          String label, int anchor, Paint labelColor, Font font,
                                          Interactor interactor) {
        if (label == null || label.length() == 0) {
            return new ImageFigure(shape, fill, outline, lineWidth, interactor);
        } else {
            return new LabeledImageFigure(new ImageFigure(shape, fill, outline, lineWidth, null),
                    label, anchor, labelColor, font, interactor);
        }
    }


    /**
     * Make and return a figure with the given shape, fill, outline and
     * line width. The shape is expected to be in screen coordinates.
     * If a label is specified, it will be attached to the figure using
     * the given anchor argument for the relative position.
     *
     * @param shape      the shape to draw
     * @param fill       the paint to use to fill the shape
     * @param outline    the paint to use for the outline
     * @param lineWidth  the width of the shape lines in pixels
     * @param composite  the composite to use (transparency)
     * @param interactor determines the behavior of the figure (may be null)
     * @return the handle for  the figure
     */
    public CanvasFigure makeFigure(Shape shape, Paint fill, Paint outline, float lineWidth, Composite composite,
                                   Interactor interactor) {
        CanvasFigure fig = makeFigure(shape, fill, outline, lineWidth, interactor);
        if (composite != null && fig instanceof BasicFigure) {
            ((BasicFigure) fig).setComposite((AlphaComposite) composite);
        }
        return fig;
    }

    /**
     * Make and return a figure with the given shape, fill, outline and
     * line width. The shape is expected to be in screen coordinates.
     * If a label is specified, it will be attached to the figure using
     * the given anchor argument for the relative position.
     *
     * @param shape      the shape to draw
     * @param fill       the paint to use to fill the shape
     * @param outline    the paint to use for the outline
     * @param lineWidth  the width of the shape lines in pixels
     * @param interactor determines the behavior of the figure (may be null)
     * @return the handle for  the figure
     */
    public RotatableCanvasFigure makeFigure(Shape shape, Paint fill, Paint outline, float lineWidth,
                                   Interactor interactor) {
        if (shape instanceof Rectangle2D.Double) {
            RotatableCanvasFigure fig = makeRoiRectangle((Rectangle2D.Double) shape, fill, outline, lineWidth);
            fig.setInteractor(interactor);
            return fig;
        } else if (shape instanceof Ellipse2D.Double) {
            RotatableCanvasFigure fig = makeRoiEllipse((Ellipse2D.Double) shape, fill, outline, lineWidth);
            fig.setInteractor(interactor);
            return fig;
        }
//        return new ImageFigure(shape, fill, outline, lineWidth, interactor);
        return new RoiFigure(shape, fill, outline, lineWidth, interactor);
    }


    /**
     * Make and return a labeled figure with the given shape, fill, outline and line width.
     * The shape is expected to be in screen coordinates.
     *
     * @param shape      the shape to draw
     * @param fill       the paint to use to fill the shape
     * @param outline    the paint to use for the outline
     * @param lineWidth  the width of the shape lines in pixels
     * @param label      an optional label text to be displayed with the figure (may be null)
     * @param anchor     {@link SwingConstants} value for label position
     * @param labelColor color of the label
     * @param font       the label's font
     * @return an object representing the figure
     */
    public CanvasFigure makeLabeledFigure(Shape shape, Paint fill, Paint outline, float lineWidth,
                                          String label, int anchor, Paint labelColor, Font font) {
        return makeLabeledFigure(shape, fill, outline, lineWidth, label, anchor, labelColor, font,
                _fixedSelectionInteractor);
    }

    /**
     * Make and return a figure with the given shape, fill, outline and line width.
     * The shape is expected to be in screen coordinates.
     *
     * @param shape     the shape to draw
     * @param fill      the paint to use to fill the shape
     * @param outline   the paint to use for the outline
     * @param lineWidth the width of the shape lines in pixels
     * @return an object representing the figure
     */
    public CanvasFigure makeFigure(Shape shape, Paint fill, Paint outline, float lineWidth) {
        return makeFigure(shape, fill, outline, lineWidth, _fixedSelectionInteractor);
    }

    /**
     * This is a convenience method for making a labeled rectangle that allows you to
     * specify the type of the coordinates given by the rect argument.
     * The rect argument is converted to screen coordinates before creating the figure as
     * in add(Shape shape, Paint fill, Paint outline, float lineWidth, Interactor interactor).
     *
     * @param rect       the coordinate of the rect
     * @param coordType  {@link CoordinateConverter} constant for the type of the coordinates
     * @param fill       the fill color
     * @param outline    the outline color
     * @param lineWidth  the line width
     * @param label      the text of the label
     * @param anchor     {@link SwingConstants} value for label position
     * @param labelColor the label color
     * @param font       the label font
     * @param interactor the interactor for the figure ({@link SelectionInteractor},
     *                   {@link DragInteractor}, etc.)
     * @return the new figure
     */
    public CanvasFigure makeLabeledRectangle(Rectangle2D.Double rect, int coordType, Paint fill,
                                             Paint outline, float lineWidth,
                                             String label, int anchor, Paint labelColor, Font font,
                                             Interactor interactor) {
        CoordinateConverter coordinateConverter = _imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double(rect.x, rect.y);
        coordinateConverter.convertCoords(p, coordType, CoordinateConverter.SCREEN, false);
        Point2D.Double size = new Point2D.Double(rect.width, rect.height);
        coordinateConverter.convertCoords(size, coordType, CoordinateConverter.SCREEN, true);
        Rectangle2D.Double r = new Rectangle2D.Double(p.x, p.y, size.x, size.y);
        return makeLabeledFigure(r, fill, outline, lineWidth, label, anchor, labelColor, font, interactor);
    }

    /**
     * This is a convenience method for making rectangles that allows you to
     * specify the type of the coordinates given by the rect argument.
     * The rect argument is converted to screen coordinates before creating the figure as
     * in add(Shape shape, Paint fill, Paint outline, float lineWidth, Interactor interactor).
     *
     * @param rect       the coordinate of the rect
     * @param coordType  {@link CoordinateConverter} constant for the type of the coordinates
     * @param fill       the fill color
     * @param outline    the outline color
     * @param lineWidth  the line width
     * @param interactor the interactor for the figure (SelctionInteractor, DragInteractor, etc.)
     * @return the new figure
     */
    public CanvasFigure makeRectangle(Rectangle2D.Double rect, int coordType, Paint fill,
                                      Paint outline, float lineWidth, Interactor interactor) {
        CoordinateConverter coordinateConverter = _imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double(rect.x, rect.y);
        coordinateConverter.convertCoords(p, coordType, CoordinateConverter.SCREEN, false);
        Point2D.Double size = new Point2D.Double(rect.width, rect.height);
        coordinateConverter.convertCoords(size, coordType, CoordinateConverter.SCREEN, true);
        Rectangle2D.Double r = new Rectangle2D.Double(p.x, p.y, size.x, size.y);
        return makeFigure(r, fill, outline, lineWidth, interactor);
    }

    /**
     * Makes a rotatable ROI rectangle with the given screen coordinate rectangle
     *
     * @param rect      the coordinate of the rect
     * @param fill      the fill color
     * @param outline   the outline color
     * @param lineWidth the line width
     * @return the new figure
     */
    public RotatableCanvasFigure makeRoiRectangle(Rectangle2D.Double rect, Paint fill,
                                         Paint outline, float lineWidth) {
        return makeRoiRectangle(rect, CoordinateConverter.SCREEN, fill, outline, lineWidth);
    }

    /**
     * Makes a rotatable ROI rectangle
     *
     * @param rect      the coordinate of the rect
     * @param coordType {@link CoordinateConverter} constant for the type of the coordinates
     * @param fill      the fill color
     * @param outline   the outline color
     * @param lineWidth the line width
     * @return the new figure
     */
    public RotatableCanvasFigure makeRoiRectangle(Rectangle2D.Double rect, int coordType, Paint fill,
                                         Paint outline, float lineWidth) {
        CoordinateConverter coordinateConverter = _imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double(rect.x, rect.y);
        coordinateConverter.convertCoords(p, coordType, CoordinateConverter.SCREEN, false);
        Point2D.Double size = new Point2D.Double(rect.width, rect.height);
        coordinateConverter.convertCoords(size, coordType, CoordinateConverter.SCREEN, true);

        Rectangle2D.Double r = new Rectangle2D.Double(p.x, p.y, size.x, size.y);
        return new RoiRectangle(r, fill, outline, lineWidth, _roiSelectionInteractor);
    }


    /**
     * Makes a rotatable ROI ellipse with the given screen coordinate ellipse
     *
     * @param ellipse   the coordinate of the ellipse
     * @param fill      the fill color
     * @param outline   the outline color
     * @param lineWidth the line width
     * @return the new figure
     */
    public RotatableCanvasFigure makeRoiEllipse(Ellipse2D.Double ellipse, Paint fill,
                                       Paint outline, float lineWidth) {

        return makeRoiEllipse(ellipse, CoordinateConverter.SCREEN, fill, outline, lineWidth);
    }


    /**
     * Makes a rotatable ROI ellipse
     *
     * @param ellipse   the coordinate of the rect
     * @param coordType {@link CoordinateConverter} constant for the type of the coordinates
     * @param fill      the fill color
     * @param outline   the outline color
     * @param lineWidth the line width
     * @return the new figure
     */
    public RotatableCanvasFigure makeRoiEllipse(Ellipse2D.Double ellipse, int coordType, Paint fill,
                                       Paint outline, float lineWidth) {
        CoordinateConverter coordinateConverter = _imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double(ellipse.x, ellipse.y);
        coordinateConverter.convertCoords(p, coordType, CoordinateConverter.SCREEN, false);
        Point2D.Double size = new Point2D.Double(ellipse.width, ellipse.height);
        coordinateConverter.convertCoords(size, coordType, CoordinateConverter.SCREEN, true);

        Ellipse2D.Double e = new Ellipse2D.Double(p.x, p.y, size.x, size.y);
        return new RoiEllipse(e, fill, outline, lineWidth, _roiSelectionInteractor);
    }

    /**
     * This is a convenience method for drawing a labeled ellipse that allows you to
     * specify the type of the coordinates given by the ellipse argument.
     * The ellipse argument is converted to screen coordinates before creating the figure as
     * in makeFigure(Shape shape, Paint fill, Paint outline, float lineWidth, Interactor interactor).
     *
     * @param ellipse    the coordinate of the ellipse
     * @param coordType  {@link CoordinateConverter} constant for the type of the coordinates
     * @param fill       the fill color
     * @param outline    the outline color
     * @param lineWidth  the line width
     * @param label      the text of the label
     * @param anchor     {@link SwingConstants} value for label position
     * @param labelColor the label color
     * @param font       the label font
     * @param interactor the interactor for the figure (SelctionInteractor, DragInteractor, etc.)
     * @return the new figure
     */
    public CanvasFigure makeLabeledEllipse(Ellipse2D.Double ellipse, int coordType, Paint fill,
                                           Paint outline, float lineWidth,
                                           String label, int anchor, Paint labelColor, Font font,
                                           Interactor interactor) {
        CoordinateConverter coordinateConverter = _imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double(ellipse.x, ellipse.y);
        coordinateConverter.convertCoords(p, coordType, CoordinateConverter.SCREEN, false);
        Point2D.Double size = new Point2D.Double(ellipse.width, ellipse.height);
        coordinateConverter.convertCoords(size, coordType, CoordinateConverter.SCREEN, true);
        Ellipse2D.Double r = new Ellipse2D.Double(p.x, p.y, size.x, size.y);
        return makeLabeledFigure(r, fill, outline, lineWidth, label, anchor, labelColor, font, interactor);
    }

    /**
     * This is a convenience method for drawing ellipses that allows you to
     * specify the type of the coordinates given by the ellipse argument.
     * The ellipse argument is converted to screen coordinates before creating the figure as
     * in makeFigure(Shape shape, Paint fill, Paint outline, float lineWidth, Interactor interactor).
     * This is a convenience method for making rectangles that allows you to
     * specify the type of the coordinates given by the rect argument.
     * The rect argument is converted to screen coordinates before creating the figure as
     * in add(Shape shape, Paint fill, Paint outline, float lineWidth, Interactor interactor).
     *
     * @param ellipse    the coordinate of the ellipse
     * @param coordType  {@link CoordinateConverter} constant for the type of the coordinates
     * @param fill       the fill color
     * @param outline    the outline color
     * @param lineWidth  the line width
     * @param interactor the interactor for the figure (SelctionInteractor, DragInteractor, etc.)
     * @return the new figure
     */
    public RotatableCanvasFigure makeEllipse(Ellipse2D.Double ellipse, int coordType, Paint fill,
                                    Paint outline, float lineWidth, Interactor interactor) {
        CoordinateConverter coordinateConverter = _imageDisplay.getCoordinateConverter();
        Point2D.Double p = new Point2D.Double(ellipse.x, ellipse.y);
        coordinateConverter.convertCoords(p, coordType, CoordinateConverter.SCREEN, false);
        Point2D.Double size = new Point2D.Double(ellipse.width, ellipse.height);
        coordinateConverter.convertCoords(size, coordType, CoordinateConverter.SCREEN, true);
        Ellipse2D.Double r = new Ellipse2D.Double(p.x, p.y, size.x, size.y);
        return makeFigure(r, fill, outline, lineWidth, interactor);
    }


    /**
     * Make and return a canvas label.
     *
     * @param pos        the label position
     * @param text       the text of the label to draw
     * @param color      the paint to use to draw the text
     * @param font       the font to use for the label
     * @param interactor determines the behavior of the figure (may be null)
     * @return the new figure
     */
    public CanvasFigure makeLabel(Point2D.Double pos, String text, Paint color,
                                  Font font, Interactor interactor) {
        return new ImageLabel(text, pos, color, font, interactor);
    }

    /**
     * Make and return a canvas label.
     *
     * @param text  the text of the label to draw
     * @param pos   the label position
     * @param color the paint to use to draw the text
     * @param font  the font to use for the label
     */
    public CanvasFigure makeLabel(Point2D.Double pos, String text, Paint color, Font font) {
        return new ImageLabel(text, pos, color, font, null);
    }


    /**
     * Make and return a new CanvasFigureGroup object that can be used as a
     * figure container to hold other figures.
     *
     * @param interactor determines the selection behavior of the figure group (may be null)
     * @return the new figure
     */
    public CanvasFigureGroup makeFigureGroup(Interactor interactor) {
        return new ImageFigureGroup(interactor);
    }


    /**
     * Make and return a new CanvasFigureGroup object that can be used as a
     * figure container to hold other figures.
     */
    public CanvasFigureGroup makeFigureGroup() {
        return new ImageFigureGroup(_fixedSelectionInteractor);
    }

    /**
     * Add the given figure to the canvas.
     */
    public void add(CanvasFigure fig) {
        _figureLayer.add(fig);
    }

    /**
     * Remove the given figure from the display.
     */
    public void remove(CanvasFigure fig) {
        Interactor interactor = fig.getInteractor();
        if (interactor instanceof SelectionInteractor) {
            // remove any selection handles, etc.
            SelectionModel model = ((SelectionInteractor) interactor).getSelectionModel();
            if (model.containsSelection(fig)) {
                model.removeSelection(fig);
            }
        }
        _figureLayer.remove(fig);
    }

    /**
     * Select the given figure.
     */
    public void select(CanvasFigure fig) {
        Interactor i = fig.getInteractor();
        if (i instanceof SelectionInteractor) {
            ((SelectionInteractor) i).getSelectionModel().addSelection(fig);
        }
    }

    /**
     * Deselect the given figure.
     */
    public void deselect(CanvasFigure fig) {
        Interactor i = fig.getInteractor();
        if (i instanceof SelectionInteractor) {
            ((SelectionInteractor) i).getSelectionModel().removeSelection(fig);
        }
    }

    /**
     * Clear the selection.
     */
    public void clearSelection() {
        _selectionInteractor.getSelectionModel().clearSelection();
        _roiSelectionInteractor.getSelectionModel().clearSelection();
    }

    /**
     * Schedule the removal of the given figure from the display at a later time.
     * This version may be used to avoid problems with iterators working on a
     * a list of figures that should not be modified inside the loop.
     */
    public void scheduleRemoval(CanvasFigure fig) {
        SwingUtilities.invokeLater(new FigureRemover(fig));
    }


    /**
     * Return the number of figures.
     */
    public int getFigureCount() {
        return _figureLayer.getFigureCount();
    }


    /**
     * Transform all graphics according to the given AffineTransform object.
     */
    public void transform(AffineTransform trans) {
        // iterate over all figures in the foreground layer
        Iterator it = _figureLayer.figures();
        while (it.hasNext()) {
            Figure fig = (Figure) (it.next());
            fig.transform(trans);
        }
    }


    /**
     * Set the interaction mode for the given figure to an OR'ed combination of
     * the following constants: SELECT, MOVE, RESIZE, ROTATE.
     * For example, if mode is (SELECT | MOVE | RESIZE), the figure can be selected,
     * moved, and resized. (Note that MOVE, RESIZE and ROTATE automatically assume
     * SELECT).
     */
    public void setInteractionMode(CanvasFigure fig, int mode) {
        Interactor interactor = null;
        if ((mode & (ROTATE | MOVE | RESIZE)) != 0) {
            mode |= SELECT;
        }

        if (mode == SELECT) {
            interactor = _fixedSelectionInteractor;
        } else if (mode == (SELECT | MOVE)) {
            interactor = _dragInteractor;
        } else if (mode == (SELECT | MOVE | RESIZE)) {
            interactor = _selectionInteractor;
        }

        // XXX else: implement other combinations

        fig.setInteractor(interactor);
    }


    /**
     * Local class used to remove a figure at a later time
     */
    private class FigureRemover implements Runnable {

        CanvasFigure fig;

        public FigureRemover(CanvasFigure fig) {
            this.fig = fig;
        }

        public void run() {
            remove(fig);
        }
    }

    /**
     * Wait for the user to drag out an area on the image canvas and then
     * notify the listener with the coordinates of the box.
     */
    public void selectArea(final SelectedAreaListener l) {
        SelectionDragger sd = new SelectionDragger(_graphicsPane) {

            public void mouseReleased(LayerEvent e) {
                super.mouseReleased(e);
                setEnabled(false);
                Rectangle2D r = getSelectedArea();
                if (r != null) {
                    l.setSelectedArea(r);
                }
            }
        };
        sd.setEnabled(true);
    }

    /**
     * Schedule a repaint of the window containing the graphics.
     */
    public void repaint() {
        _figureLayer.repaint();
    }

    /**
     * Schedule a repaint of the given area of the window containing the graphics.
     *
     * @param region the area of the image to repaint
     */
    public void repaint(Rectangle2D region) {
        _figureLayer.repaint(region);
    }


    /**
     * test main: usage: java GraphicsImageDisplay <filename>.
     *
     * @param args optional image file to display in the background
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("GraphicsImageDisplay");
        DivaGraphicsImageDisplay imageDisplay = new DivaGraphicsImageDisplay();
        imageDisplay.setPreferredSize(new Dimension(600, 500));
        if (args.length > 0) {
            try {
                imageDisplay.setImage(JAI.create("fileload", args[0]));
            } catch (Exception e) {
                System.out.println("error: " + e.toString());
                System.exit(1);
            }
        }

        // Add some test objects
        DivaImageGraphics g = (DivaImageGraphics)imageDisplay.getCanvasGraphics();
        //CoordinateConverter coordinateConverter = imageDisplay.getCoordinateConverter();
        SelectionInteractor si = g.getSelectionInteractor();
        SelectionInteractor rsi = g.getRoiSelectionInteractor();
        SelectionInteractor fsi = g.getFixedSelectionInteractor();
        DragInteractor di = g.getDragInteractor();

        Font font = new Font("Dialog", Font.PLAIN, 12);

        Rectangle2D.Double r1 = new Rectangle2D.Double(30., 30., 30., 40.);
        CanvasFigure fig = g.makeLabeledRectangle(r1, CoordinateConverter.USER, null, Color.blue, 2.0F,
                "Test1", SwingConstants.CENTER, Color.blue, font, si);
        // rotate the rectangle by 30 degrees
        fig.transform(AffineTransform.getRotateInstance(Math.toRadians(30.), 25, 25));
        g.add(fig);

        Rectangle2D.Double r2 = new Rectangle2D.Double(70., 70., 50., 50.);
        g.add(g.makeLabeledRectangle(r2, CoordinateConverter.USER, null, Color.white, 2.0F,
                "Test2", SwingConstants.CENTER, Color.blue, font, fsi));

        Ellipse2D.Double e1 = new Ellipse2D.Double(150., 150., 50., 50.);
        RotatableCanvasFigure imageFig = g.makeEllipse(e1, CoordinateConverter.USER, Color.red, Color.white, 2.0F, rsi);
        imageFig.setResizable(false);
        g.add(imageFig);

        Rectangle2D.Double r4 = new Rectangle2D.Double(120., 180., 20., 60.);
        g.add(g.makeRectangle(r4, CoordinateConverter.USER, Color.green, Color.yellow, 2.0F, si));

        Ellipse2D.Double e3 = new Ellipse2D.Double(20., 220., 50., 20.);
        g.add(g.makeEllipse(e3, CoordinateConverter.USER, null, Color.white, 2.0F, si));

        Ellipse2D.Double e4 = new Ellipse2D.Double(55., 200., 10., 40.);
        g.add(g.makeEllipse(e4, CoordinateConverter.USER, Color.white, Color.yellow, 2.0F, di));

        // test labels
        Point2D.Double pos = new Point2D.Double(10., 150.);
        g.add(g.makeLabel(pos, "Test Label", Color.yellow, font));

        // test grouping
        Rectangle2D.Double r3 = new Rectangle2D.Double(150., 100., 60., 40.);
        CanvasFigure f1 = g.makeRectangle(r3, CoordinateConverter.USER, null, Color.yellow, 2.0F, null);
        Ellipse2D.Double e5 = new Ellipse2D.Double(150., 100., 60., 40.);
        CanvasFigure f2 = g.makeEllipse(e5, CoordinateConverter.USER, null, Color.yellow, 2.0F, null);
        pos = new Point2D.Double(r3.x + 10, r3.y + 25);
        CanvasFigure f3 = g.makeLabel(pos, "Group", Color.yellow, new JLabel().getFont());
        CanvasFigureGroup group = g.makeFigureGroup(rsi);
//        group.setResizable(false);
        // rotate the group by -25 deg
        group.transform(AffineTransform.getRotateInstance(Math.toRadians(-25.), 25, 25));
        group.add(f1);
        group.add(f2);
        group.add(f3);
        g.add(group);

        // ROI figures
        Rectangle2D.Double r5 = new Rectangle2D.Double(250., 180., 40., 60.);
        g.add(g.makeRoiRectangle(r5, CoordinateConverter.USER, Color.green, Color.yellow, 2.0F));

        Ellipse2D.Double e6 = new Ellipse2D.Double(250., 260., 40., 60.);
        g.add(g.makeRoiEllipse(e6, CoordinateConverter.USER, Color.green, Color.yellow, 2.0F));

        // test the area selection once
        g.selectArea(new SelectedAreaListener() {

            public void setSelectedArea(Rectangle2D r) {
                System.out.println("Selected area: " + r);
            }
        });

        frame.getContentPane().add(imageDisplay, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
        frame.addWindowListener(new BasicWindowMonitor());
    }

}

