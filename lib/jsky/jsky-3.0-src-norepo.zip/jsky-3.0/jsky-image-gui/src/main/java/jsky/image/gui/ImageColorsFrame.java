/*
 * ESO Archive
 *
 * $Id: ImageColorsFrame.java,v 1.2 2009/03/06 10:32:13 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/05/03  Created
 */

package jsky.image.gui;


import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.ImageIcon;

import jsky.util.I18N;
import jsky.util.Preferences;
import jsky.util.Resources;


/**
 * Provides a top level window for an ImageColors panel.
 *
 * @version $Revision: 1.2 $
 * @author Allan Brighton
 */
public class ImageColorsFrame extends JFrame {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(ImageColorsFrame.class);

    // The GUI panel
    private ImageColors imageColors;


    /**
     * Create a top level window containing an ImageColors panel.
     */
    public ImageColorsFrame(BasicImageDisplay imageDisplay) {
        super(_I18N.getString("imageColors"));
        setIconImage(new ImageIcon(Resources.getResource("images/Palette.gif")).getImage());
        imageColors = new ImageColors(imageDisplay);
        getContentPane().add(imageColors, BorderLayout.CENTER);
        pack();
        Preferences.manageLocation(this);
        setVisible(true);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
    }

    /** Return the internal panel object */
    public ImageColors getImageColors() {
        return imageColors;
    }
}

