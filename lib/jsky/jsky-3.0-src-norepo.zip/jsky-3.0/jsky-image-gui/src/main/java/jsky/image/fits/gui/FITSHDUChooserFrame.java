/*
 * ESO Archive
 *
 * $Id: FITSHDUChooserFrame.java,v 1.4 2009/03/23 11:54:08 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/05/03  Created
 */

package jsky.image.fits.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.ImageIcon;

import jsky.image.fits.codec.FITSImage;
import jsky.image.gui.MainImageDisplay;
import jsky.util.Preferences;
import jsky.util.Resources;


/**
 * Provides a top level window for an FITSHDUChooser panel.
 *
 * @version $Revision: 1.4 $
 * @author Allan Brighton
 */
public class FITSHDUChooserFrame extends JFrame {

//    // Used to access internationalized strings (see i18n/gui*.proprties)
//    private static final I18N _I18N = I18N.getInstance(FITSHDUChooserFrame.class);

    // The HDU chooser panel
    private FITSHDUChooser _fitsHDUChooser;


    /**
     * Create a top level window containing an FITSHDUChooser panel.
     */
    public FITSHDUChooserFrame(MainImageDisplay imageDisplay, FITSImage fitsImage) {
        super("FITS Extensions");
        setIconImage(new ImageIcon(Resources.getResource("images/colmeta0.gif")).getImage());
        _fitsHDUChooser = new FITSHDUChooser(imageDisplay, fitsImage);
        Preferences.manageSize(_fitsHDUChooser, new Dimension(800, 100));
        getContentPane().add(_fitsHDUChooser, BorderLayout.CENTER);
        pack();
        Preferences.manageLocation(this);
        setVisible(true);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
    }

    /** Return the internal panel object */
    public FITSHDUChooser getFitsHDUChooser() {
        return _fitsHDUChooser;
    }
}

