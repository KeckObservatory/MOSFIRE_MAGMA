/*
 * $Id: ImageGraphicsHandler.java,v 1.2 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.image.gui;

import java.awt.Graphics2D;
import java.util.EventListener;


/**
 *  A callback interface for classes that need to draw graphics over an image.
 *
 * @version $Revision: 1.2 $
 * @author Allan Brighton
 */
public abstract interface ImageGraphicsHandler extends EventListener {

    /** Called each time the image is repainted */
    public void drawImageGraphics(BasicImageDisplay imageDisplay, Graphics2D g);
}


