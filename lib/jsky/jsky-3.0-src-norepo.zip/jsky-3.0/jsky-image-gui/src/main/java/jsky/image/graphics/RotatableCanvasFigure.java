package jsky.image.graphics;

import jsky.graphics.CanvasFigure;

/**
 * Defines common methods for rotatable figures.
 */
public interface RotatableCanvasFigure extends CanvasFigure {

    /**
     * @return the rectangular geometry of the figure's outline. 
     */
    public RectangleGeometry getGeometry();

    /**
     * @return true if the figure should be resizable
     */
    public boolean isResizable();

    /**
     * @param resizable set to true if the figure should be resizable
     */
    public void setResizable(boolean resizable);

}
