/*
 * ESO Archive
 *
 * $Id: FITSEncodeParam.java,v 1.1.1.1 2009/02/17 22:24:17 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/05/03  Created
 */

package jsky.image.fits.codec;

import com.sun.media.jai.codec.ImageEncodeParam;

public class FITSEncodeParam implements ImageEncodeParam {

    public FITSEncodeParam() {
    }
}

