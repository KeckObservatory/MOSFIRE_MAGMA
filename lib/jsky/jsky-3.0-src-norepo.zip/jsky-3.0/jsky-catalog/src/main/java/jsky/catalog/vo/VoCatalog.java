package jsky.catalog.vo;

import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


import uk.ac.starlink.table.StarTable;
import uk.ac.starlink.table.StarTableFactory;
import uk.ac.starlink.vo.RegCapabilityInterface;
import uk.ac.starlink.vo.RegResource;
import uk.ac.starlink.vo.DalQuery;
import uk.ac.starlink.vo.ConeSearch;

import jsky.catalog.*;
import jsky.catalog.astrocat.AstroCatConfig;
import jsky.catalog.skycat.SkycatConfigEntry;
import jsky.catalog.skycat.SkycatConfigFile;
import jsky.coords.CoordinateRadius;
import jsky.coords.Coordinates;
import jsky.coords.WorldCoords;
import jsky.util.NameValue;
import jsky.util.gui.ProgressPanel;
import jsky.util.gui.ProgressException;

/**
 * Represents a catalog server based on the VO standards. The results of a query to this type of catalog are represented
 * by the {@link VoTable} class.
 */
public class VoCatalog implements PlotableCatalog, Serializable {

    private static final long serialVersionUID = 1L;

//    private static final Logger LOG = Logger.getLogger(VoCatalog.class.getName());

    // The access URL for the catalog server
    private URL _url;

    // The display name of this catalog
    private String _name;

    // Optional description
    private String _description;

    // Optional URL describing the catalog
    private URL _docURL;

    // The catalog id
    private String _id;

    // The standard id: One of the values defined in RegCapabilityInterface
    private String _standardId;

    // The parent catalog directory
    private transient CatalogDirectory _parent;

    // Describes the query arguments
    private transient FieldDesc[] _fieldDesc;

    // Panel used to display download progress information
    private transient ProgressPanel _progressPanel;

    // An array of plot symbol descriptions, constructed from the symbol property string
    private transient TablePlotSymbol[] _symbols;

    // Set to true if the user edited the plot symbol definitions
    private transient boolean _symbolsEdited = false;

    // Table data for local catalog
    private transient VoTable _voTable;


    /**
     * Initialize with the values returned from a VO registry query.
     *
     * @param resource   the VO registry resource
     * @param capability describes the type of server, query arguments and return value
     * @param parent     the parent catalog directory (registry)
     */
    public VoCatalog(RegResource resource, RegCapabilityInterface capability, CatalogDirectory parent) {
        _parent = parent;
        _name = resource.getTitle();
        if (_name == null) {
            _name = resource.getShortName();
        }
        if (_name == null) {
            _name = "unknown";
        }
        try {
            _url = new URL(capability.getAccessUrl());
        } catch (Exception e) {
            throw new RuntimeException("Error in access URL for: " + _name, e);
        }
        initQueryArgs();
        _description = resource.getPublisher();
        if (resource.getReferenceUrl() != null && resource.getReferenceUrl().length() != 0) {
            try {
                _docURL = new URL(resource.getReferenceUrl());
            } catch (Exception ignored) {
            }
        }
        _id = resource.getIdentifier();
        _standardId = capability.getStandardId();
    }

    /**
     * Initialize a local catalog from the table data
     *
     * @param voTable contains the table data
     * @throws java.io.IOException on error
     */
    public VoCatalog(VoTable voTable)
            throws IOException {
        _voTable = voTable;
        _voTable.setCatalog(this);
        setName(voTable.getName());
        initQueryArgs();

//        // XXX Add local search capability
//        _fieldDesc = _voTable.getFields();
//        for(FieldDesc fd : _fieldDesc) {
//            if (fd.getDescription() == null && fd instanceof VoFieldDesc) {
//                ((VoFieldDesc)fd).setDescription(fd.getName() + ": Filter with wildcard expression (*, |, ?)");
//            }
//        }
    }


    /**
     * Initializes an array of query arguments for this catalog. This includes arguments that are not sent to the
     * server, such as object name, name server and equinox, which are used only to generate RA,Dec.
     */
    void initQueryArgs() {
        List<FieldDesc> params = new ArrayList<FieldDesc>();
        FieldDescAdapter p;
        if (_voTable == null || _voTable.hasCoordinates()) {
            p = new FieldDescAdapter(SkycatConfigEntry.OBJECT);
            p.setDescription("Enter the name of the object");
            params.add(p);

            p = new FieldDescAdapter(SkycatConfigEntry.NAME_SERVER);
            p.setDescription("Select the name server to use to resolve the object name");
            List<Catalog> l = SkycatConfigFile.getConfigFile().getNameServers();
            NameValue[] ar = new NameValue[l.size()];
            for (int i = 0; i < ar.length; i++) {
                Catalog cat = l.get(i);
                ar[i] = new NameValue(cat.getName(), cat);
            }
            p.setOptions(ar);
            params.add(p);

            p = new FieldDescAdapter(SkycatConfigEntry.RA);
            p.setIsRA(true);
            p.setDescription("Right Ascension in the selected equinox, format: hh:mm:ss.sss");
            params.add(p);

            p = new FieldDescAdapter(SkycatConfigEntry.DEC);
            p.setDescription("Declination in the selected equinox, format: dd:mm:ss.sss");
            p.setIsDec(true);
            params.add(p);

            p = new FieldDescAdapter(SkycatConfigEntry.EQUINOX);
            p.setDescription("Equinox of RA and Dec");
            p.setOptions(SkycatConfigEntry.getEquinoxOptions());
            params.add(p);

            p = new FieldDescAdapter(SkycatConfigEntry.MAX_RADIUS);
            p.setDescription("The search radius from the center coordinates in arcmin");
            p.setFieldClass(Double.class);
            p.setUnits("arcmin");
            params.add(p);
        }
        p = new FieldDescAdapter(SkycatConfigEntry.MAX_OBJECTS);
        p.setDescription("The maximum number of objects to return");
        p.setFieldClass(Integer.class);
        p.setDefaultValue(1000);
        params.add(p);

        FieldDesc[] fd = new FieldDescAdapter[params.size()];
        params.toArray(fd);
        _fieldDesc = fd;
    }

    /**
     * Implementation of the clone method (makes a shallow copy).
     */
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public String getDescription() {
        return _description;
    }


    public URL getDocURL() {
        return _docURL;
    }


    public String getId() {
        return _id;
    }


    public String getName() {
        return _name;
    }


    public int getNumParams() {
        return _fieldDesc.length;
    }


    public FieldDesc getParamDesc(int i) {
        return _fieldDesc[i];
    }


    public FieldDesc getParamDesc(String name) {
        for (FieldDesc fd : _fieldDesc) {
            if (fd.getName().equals(name)) {
                return fd;
            }
        }
        return null;
    }


    public CatalogDirectory getParent() {
        return _parent;
    }


    public Catalog[] getPath() {
        CatalogDirectory parent = getParent();
        if (parent == null) {
            return null;
        }

        return parent.getPath(this);
    }


    public String getTitle() {
        return _name;
    }


    public String getType() {
        if (_voTable != null) {
            return LOCAL;
        }
        if (RegCapabilityInterface.CONE_STDID.equals(_standardId)) {
            return CATALOG;
        }
        return ARCHIVE;
    }


    public boolean isImageServer() {
        return false;
    }


    public boolean isLocal() {
        return _voTable != null;
    }


    public QueryResult query(QueryArgs queryArgs) throws IOException {
        _setRegion(queryArgs);
        _setMaxRows(queryArgs);
        int maxRows = queryArgs.getMaxRows();

        // check if it is a local catalog
        if (_voTable != null) {
            if (!_voTable.hasCoordinates() && queryArgs.getMaxRows() >= _voTable.getRowCount()) {
                return _voTable; // Just return the whole table
            }
            QueryResult result = _voTable.query(queryArgs);
            if (result instanceof TableQueryResult) {
                ((TableQueryResult) result).setCatalog(this);
            }
            return result;
        }

        CoordinateRadius cr = queryArgs.getRegion();
        if (cr == null) {
            cr = new CoordinateRadius(new WorldCoords(), 15);
        }
        Coordinates coords = cr.getCenterPosition();
        double ra = coords.getX();
        double dec = coords.getY();
        double radius = cr.getMaxRadius();

        _progressPanel = _getProgressPanel("Downloading query results ...");
        _progressPanel.start();

        try {
            StarTableFactory factory = new StarTableFactory();
            StarTable starTable = null;
            if (RegCapabilityInterface.SIA_STDID.equals(_standardId)) {
                _progressPanel.setText("Performing SIAP query: " + _url);
                // convert raSize and decSize to degrees for query
                DalQuery sq = new DalQuery(_url.toString(), ra, dec, radius / 60.);
                starTable = sq.execute(factory);
            } else if (RegCapabilityInterface.CONE_STDID.equals(_standardId)) {
                _progressPanel.setText("Performing cone search: " + _url);
                ConeSearch cs = new ConeSearch(_url.toString());
                // convert radius to degrees for query
                starTable = cs.performSearch(ra, dec, radius / 60., 0, factory);
            } else if (RegCapabilityInterface.SSA_STDID.equals(_standardId)) {
                _progressPanel.setText("Performing SSA query: " + _url);
                DalQuery sq = new DalQuery(_url.toString(), ra, dec, radius / 60.);
                sq.addArgument("REQUEST", "queryData");
                starTable = sq.execute(factory);
            }

            if (_progressPanel.isInterrupted()) {
                throw new ProgressException("Interrupted");
            }

            if (starTable == null) {
                throw new RuntimeException("Catalog type not supported: " + _standardId);
            } else {
                return VoTable.createVoTable(starTable, this, maxRows);
            }

        } finally {
            _progressPanel.stop();
        }
    }


    public void setName(String name) {
        _name = name;
    }


    public void setParent(CatalogDirectory parent) {
        _parent = parent;

    }


    /**
     * Given a description of a region of the sky (center point and radius range), and the current query argument
     * settings, set the values of the corresponding query parameters.
     *
     * @param queryArgs (in/out) describes the query arguments
     * @param region    (in) describes the query region (center and radius range)
     */
    public void setRegionArgs(QueryArgs queryArgs, CoordinateRadius region) {
        Coordinates coords = region.getCenterPosition();
        WorldCoords pos = (WorldCoords) coords;
        String[] radec = pos.format();
        queryArgs.setParamValue(SkycatConfigEntry.RA, radec[0]);
        queryArgs.setParamValue(SkycatConfigEntry.DEC, radec[1]);
        String equinoxStr = (String) queryArgs.getParamValue(SkycatConfigEntry.EQUINOX);
        queryArgs.setParamValue(SkycatConfigEntry.EQUINOX, equinoxStr);
        queryArgs.setParamValue(SkycatConfigEntry.MAX_RADIUS, region.getMaxRadius());
        queryArgs.setParamValue(SkycatConfigEntry.WIDTH, region.getWidth());
        queryArgs.setParamValue(SkycatConfigEntry.HEIGHT, region.getHeight());
    }

    /**
     * Extract and set the query region (ra,dec width,height) from the query arguments
     *
     * @param queryArgs the query arguments
     * @throws java.io.IOException if there is an error resolving the object name via name server
     */
    private void _setRegion(QueryArgs queryArgs) throws IOException {
        WorldCoords wcs;
        String objectName = (String) queryArgs.getParamValue(SkycatConfigEntry.OBJECT);
        if (objectName == null || objectName.length() == 0) {
            // no object name specified, check RA and Dec
            String raStr = (String) queryArgs.getParamValue(SkycatConfigEntry.RA);
            String decStr = (String) queryArgs.getParamValue(SkycatConfigEntry.DEC);
            if (raStr == null || decStr == null) {
                return;
            }
            double equinox = _getEquinox(queryArgs);
            wcs = new WorldCoords(raStr, decStr, equinox, true);
        } else {
            // an object name was specified, which needs to be resolved with a nameserver
            Object o = queryArgs.getParamValue(SkycatConfigEntry.NAME_SERVER);
            if (!(o instanceof Catalog)) {
                throw new RuntimeException("No name server was specified");
            }
            wcs = _resolveObjectName(objectName, (Catalog) o);
            queryArgs.setParamValue(SkycatConfigEntry.RA, wcs.getRA().toString());
            queryArgs.setParamValue(SkycatConfigEntry.DEC, wcs.getDec().toString());
            queryArgs.setParamValue(SkycatConfigEntry.EQUINOX, "2000");
        }

        double radius = queryArgs.getParamValueAsDouble(SkycatConfigEntry.MAX_RADIUS, 10.);
        queryArgs.setRegion(new CoordinateRadius(wcs, radius));
    }

    /**
     * Check for a "Max Objects" argument and if found, set queryArgs.maxRows with the value.
     *
     * @param queryArgs the query arguments
     */
    protected void _setMaxRows(QueryArgs queryArgs) {
        if (queryArgs.getMaxRows() != 0) {
            return;
        }

        // look for a min and max radius parameters
        Integer maxObjects = (Integer) queryArgs.getParamValue(SkycatConfigEntry.MAX_OBJECTS);
        if (maxObjects != null) {
            queryArgs.setMaxRows(maxObjects);
        }
    }


    /**
     * Return the equinox setting from the given query arguments object.
     *
     * @param queryArgs the query arguments
     * @return the equinox value (2000 or 1950)
     */
    private double _getEquinox(QueryArgs queryArgs) {
        String equinoxStr = (String) queryArgs.getParamValue(SkycatConfigEntry.EQUINOX);
        double equinox = 2000.;
        if (equinoxStr != null && equinoxStr.endsWith("1950")) {
            equinox = 1950.;
        }
        return equinox;
    }

    /**
     * Resolve the given astronomical object name using the given name server and return the world coordinates
     * corresponding the name.
     *
     * @param objectName the object name
     * @param cat        a name server catalog
     * @return the world coordinates of the object
     * @throws java.io.IOException if there are errors accessing the name server
     */
    private WorldCoords _resolveObjectName(String objectName, Catalog cat) throws IOException {
        QueryArgs queryArgs = new BasicQueryArgs(cat);
        queryArgs.setId(objectName);
        QueryResult r = cat.query(queryArgs);
        if (r instanceof TableQueryResult) {
            Coordinates coords = ((TableQueryResult) r).getCoordinates(0);
            if (coords instanceof WorldCoords) {
                return (WorldCoords) coords;
            }
        }
        throw new RuntimeException("Unexpected result from " + cat.toString());
    }


    /**
     * @param title the title for the panel
     * @return a panel for displaying the progress of a query.
     */
    protected ProgressPanel _getProgressPanel(String title) {
        if (_progressPanel == null) {
            _progressPanel = ProgressPanel.makeProgressPanel(title);
        } else {
            _progressPanel.setTitle(title);
        }
        return _progressPanel;
    }

    /**
     * Return the name of the catalog
     */
    public String toString() {
        return getName();
    }


    // -- Implement the PlottableCatalog Interface --

    /**
     * Set the array of catalog table plot symbol definitions for use with this catalog
     */
    public void setSymbols(TablePlotSymbol[] symbols) {
        _symbols = symbols;
    }

    /**
     * Set to true if the user edited the plot symbol definitions (default: false)
     */
    public void setSymbolsEdited(boolean edited) {
        _symbolsEdited = edited;
    }

    /**
     * Return true if the user edited the plot symbol definitions otherwise false
     */
    public boolean isSymbolsEdited() {
        return _symbolsEdited;
    }

    /**
     * Save the catalog symbol information to disk with the user's changes
     */
    public void saveSymbolConfig() {
        AstroCatConfig.getConfigFile().save();
    }

    /**
     * Return the number of plot symbol definitions associated with this catalog.
     */
    public int getNumSymbols() {
        return getSymbols().length;
    }

    /**
     * Return the ith plot symbol description
     */
    public TablePlotSymbol getSymbolDesc(int i) {
        return getSymbols()[i];
    }

    /**
     * Return the array of symbol descriptions
     */
    public TablePlotSymbol[] getSymbols() {
        if (_symbols == null) {
            // default plot symbol definition
            _symbols = new TablePlotSymbol[]{
                    new TablePlotSymbol(null, "", "square yellow", "4")
            };
        }
        return _symbols;
    }

    /**
     * @return the table associated with this catalog, if there is one, otherwise null.
     */
    public VoTable getVoTable() {
        return _voTable;
    }

    public Catalog reload() {
        return this; // not applicable here
    }
}
