/*
 * $Id: VoCatalogDirectory.java,v 1.5 2009/04/14 10:56:02 abrighto Exp $
 */

package jsky.catalog.vo;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import java.io.ObjectInputStream;
import java.io.InputStream;

import jsky.catalog.AbstractCatalogDirectory;
import jsky.catalog.Catalog;
import jsky.catalog.CatalogDirectory;
import jsky.catalog.astrocat.AstroCatalog;
import jsky.util.Preferences;
import jsky.util.Resources;
import jsky.util.gui.ProgressPanel;
import uk.ac.starlink.vo.RegistryQuery;
import uk.ac.starlink.vo.RegResource;
import uk.ac.starlink.vo.RegCapabilityInterface;
import net.ivoa.registry.RegistryAccessException;


/**
 * Downloads a list of catalogs from a VO registry
 *
 * @author Allan Brighton
 * @version $Revision: 1.5 $ $Date: 2009/04/14 10:56:02 $
 */
public class VoCatalogDirectory extends AbstractCatalogDirectory {

    private static final long serialVersionUID = 1L;

    // Standard IDs for registry query (represents different catalog query types)
    private static final String[] STANDARD_IDS = new String[]{
            RegCapabilityInterface.CONE_STDID,
            RegCapabilityInterface.SIA_STDID,
            RegCapabilityInterface.SSA_STDID
    };

    // Display names corresponding to the above STANDARD_IDS
    private static final String[] STANDARD_NAMES = new String[]{
            "Cone Search Services",
            "SIA Services",
            "SSA Services"
    };

    // Used to sort the catalog list for display
    private static final Comparator<Catalog> CATALOG_COMPARATOR = new Comparator<Catalog>() {
        public int compare(Catalog c1, Catalog c2) {
            return c1.getName().compareToIgnoreCase(c2.getName());
        }
    };

    // Cached references to previously downloaded catalog directory list, by server URL
    private static Map<URL, VoCatalogDirectory> _voCatalogDirectory;

    // Set to true to force reloading
    private static boolean _reloadFlag = false;

    // Panel used to display download progress information
    private transient ProgressPanel _progressPanel;

    /**
     * Initializes the list of catalogs from the given URL
     *
     * @param name the display name for the catalog directory
     * @param url  the URL of the VO catalog registry
     */
    private VoCatalogDirectory(String name, URL url) {
        super(name);
        setURL(url);
        _load();
    }

    /**
     * Initializes the (sub)directory from the name and the list of catalogs
     *
     * @param name     the display name for the catalog directory
     * @param catalogs list of catalogs in this directory
     */
    private VoCatalogDirectory(String name, List<Catalog> catalogs) {
        super(name);
        setCatalogs(catalogs);
    }

    /**
     * Loads the catalog list from the URL and store any catalogs
     * found there in the catalogs vector.
     * This method organizes the list by capability. Additional subdirs are
     * created for each standardId.
     */
    private void _load() {
        URL url = getURL();
        if (url == null) {
            return;
        }

        if (_progressPanel == null) {
            _progressPanel = ProgressPanel.makeProgressPanel("Updating list of available catalogs from: "
                    + url.getHost());
        }
        _progressPanel.start();

        try {
            // arrange in subdirs, where there is a subdir for each capability
            List<Catalog> subdirs = new ArrayList<Catalog>();
            for (int i = 0; i < STANDARD_IDS.length; i++) {
                String standardId = STANDARD_IDS[i];
                String name = STANDARD_NAMES[i];
                List<Catalog> catalogs = new ArrayList<Catalog>();
                String queryStr = "capability/@standardID = '" + standardId + "'";
                _progressPanel.setText("Query: capability = " + standardId);
                final RegistryQuery query = new RegistryQuery(url.toString(), queryStr);
                RegResource[] resources;
                try {
                    resources = query.getQueryResources();
                } catch (RegistryAccessException e) {
                    e.printStackTrace(); // XXX
                    throw new RuntimeException(e);
                }
                if (_progressPanel.isInterrupted()) {
                    return;
                }
                if (resources != null && resources.length != 0) {
                    for (RegResource resource : resources) {
                        RegCapabilityInterface[] caps = resource.getCapabilities();
                        for (RegCapabilityInterface cap : caps) {
                            if (standardId.equals(cap.getStandardId())) {
                                catalogs.add(new VoCatalog(resource, cap, this));
                            }
                        }
                    }
                    Collections.sort(catalogs, CATALOG_COMPARATOR);
                    subdirs.add(new VoCatalogDirectory(name, catalogs));
                }
            }
            setCatalogs(subdirs);
        } finally {
            _progressPanel.stop();
        }
    }

    /**
     * This method is called once at startup to load the given VO catalog directory.
     *
     * @param cat contains the information from the (AstroCat.xml) config file
     *            (like the URL of the VO registry to use)
     * @return the catalog directory
     */
    public static CatalogDirectory getDirectory(AstroCatalog cat) {
        URL url;
        try {
            url = cat.getBaseURL();
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        String name = cat.getName();
        if (name == null) {
            name = "unknown";
        }
        if (_voCatalogDirectory == null) {
            _voCatalogDirectory = new HashMap<URL, VoCatalogDirectory>();
        } else if (_voCatalogDirectory.containsKey(url)) {
            return _voCatalogDirectory.get(url);
        }
        return getCatalogList(name, url);
    }


    /**
     * Download the list of catalogs from the given URL.
     * Both a persistent file cache and an in memory cache are used to avoid downloading
     * too often, since it can be slow. Calling reload will force a complete reload
     * from the server.
     *
     * @param name the name of the catalog directory
     * @param url  the URL of the catalog directory
     * @return the new catalog directory
     */
    public static VoCatalogDirectory getCatalogList(String name, URL url) {
        VoCatalogDirectory dir;
        if (!_reloadFlag) {
            dir = _loadPersistent(url);
            if (dir != null) {
                dir.setName(name);
                return dir;
            }
        }
        dir = new VoCatalogDirectory(name, url);
        _voCatalogDirectory.put(url, dir);
        _savePersistent(dir, url);
        return dir;
    }

    /**
     * Reload the catalog config file and return the new object for it.
     */
    public Catalog reload() {
        _removePersistent(getURL());
        _reloadFlag = true;
        CatalogDirectory catDir = null;
        try {
            catDir = getCatalogList(getName(), getURL());
        } finally {
            _reloadFlag = false;
        }
        return catDir;
    }

    /**
     * Attempt to read a catalog subdirectory from the given URL and return
     * a CatalogDirectory object for it.
     *
     * @return the new CatalogDirectory
     * @throws RuntimeException if the catalog directory could not be created
     */
    public CatalogDirectory loadSubDir(URL url) {
        throw new RuntimeException("Not implemented");
    }

    public boolean configNeedsUrl() {
        return true;
    }

    /**
     * Save the contents of this catalog directory to make it permanent
     * (for example, in a config file under ~/.jsky3/...).
     */
    public void save() {
        // XXX TODO
    }

    // Save a persistent copy of the catalog directory to disk, using the URL as the key
    private static void _savePersistent(VoCatalogDirectory dir, URL url) {
        try {
            // encode the URL to get a string suitable for a file name
            String s = _getPersistentName(url);
            Preferences.getPreferences().serialize(s, dir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Loads the persistent copy of a catalog directory from disk, using the URL as the key.
    // Returns null if not found.
    private static VoCatalogDirectory _loadPersistent(URL url) {
        // encode the URL to get a string suitable for a file name
        String name = _getPersistentName(url);
        VoCatalogDirectory dir = null;
        try {
            // First try the user's copy
            dir = (VoCatalogDirectory) Preferences.getPreferences().deserialize(name);
        } catch (Exception e) {
            // If not found, use the version supplied with the application
            try {
                String filename = name + Preferences.SERIAL_SUFFIX;
                InputStream inputStream = Resources.getResourceAsStream(filename);
                if (inputStream != null) {
                    ObjectInputStream in = new ObjectInputStream(inputStream);
                    dir = (VoCatalogDirectory) in.readObject();
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }

        if (dir != null) {
            _updatePersistent(dir);
        }
        return dir;
    }

    // restores transient data lost in serialization and reregister catalogs
    private static void _updatePersistent(CatalogDirectory dir) {
        dir.setCatalogs(dir.getCatalogs());

        // restore reference to name servers
        for (Catalog cat : dir.getCatalogs()) {
            if (cat instanceof VoCatalog) {
                ((VoCatalog) cat).initQueryArgs();
            } else if (cat instanceof CatalogDirectory) {
                _updatePersistent((CatalogDirectory) cat);
            }
        }
    }

    private void _removePersistent(URL url) {
        try {
            String s = _getPersistentName(url);
            Preferences.getPreferences().removeSerializedFile(s);
        } catch (Exception e) {
            // ignore
        }
    }

    // Returns the base file name to use to store the catalog list from the given URL
    private static String _getPersistentName(URL url) {
        return url.getHost() + "-" + url.getPath().replaceAll("[^A-Za-z0-9_]", "-");
    }
}
