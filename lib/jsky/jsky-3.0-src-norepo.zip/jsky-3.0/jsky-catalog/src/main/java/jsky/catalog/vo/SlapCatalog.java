package jsky.catalog.vo;


import jsky.catalog.astrocat.AstroCatalog;
import jsky.catalog.Catalog;
import jsky.catalog.CatalogDirectory;
import jsky.catalog.FieldDescAdapter;
import jsky.catalog.FieldDesc;
import jsky.catalog.QueryArgs;
import jsky.catalog.QueryResult;
import jsky.coords.CoordinateRadius;
import jsky.util.gui.ProgressPanel;
import jsky.util.gui.ProgressException;
import jsky.util.Preferences;
import jsky.util.StringUtil;
import jsky.util.Resources;

import java.net.URL;
import java.net.MalformedURLException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.logging.Logger;


import uk.ac.starlink.votable.VOElement;
import uk.ac.starlink.votable.VOElementFactory;
import uk.ac.starlink.util.URLDataSource;
import uk.ac.starlink.util.DOMUtils;
import uk.ac.starlink.table.StoragePolicy;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

/**
 * A catalog implementation specialized for SLAP (Simple Line Access Protocol) services.
 *
 * @author Allan Brighton
 * @since Feb 23, 2009
 */
public class SlapCatalog implements Catalog {

    private static final Logger LOG = Logger.getLogger(SlapCatalog.class.getName());

    // The base URL for accessing the catalog
    private URL _url;

    // The catalog name
    private String _name;

    // The parent catalog directory
    private CatalogDirectory _parent;

    // Array of parameter descriptions
    private FieldDescAdapter[] _fieldDesc;

    // Panel used to display download progress information
    private transient ProgressPanel _progressPanel;


    /**
     * Called via reflection from {@link jsky.catalog.astrocat.AstroCatXML} when reading the catalog configuration file
     * to create an instance of this class.
     *
     * @param cat contains the configuration information (we mainly need the URL)
     * @return the catalog object used to do a SPLAT query
     */
    public static Catalog getCatalog(AstroCatalog cat) {
        URL url;
        try {
            url = cat.getBaseURL();
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        String name = cat.getName();
        if (name == null) {
            name = "unknown";
        }
        return new SlapCatalog(name, url);
    }

    /**
     * Initialize with the catalog name and access URL
     *
     * @param name name, as specified in the configuration file
     * @param url base access URL
     */
    public SlapCatalog(String name, URL url) {
        _name = name;
        _url = url;
        _init();
    }

    /**
     * Read the catalog metadata and initialize the query parameters
     */
    private void _init() {
        // try cached version first
        _fieldDesc = _loadPersistent();
        if (_fieldDesc == null) {
            // read the URL to get the query arguments
            try {
                URL url =_makeURL(_url, "FORMAT=METADATA");
                LOG.info("Reading SLAP server configuration from " + _url);
                VOElement topEl = new VOElementFactory(StoragePolicy.getDefaultPolicy())
                        .makeVOElement(new URLDataSource(url));
                _checkStatus(topEl);

                NodeList params = topEl.getElementsByTagName("PARAM");
                _fieldDesc = new FieldDescAdapter[params.getLength()];
                for (int i = 0; i < _fieldDesc.length; i++) {
                    Element param = (Element) params.item(i);
                    _fieldDesc[i] = new FieldDescAdapter(_getName(param));
                    _fieldDesc[i].setDisplayName(_getDisplayName(param));
                    _fieldDesc[i].setUCD(param.getAttribute("ucd"));
                    _fieldDesc[i].setType(param.getAttribute("utype"));

                    NodeList nodeList = param.getElementsByTagName("DESCRIPTION");
                    if (nodeList != null && nodeList.getLength() == 1) {
                        _fieldDesc[i].setDescription(nodeList.item(0).getTextContent());
                    }
                }
                _savePersistent();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    // Returns the name for the given parameter description.
    // The input name is a string is something like "INPUT:CHEMICAL_ELEMENT".
    // The INPUT: part is removed.
    private String _getName(Element param) {
        String name = param.getAttribute("name");
        if (name == null) {
            name = "unknown";
        }
        if (name.toLowerCase().startsWith("input:")) {
            name = name.substring(6).trim();
        }
        return name;
    }

    // Returns a display name for the given parameter description.
    // The input name is a string is something like "INPUT:CHEMICAL_ELEMENT".
    // The INPUT: part is removed and the rest formatted for readability.
    private String _getDisplayName(Element param) {
        String name = param.getAttribute("name").toLowerCase();
        if (name.startsWith("input:")) {
            name = name.substring(6).trim().replace('_', ' ');
        }
        return StringUtil.capitalize(name);
    }

    // Returns a new URL made by adding the given query string
    private URL _makeURL(URL url, String query) throws MalformedURLException {
        String urlStr = url.toString();
        if (urlStr.contains("?")) {
            return new URL(urlStr + "&" + query);
        }
        return new URL(urlStr + "?" + query);
    }

    public Catalog reload() {
        _removePersistent();
        _init();
        return this; // not applicable here
    }

    // Checks the status of the VOTable and throws an exception if appropriate
    private void _checkStatus(VOElement topEl) throws IOException {
        // Locate the first RESOURCE element with type="results", which is defined to contain the result.
        NodeList resources = topEl.getElementsByTagName("RESOURCE");
        Element results = null;
        for (int i = 0; i < resources.getLength(); i++) {
            Element resource = (Element) resources.item(i);
            // Since the VOTable 1.1 schema defines "results" as the default
            // value of the type attribute, an absent type should probably
            // count.  Use this if we don't find an explicit results value.
            if (!resource.hasAttribute("type")) {
                results = resource;
            }
            // If we have one explicitly marked results though, use that.
            else if ("results".equals(resource.getAttribute("type"))
                    // may be a bug in some servers?
                    || "result".equals(resource.getAttribute("type"))) {
                results = resource;
                break;
            }
        }

        // If there is no results element, throw an exception.
        if (results == null) {
            throw new IOException("No suitable RESOURCE found in returned VOTable");
        }

        /* Try to find the status info. */
        String status = null;
        String message = null;
        for (Node node = results.getFirstChild(); node != null;
             node = node.getNextSibling()) {
            if (node instanceof Element) {
                Element el = (Element) node;
                if ("INFO".equals(el.getTagName()) && "QUERY_STATUS".equals(el.getAttribute("name"))) {
                    status = el.getAttribute("value");
                    message = DOMUtils.getTextContent(el);
                    break;
                }
            }
        }

        // If the query status is error, throw an exception.
        if ("ERROR".equals(status)) {
            throw new IOException("SLAP query error: " + message);
        }
    }


    // --- Implement the Catalog interface --

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public String getName() {
        return _name;
    }

    public void setName(String name) {
        _name = name;
    }

    public String getId() {
        return _name;
    }

    public String getTitle() {
        return _name;
    }

    public String getDescription() {
        // In this case, return a help string to be displayed below the input parameters
        return "<html><i>Syntax for range values: min1/max1,min2/max2,...</i></html>";
    }

    public String toString() {
        return _name;
    }

    public URL getDocURL() {
        return null;
    }

    public int getNumParams() {
        return _fieldDesc.length;
    }


    public FieldDesc getParamDesc(int i) {
        return _fieldDesc[i];
    }


    public FieldDesc getParamDesc(String name) {
        for (FieldDesc fd : _fieldDesc) {
            if (fd.getName().equals(name)) {
                return fd;
            }
        }
        return null;
    }


    public void setRegionArgs(QueryArgs queryArgs, CoordinateRadius region) {
        // does not apply here
    }

    public boolean isLocal() {
        return false;
    }

    public boolean isImageServer() {
        return false;
    }

    public String getType() {
        return "catalog";
    }

    public void setParent(CatalogDirectory catDir) {
        _parent = catDir;
    }

    public CatalogDirectory getParent() {
        return _parent;
    }

    public Catalog[] getPath() {
        CatalogDirectory parent = getParent();
        if (parent == null) {
            return null;
        }

        return parent.getPath(this);
    }

    /**
     * @param title the title for the panel
     * @return a panel for displaying the progress of a query.
     */
    protected ProgressPanel _getProgressPanel(String title) {
        if (_progressPanel == null) {
            _progressPanel = ProgressPanel.makeProgressPanel(title);
        } else {
            _progressPanel.setTitle(title);
        }
        return _progressPanel;
    }

    // Returns the query URL, based on the given query arguments
    private URL _getQueryUrl(QueryArgs queryArgs) throws MalformedURLException {
        StringBuffer sb = new StringBuffer();
        int i = 0;
        boolean first = true;
        for (FieldDesc fd : _fieldDesc) {
            String s = (String) queryArgs.getParamValue(i++);
            if (s != null && s.length() != 0) {
                if (!first) {
                    sb.append("&");
                }
                first = false;
                sb.append(fd.getName().toUpperCase());
                sb.append("=");
                sb.append(s);
            }
        }
        return _makeURL(_url, sb.toString());
    }

    public QueryResult query(QueryArgs queryArgs) throws IOException {
        URL url = _getQueryUrl(queryArgs);

        _progressPanel = _getProgressPanel("Downloading query results ...");
        _progressPanel.start();
        _progressPanel.setText("Performing SLAP query: " + url);

        try {
            VoTable result = VoTable.createVoTable(url, getId(), getName(), this);
            if (_progressPanel.isInterrupted()) {
                throw new ProgressException("Interrupted");
            }
            return result;
        }
        finally {
            _progressPanel.stop();
        }
    }


    // Save a persistent copy of the query parameters, so we don't need to download the
    // information every time. The information is updated when reload() is called
    // (Catalog/Refresh menu item in the GUI)
    private void _savePersistent() {
        try {
            // encode the URL to get a string suitable for a file name
            String s = _getPersistentName(_url);
            Preferences.getPreferences().serialize(s, _fieldDesc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Loads the persistent copy of a query parameters from disk, using the URL as the key.
    // Returns null if not found.
    private FieldDescAdapter[] _loadPersistent() {
        // encode the URL to get a string suitable for a file name
        String name = _getPersistentName(_url);
        FieldDescAdapter[] result = null;
        try {
            // First try the user's copy
           result = (FieldDescAdapter[]) Preferences.getPreferences().deserialize(name);
        } catch (Exception e) {
            // If not found, use the version supplied with the application
            try {
                String filename = name + Preferences.SERIAL_SUFFIX;
                ObjectInputStream in = new ObjectInputStream(Resources.getResourceAsStream(filename));
                result = (FieldDescAdapter[]) in.readObject();
                in.close();
                return result;
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return result;
    }

    private void _removePersistent() {
        try {
            String s = _getPersistentName(_url);
            Preferences.getPreferences().removeSerializedFile(s);
        } catch (Exception ignored) {
        }
    }

    // Returns the base file name to use to store the catalog list from the given URL
    private static String _getPersistentName(URL url) {
        String s = url.getHost() + url.getPath() + url.getQuery();
        return s.replaceAll("[^A-Za-z0-9_]", "-");
    }
}
