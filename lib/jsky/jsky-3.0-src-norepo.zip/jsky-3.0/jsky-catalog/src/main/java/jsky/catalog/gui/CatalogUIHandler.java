// Copyright 2001 Association for Universities for Research in Astronomy, Inc.,
// Observatory Control System, Gemini Telescopes Project.
//
// $Id: CatalogUIHandler.java,v 1.2 2009/02/19 22:48:43 abrighto Exp $

package jsky.catalog.gui;

import javax.swing.JComponent;


/**
 * Defines the interface for classes wishing to define thier own catalog
 * query or query result components.
 */
public abstract interface CatalogUIHandler {

    /**
     * This interface may be implemented by Catalog and QueryResult objects that
     * wish to define custom user interfaces.
     *
     * @param display can be used to display the results of a catalog query
     *
     * @return a user interface component for the catalog or queryResult object, or null,
     *         in which case a default component will be used, based on the object type
     */
    public JComponent makeComponent(QueryResultDisplay display);
}
