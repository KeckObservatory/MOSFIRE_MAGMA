package jsky.catalog.vo;

import junit.framework.TestCase;

import java.net.URL;
import java.net.MalformedURLException;

import jsky.catalog.FieldDesc;

/**
 * @author Allan Brighton
 * @since Feb 23, 2009
 */
public class SlapCatalogTest extends TestCase {

    public void testInit() throws MalformedURLException {
        SlapCatalog cat = new SlapCatalog("Splatalogue Simple Line Access Service",
                new URL("http://phobos.jb.man.ac.uk:8000/slap.py"));
        assertEquals("Splatalogue Simple Line Access Service", cat.getName());
        assertEquals(4, cat.getNumParams());

        FieldDesc fd = cat.getParamDesc(0);
        assertEquals("Linelist", fd.getName());
        assertEquals("Specify the original linelist from which this information is derived", fd.getDescription());

        fd = cat.getParamDesc(1);
        assertEquals("Species", fd.getName());
        assertEquals("Specify the species name.", fd.getDescription());

        fd = cat.getParamDesc(2);
        assertEquals("Final", fd.getName());
        assertEquals("Specify the final energy of the species originating the transition. To be specified in J.", fd.getDescription());

        fd = cat.getParamDesc(3);
        assertEquals("Wavelength", fd.getName());
        assertEquals("Specify the wavelength spectral range. To be specified in meters. This wavelength will be interpreted as the wavelength in the vacuum of the transition originating the line", fd.getDescription());
    }
}
