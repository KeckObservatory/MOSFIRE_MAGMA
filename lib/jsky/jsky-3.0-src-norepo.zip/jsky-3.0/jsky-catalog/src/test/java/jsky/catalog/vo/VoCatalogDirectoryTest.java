package jsky.catalog.vo;

import java.net.MalformedURLException;

import jsky.catalog.Catalog;
import jsky.catalog.CatalogDirectory;
import jsky.catalog.astrocat.AstroCatalog;
import junit.framework.TestCase;

public class VoCatalogDirectoryTest extends TestCase {
	
	public void testLoadDir() throws MalformedURLException {
		AstroCatalog cat = new AstroCatalog();
		cat.setName("Test");
		cat.setProtocol("http");
		cat.setHost("nvo.stsci.edu");
		cat.setURLPath("/vor10/ristandardservice.asmx");
		CatalogDirectory dir = VoCatalogDirectory.getDirectory(cat);
		int n = dir.getNumCatalogs();
		for(int i = 0; i < n; i++) {
			Catalog catalog = dir.getCatalog(i);
			System.out.println(i + ": " + catalog.getName() + " - " + catalog.getTitle());
		}
	}
}
