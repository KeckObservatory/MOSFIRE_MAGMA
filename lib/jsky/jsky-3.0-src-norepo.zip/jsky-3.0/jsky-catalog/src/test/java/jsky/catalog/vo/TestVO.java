package jsky.catalog.vo;

import net.ivoa.registry.RegistryAccessException;
import net.ivoa.registry.search.Records;
import uk.ac.starlink.vo.RegistryQuery;
import uk.ac.starlink.vo.RegResource;
import uk.ac.starlink.vo.RegistryStarTable;
import uk.ac.starlink.vo.RegCapabilityInterface;
import uk.ac.starlink.ttools.task.TableProducer;
import uk.ac.starlink.table.StarTable;
import uk.ac.starlink.table.RowSequence;
import uk.ac.starlink.task.TaskException;
import uk.ac.starlink.task.ExecutionException;
import uk.ac.starlink.task.ParameterValueException;

import java.io.IOException;
import java.net.URL;
import java.net.MalformedURLException;

import junit.framework.TestCase;

public class TestVO extends TestCase {
	
	public TestVO(String name) {
		super(name);
	}
	
    public void testRegistryQuery() {
//        String url = "http://registry.astrogrid.org/astrogrid-registry/services/RegistryQueryv1_0";
        String url = "http://nvo.stsci.edu/vor10/ristandardservice.asmx";
//        final RegistryQuery query = new RegistryQuery(url, null);
        String queryStr = "capability/@standardID = 'ivo://ivoa.net/std/SIA'";
        //capability/@standardID = 'ivo://ivoa.net/std/ConeSearch'
        //capability/@standardID = 'ivo://ivoa.net/std/SSA'


        URL regURL;
        try {
            regURL = new URL(url);
        }
        catch ( MalformedURLException e ) {
            return;
        }
        final RegistryQuery query =
            new RegistryQuery( regURL.toString(), queryStr );

        
       TableProducer producer = new TableProducer() {
            public StarTable getTable() throws TaskException {
                try {
                    return new RegistryStarTable( query );
                }
                catch ( Exception e ) {
                    throw new ExecutionException( "Query failed: "
                                                + e.getMessage(), e );
                }
            }
        };

        

        StarTable table;
        try {
            table = producer.getTable();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        RowSequence rseq;
        try {
            rseq = table.getRowSequence();
            try {
                while (rseq.next()) {
                    Object[] row = rseq.getRow();
//                    System.out.println("XXX Found row: " + row[0]); // XXX
                }
            }
            finally {
                rseq.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }



        RegResource[] resources;
		try {
			resources = query.getQueryResources();
		} catch (RegistryAccessException e) {
			e.printStackTrace();
			return;
		}
        for (RegResource resource : resources) {
            System.out.println("\ngetContact = " + resource.getIdentifier());
            System.out.println("getShortName = " + resource.getShortName());
            System.out.println("getReferenceUrl = " + resource.getReferenceUrl());
            System.out.println("getTitle = " + resource.getTitle());
            System.out.println("getContact = " + resource.getContact());

            RegCapabilityInterface[] caps = resource.getCapabilities();
            for (RegCapabilityInterface cap : caps) {
                System.out.println("Capability.getAccessUrl = " + cap.getAccessUrl());
                System.out.println("Capability.getDescription = " + cap.getDescription());
                System.out.println("Capability.getStandardId = " + cap.getStandardId());
                System.out.println("Capability.getVersion = " + cap.getVersion());
            }
        }
    }
    
    public void testCatalogQuery() {
    
//    	getContact = ivo://nasa.heasarc/skyview/rass
//    	getShortName = RASS
//    	getReferenceUrl = http://skyview.gsfc.nasa.gov
//    	getTitle = ROSAT All-Sky X-ray Survey 1.5 keV
//    	getContact = null
//    	Capability.getAccessUrl = http://skyview.gsfc.nasa.gov/cgi-bin/vo/sia.pl?survey=RASS&
//    	Capability.getDescription = null
//    	Capability.getStandardId = ivo://ivoa.net/std/SIA
//    	Capability.getVersion = null
    }
    
}

