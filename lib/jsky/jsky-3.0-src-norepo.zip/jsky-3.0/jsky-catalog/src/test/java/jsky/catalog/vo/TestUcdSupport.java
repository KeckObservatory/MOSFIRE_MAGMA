package jsky.catalog.vo;

import junit.framework.TestCase;

/**
 * @author Allan Brighton
 * @since Feb 25, 2009
 */
public class TestUcdSupport extends TestCase {

    public void testUcdSupport() {
        assertFalse(new UcdSupport(null).isRa());
        assertTrue(new UcdSupport("pos.eq.ra").isRa());
        assertTrue(new UcdSupport("pos.eq.dec").isDec());
        assertTrue(new UcdSupport("pos.eq.ra;meta.main").isRaMain());
        assertTrue(new UcdSupport("POS_EQ_RA_MAIN").isRaMain());
        assertTrue(new UcdSupport("pos.eq.dec;meta.main").isDecMain());
        assertTrue(new UcdSupport("POS_EQ_DEC_MAIN").isDecMain());
        assertTrue(new UcdSupport("meta.id").isId());
        assertTrue(new UcdSupport("VOX:Image_AccessReference").isLink());
        assertTrue(new UcdSupport("DATA_LINK").isLink());
        assertTrue(new UcdSupport("meta.ref.url").isLink());
        assertTrue(new UcdSupport("VOX:Image_Format").isFormat());
        assertTrue(new UcdSupport("VOX:Spectrum_Format").isFormat());
    }
}
