package jsky.util;

import junit.framework.TestCase;

/**
 * @author Allan Brighton
 * @since Feb 24, 2009
 */
public class StringUtilTest extends TestCase {

    public void testCapitalize() {
        assertEquals("", StringUtil.capitalize(""));
        assertEquals("The Brown Dog", StringUtil.capitalize("the brown dog"));
        assertEquals("Xxx Yyy", StringUtil.capitalize("xxx Yyy"));
        assertEquals("Xxx Yyy", StringUtil.capitalize("XXX YYy"));
        assertEquals("Xxx Yyy", StringUtil.capitalize(" XXX  YYy "));
    }

    public void testSplit() {
        String[] ar = StringUtil.split("test|passed", '|');
        assertEquals(2, ar.length);
        assertEquals("test", ar[0]);
        assertEquals("passed", ar[1]);
    }

    public void testMatch() {
        assertTrue(StringUtil.match("s*", "str"));
        assertFalse(StringUtil.match("*s", "str"));
        assertTrue(StringUtil.match("*s", "xxs"));
        assertTrue(StringUtil.match("*s*", "xxsxx"));
        assertFalse(StringUtil.match("*s*", "xxpxx"));
        assertTrue(StringUtil.match("*s*", "s"));
        assertTrue(StringUtil.match("s*", "s"));
        assertTrue(StringUtil.match("*s", "s"));
        assertTrue(StringUtil.match("*s", "s"));
        assertTrue(StringUtil.match("s*|p*", "s"));
        assertTrue(StringUtil.match("s*|p*", "p"));
        assertFalse(StringUtil.match("s*|p*", "x"));
        assertTrue(StringUtil.match("*s|*p", "s"));
        assertTrue(StringUtil.match("*s|*p", "p"));
        assertFalse(StringUtil.match("*s|*p", "x"));
        assertTrue(StringUtil.match("*s*|*p*", "s"));
        assertTrue(StringUtil.match("*s*|*p*", "p"));
        assertFalse(StringUtil.match("*s*|*p*", "x"));
        assertTrue(StringUtil.match("x*|", "xyz"));
        assertTrue(StringUtil.match("x*|", "xyz"));
        assertFalse(StringUtil.match("|", "xyz"));
        assertTrue(StringUtil.match("*", "ppp"));
        assertTrue(StringUtil.match("ab?", "abc"));
        assertTrue(StringUtil.match("?b?", "abc"));
        assertTrue(StringUtil.match("?b?", "abc"));
    }
}
