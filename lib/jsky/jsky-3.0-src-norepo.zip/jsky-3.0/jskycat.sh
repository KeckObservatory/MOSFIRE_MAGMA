#!/bin/sh
#
# Script to run the jskycat application

java -Xmx256m -jar `dirname $0`/jskycat/target/jskycat-3.0-assembly.dir/jskycat-3.0.jar $*

