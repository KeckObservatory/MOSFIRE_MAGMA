#!/bin/sh
#
# Updates jar files in this directory from the StarJava source dir.
# Check if the version numbers changed and update setup.sh and ../jsky/pom.xml, if needed.
# Then run setup.sh again to update the maven repository with the latest StarJava jars.

# Set this to the root of the STARJAVA svn source tree
STARJAVA=../../starjava

modules="astrogrid connect fits jsamp pal registry table task ttools util vo votable plastic"

for i in $modules
do
    test -f $STARJAVA/source/$i/lib/$i/$i.jar || (echo "$STARJAVA/source/$i/lib/$i/$i.jar" does not exist; exit 1)
    fgrep '<property name="version" value=' $STARJAVA/source/$i/build.xml /dev/null
    grep -w $i setup.sh
    echo
    cp $STARJAVA/source/$i/lib/$i/$i.jar .
done

