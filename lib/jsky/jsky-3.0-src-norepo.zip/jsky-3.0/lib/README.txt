This directory contains jar file dependencies that are not
automatically available from public Maven repositories. The script:

    ./setup.sh

installs these jars to the local repository (../repository).


