#!/bin/sh
#
# Installs the jars required by JSky (but not available from public repositories) 
# in the local Maven repository (../repository)
#

# Run from the top level JSky directory
test -d lib || cd ..

# Starlink packages
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=util -Dversion=1.0 -Dpackaging=jar -Dfile=lib/util.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=pal -Dversion=1.0-1 -Dpackaging=jar -Dfile=lib/pal.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=table -Dversion=2.7-1 -Dpackaging=jar -Dfile=lib/table.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=ttools -Dversion=2.0-3 -Dpackaging=jar -Dfile=lib/ttools.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=votable -Dversion=2.0 -Dpackaging=jar -Dfile=lib/votable.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=vo -Dversion=0.2 -Dpackaging=jar -Dfile=lib/vo.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=task -Dversion=0.2 -Dpackaging=jar -Dfile=lib/task.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=fits -Dversion=0.1 -Dpackaging=jar -Dfile=lib/fits.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=connect -Dversion=0.1 -Dpackaging=jar -Dfile=lib/connect.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=astrogrid -Dversion=0.2 -Dpackaging=jar -Dfile=lib/astrogrid.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=soapserver -Dversion=0.4 -Dpackaging=jar -Dfile=lib/soapserver.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=jsamp -Dversion=0.3-1 -Dpackaging=jar -Dfile=lib/jsamp.jar
mvn.sh install:install-file -DgroupId=net.ivoa -DartifactId=registry -Dversion=1.0 -Dpackaging=jar -Dfile=lib/registry.jar
mvn.sh install:install-file -DgroupId=uk.ac.starlink -DartifactId=plastic -Dversion=0.4+ -Dpackaging=jar -Dfile=lib/plastic.jar
mvn.sh install:install-file -DgroupId=rmi-lite -DartifactId=rmi-lite -Dversion=1.0 -Dpackaging=jar -Dfile=lib/rmi-lite.jar

# Note: Using newer versions of these packages, as well as axis and javax.servlet
mvn.sh install:install-file -DgroupId=org.gnu -DartifactId=jel_g -Dversion=2.0.1 -Dpackaging=jar -Dfile=lib/jel_g.jar
mvn.sh install:install-file -DgroupId=nom.tam -DartifactId=tamfits -Dversion=1.0 -Dpackaging=jar -Dfile=lib/tamfits.jar
mvn.sh install:install-file -DgroupId=org.apache.tools -DartifactId=bzip2 -Dversion=1.0 -Dpackaging=jar -Dfile=lib/apache-bzip2.jar


# Other JSky dependencies
mvn.sh install:install-file -DgroupId=ca.nrc.cadc -DartifactId=hcompress -Dversion=0.52 -Dpackaging=jar -Dfile=lib/hcompress.jar
# Note: diva.jar was taken from the Ptolemy Project (http://ptolemy.eecs.berkeley.edu/index.htm)
mvn.sh install:install-file -DgroupId=diva -DartifactId=diva -Dversion=ptII7.0.1 -Dpackaging=jar -Dfile=lib/diva.jar

mvn.sh install:install-file -DgroupId=jfreechart -DartifactId=jfreechart -Dversion=1.0.12 -Dpackaging=jar -Dfile=lib/jfreechart.jar
mvn.sh install:install-file -DgroupId=jcommon -DartifactId=jcommon -Dversion=1.0.15 -Dpackaging=jar -Dfile=lib/jcommon.jar

mvn.sh install:install-file -DgroupId=edu.stanford.ejalbert -DartifactId=BrowserLauncher -Dversion=2-1_3 -Dpackaging=jar -Dfile=lib/BrowserLauncher.jar

# JAI: Note: To get better (native) performace, also install the JAI package as a java extension
mvn.sh install:install-file -DgroupId=jai -DartifactId=jai-core -Dversion=1.1.2 -Dpackaging=jar -Dfile=lib/jai_core.jar
mvn.sh install:install-file -DgroupId=jai -DartifactId=jai-codec -Dversion=1.1.2 -Dpackaging=jar -Dfile=lib/jai_codec.jar
mvn.sh install:install-file -DgroupId=jai -DartifactId=mlibwrapper_jai -Dversion=1.1.2 -Dpackaging=jar -Dfile=lib/mlibwrapper_jai.jar

