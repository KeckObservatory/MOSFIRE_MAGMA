#!/bin/sh
#
# Script to run the elevation plot

dir=`dirname $0`
lib=$dir/jskycat/target/jskycat-3.0-assembly.dir/lib

cp=$dir/jsky-elevation-plot/target/jsky-elevation-plot-3.0.jar
for i in $lib/*.jar
do
    cp=${cp}:$i
done

java -cp $cp jsky.plot.ElevationPlotPanel $*


