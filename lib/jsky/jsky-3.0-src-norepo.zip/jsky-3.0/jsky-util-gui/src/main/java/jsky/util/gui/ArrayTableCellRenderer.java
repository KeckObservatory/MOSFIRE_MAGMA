/*
 * $Id: ArrayTableCellRenderer.java,v 1.3 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.util.gui;

import java.awt.Component;
import java.lang.reflect.Array;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Used to display the contents of arrays in a table cell.
 */
public class ArrayTableCellRenderer extends DefaultTableCellRenderer {

    /**
     * Constructor: set the alignment based on the array element type.
     *
     */
    public ArrayTableCellRenderer() {
        setHorizontalAlignment(JLabel.CENTER);
    }


    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
        Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        if (value != null) {
            Class c = value.getClass();
            if (c.isArray()) {
                int n = Array.getLength(value);
                if (n > 0) {
                    StringBuffer sb = new StringBuffer("(");
                    for(int i = 0; i < n; i++) {
                        sb.append(Array.get(value, i).toString());
                        if (i == 2 && n > 3) {
                            sb.append(", ...");
                            break;
                        }
                        if (i < n-1) {
                            sb.append(", ");
                        }
                    }
                    sb.append(")");
                    ((JLabel) component).setText(sb.toString());
                }
            }
        }

        return component;
    }
}


