/**
 * $Id: GreenTheme.java,v 1.4 2009/03/24 19:46:57 abrighto Exp $
 */

package jsky.util.gui;

import com.jgoodies.looks.plastic.Plastic3DLookAndFeel;
import com.jgoodies.looks.plastic.PlasticLookAndFeel;
import com.jgoodies.looks.plastic.theme.SkyGreen;

import javax.swing.*;
import javax.swing.plaf.ColorUIResource;

/**
 * Modifies the JGoodies SkyGreen theme to have greenish labels
 */
public class GreenTheme extends SkyGreen {
    public String getName() {
        return "Emerald";
    }

    private final ColorUIResource prim1 = new ColorUIResource(51, 102, 51);

    private final ColorUIResource prim2 = new ColorUIResource(102, 153, 102);

    private final ColorUIResource prim3 = new ColorUIResource(153, 204, 153);

    private final ColorUIResource secondary2 = new ColorUIResource(126, 126, 126);

    protected ColorUIResource getPrimary1() {
        return prim1;
    }

    protected ColorUIResource getPrimary2() {
        return prim2;
    }

    protected ColorUIResource getPrimary3() {
        return prim3;
    }

    protected ColorUIResource getSecondary2() {
        return secondary2;
    }

    public ColorUIResource getSystemTextColor() {
        return prim1;
    }

    /**
     * Install the green theme and JGoodies Plastic3DLookAndFeel.
     */
    public static void installGreenTheme() {
         PlasticLookAndFeel.setCurrentTheme(new GreenTheme());
        try {
            UIManager.setLookAndFeel(new Plastic3DLookAndFeel());

            // OT-490: set ToolTip.background color to beige
            UIManager.put("ToolTip.background", new ColorUIResource(245, 245, 220));
        } catch (Exception ex) {
            DialogUtil.error(ex);
        }
    }
}
