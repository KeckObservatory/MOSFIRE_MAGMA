/*
 * $Id: TabbedPaneDialog.java,v 1.3 2009/04/21 13:31:17 abrighto Exp $
 */

package jsky.util.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JDialog;
import javax.swing.JFrame;

import jsky.util.Preferences;


/**
 * Provides a frame with a TabbedPanel and some dialog buttons.
 *
 * @version $Revision: 1.3 $
 * @author Allan Brighton
 */
public class TabbedPaneDialog extends JDialog {

    private TabbedPanel _tabbedPanel;


    /**
     * Create a top level window containing a TabbedPanel.
     */
    public TabbedPaneDialog(JFrame owner, String title) {
        super(owner, title);
        _tabbedPanel = new TabbedPanel(this);
        getContentPane().add(_tabbedPanel, BorderLayout.CENTER);
        Preferences.manageLocation(this);
        Preferences.manageSize(_tabbedPanel, new Dimension(700,600));
        setDefaultCloseOperation(HIDE_ON_CLOSE);
    }

    public TabbedPanel getTabbedPanel() {
        return _tabbedPanel;
    }

    /**
     * test main
     */
    public static void main(String[] args) {
        TabbedPaneDialog tpf = new TabbedPaneDialog(null, "Test");
        ActionListener al = new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        };
        TabbedPanel tp = tpf.getTabbedPanel();
        JTabbedPane jtp = tp.getTabbedPane();
        jtp.add(new JPanel(), "Test1");
        jtp.add(new JPanel(), "Test2");
        tp.getOKButton().addActionListener(al);
        tp.getCancelButton().addActionListener(al);
        tpf.pack();
        tpf.setVisible(true);
    }
}

