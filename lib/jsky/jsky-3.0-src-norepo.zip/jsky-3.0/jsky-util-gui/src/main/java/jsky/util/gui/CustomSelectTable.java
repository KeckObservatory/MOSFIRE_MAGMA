/**
 * $Id: CustomSelectTable.java,v 1.1.1.1 2009/02/17 22:24:34 abrighto Exp $
 */

package jsky.util.gui;

import javax.swing.*;

/**
 * JTable subclass that skips uneditable cells when tabbing to the next cell.
 * Taken from http://www.javakb.com/Uwe/ForumPost.aspx?article=java-gui:3796:m3fyzofhae.fsf_-_%40telzey.localdomain
 */
public class CustomSelectTable extends JTable {

    public void changeSelection(int row, int col, boolean toggle, boolean expand) {
        // This method is called when the user tries to move to a diffferent cell.
        // If the cell they're trying to move to is not editable, we look for
        // then next cell in the proper direction that is editable.
        if (!getModel().isCellEditable(row, col)) {
            // Find the row and column we're coming from.
            int curRow = getEditingRow();
            int curCol = getEditingColumn();
            if (curRow == -1) {
                curRow = getSelectedRow();
            }
            if (curCol == -1) {
                curCol = getSelectedColumn();
            }

            // We may need to wrap-around.
            int nRows = getRowCount();
            int nCols = getColumnCount();

            // If we can't find a cell to move to, we'll stay here.
            int nextRow = row;
            int nextCol = col;

            if (col == curCol) {
                // Up or down motion - go only up or down.
                int direction = row - curRow;
                if (direction > 1) {
                    direction = 1;
                }
                if (direction < -1) {
                    direction = -1;
                }
                nextRow = findNextEditableRow(row, col, direction, nRows, nCols);
            } else if (row == curRow) {
                // Left-or-right motion - use the "natural" (for Americans) order:
                // left-to-right, top-to-bottom, or vice-versa if we're trying
                // to move to the left. We'll wrap from the bottom row to the top
                // and vice-versa if necessary.
                int direction = col - curCol;
                if (direction > 1) {
                    direction = 1;
                }
                if (direction < -1) {
                    direction = -1;
                }
                int[] nextCell = findNextEditableCell(row, col, direction,
                        nRows, nCols);
                nextRow = nextCell[0];
                nextCol = nextCell[1];
            } else {
                // Both row and column differ. This probably means we've
                // moved off the end of a row, or else the user has clicked
                // on some random cell. The direction is controlled
                // by the row difference (this doesn't always do something
                // intuitive; always setting direction=1 might work better).
                int direction = row - curRow;
                if (direction > 1) {
                    direction = 1;
                }
                if (direction < -1) {
                    direction = -1;
                }
                if ((row == 0) && (curRow == nRows - 1)) {
                    direction = 1;
                }
                int[] nextCell = findNextEditableCell(row, col,
                        direction, nRows, nCols);
                nextRow = nextCell[0];
                nextCol = nextCell[1];
            }
            // Go to the cell we found.
            super.changeSelection(nextRow, nextCol, toggle, expand);
        } else {
            // It's an editable cell, so leave the selection here.
            super.changeSelection(row, col, toggle, expand);
        }
    }

    // Search for an editable cell starting at row,col and using the
    // "natural" order.
    int[] findNextEditableCell(int row, int col,
                               int direction, int nRows, int nCols) {
        int origRow = row;
        int origCol = col;
        do {
            col = col + direction;
            if (col >= nCols) {
                col = 0;
                row += direction;
            }
            if (col < 0) {
                col = nCols - 1;
                row += direction;
            }
            if (row >= nRows) {
                row = 0;
            }
            if (row < 0) {
                row = nRows - 1;
            }
            if (isCellEditable(row, col)) {
                return new int[]{row, col};
            }
        } while (!((row == origRow) && (col == origCol)));

        // Nothing editable found; stay here.
        return new int[]{origRow, origCol};
    }

    // Search directly above/below for an editable cell.
    int findNextEditableRow(int row, int col, int direction, int nRows, int nCols) {
        int origRow = row;
        do {
            row = row + direction;
            if (row < 0) {
                row = nRows - 1;
            }
            if (row >= nRows) {
                row = 0;
            }
            if (isCellEditable(row, col)) {
                return row;
            }
        } while (row != origRow);
        // Nothing editable found, stay here.
        return origRow;
    }
}
