/**
 * $Id: JTextAreaCellEditor.java,v 1.2 2009/02/25 17:01:10 abrighto Exp $
 */

package jsky.util.gui;

import javax.swing.table.TableCellEditor;
import javax.swing.*;
import javax.swing.text.PlainDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import java.awt.*;

/**
 * A table cell editor for multi-line text fields.
 */
public class JTextAreaCellEditor extends AbstractCellEditor implements TableCellEditor {

    private static final int ROW_PAD = 3;
    private JTextArea _textArea;
    private JTable _table;
    private int _row;

    /**
     * Create a JTextArea cell editor for the given table.
     */
    public JTextAreaCellEditor(JTable table) {
        _table = table;

        _textArea = new JTextArea(new Document());
        _textArea.setWrapStyleWord(true);
        _textArea.setLineWrap(true);
        _textArea.setBorder(JTextAreaCellRenderer.focusBorder);
        _textArea.setOpaque(true);
    }

    // used to catch tabs and returns and use them to leave the editor.
    public class Document extends PlainDocument {

        public void insertString(int offs, String str, AttributeSet a)
                throws BadLocationException {
            if (str == null) {
                return;
            }

            if (str.equals("\t") || str.equals("\n")) {
                stopCellEditing();
                return;
            }
            super.insertString(offs, str, a);
            _updateRowHeight(_table.getSelectedRow(), _table.getSelectedColumn(), _table);
        }

        public int getRow() {
            return _row;
        }
    }


    public JTextArea getTextArea() {
        return _textArea;
    }

    public Object getCellEditorValue() {
        return _textArea.getText();
    }

    public Component getTableCellEditorComponent(JTable table, Object value,
                                                 boolean isSelected, int row, int column) {
        _row = row;
        _textArea.setText((value == null) ? "" : value.toString());
        _updateRowHeight(row, column, table);
        return _textArea;
    }

    private void _updateRowHeight(int row, int column, JTable table) {
        if (row < 0 || column < 0) {
            return;
        }

        int tableColWidth = table.getColumnModel().getColumn(column).getWidth();
        Dimension d = _textArea.getPreferredSize();
        if (d.width != tableColWidth) {
            _textArea.setSize(new Dimension(tableColWidth, d.height));
            d = _textArea.getPreferredSize();
        }

        int tableRowHeight = table.getRowHeight(row);
        int defaultTableRowHeight = table.getRowHeight();
        if (d.height < defaultTableRowHeight) {
            d.height = defaultTableRowHeight;
        }

        if (d.height+ROW_PAD != tableRowHeight) {
            table.setRowHeight(row, d.height+ROW_PAD);
        }
    }
}

