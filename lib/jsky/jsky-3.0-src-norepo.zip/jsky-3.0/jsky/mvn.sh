#!/bin/sh
#
# Script to run maven using the local repository (../repository)

../maven/apache-maven-2.0.9/bin/mvn -B -Dmaven.test.skip=true -s ../settings.xml $*
