package jsky.app.jskycat;

public class JSkyCatVersion {
   public static final String JSKYCAT_VERSION="jsky-3.0";
}
