/*
 * ESO Archive
 *
 * $Id: JSkyCat.java,v 1.14 2009/04/16 15:01:36 abrighto Exp $
 *
 * who             when        what
 * --------------  ----------  ----------------------------------------
 * Allan Brighton  1999/05/03  Created
 */

package jsky.app.jskycat;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.media.jai.JAI;
import javax.media.jai.TileCache;
import javax.swing.*;
import javax.swing.plaf.ColorUIResource;

import jsky.image.gui.MainImageDisplay;
import jsky.navigator.NavigatorFrame;
import jsky.navigator.NavigatorImageDisplayFrame;
import jsky.navigator.NavigatorImageDisplay;
import jsky.util.I18N;
import jsky.interop.SampHelper;
import jsky.util.gui.*;
import jsky.interop.JSkyServer;
import jsky.interop.PlasticHelper;
import org.astrogrid.samp.Metadata;
import com.jgoodies.looks.plastic.Plastic3DLookAndFeel;

/**
 * Main class for the JSkyCat application.
 */
public class JSkyCat {

    // Used to access internationalized strings (see i18n/gui*.proprties)
    private static final I18N _I18N = I18N.getInstance(JSkyCat.class);

    /**
     * The main image frame
     */
    protected NavigatorImageDisplayFrame _imageFrame;


    /**
     * Create the JSkyCat application class and display the contents of the
     * given image file or URL, if not null.
     *
     * @param imageFileOrUrl an image file or URL to display
     * @param showNavigator  if true, display the catalog navigator on startup
     * @param useSamp        if true, use SAMP for communication (default)
     * @param usePlastic     if true, use PLASTIC instead of SAMP for communication
     * @param portNum        if not zero, listen on this port for remote control commnds (deprecated)
     * @see JSkyCatRemoteControl
     */
    public JSkyCat(String imageFileOrUrl, boolean showNavigator, boolean useSamp,
                   boolean usePlastic, int portNum) {

        makeFrameLayout(showNavigator, imageFileOrUrl);


        if (useSamp || usePlastic) {
            Metadata meta = createApplicationMetadata();
            if (useSamp) {
                initSamp(meta);
            }
            if (usePlastic) {
                initPlastic(meta);
            }
        }

        if (portNum > 0) {
            try {
                new JSkyCatRemoteControl(portNum, this).start();
            } catch (IOException e) {
                DialogUtil.error(e);
            }
        }

    }

    /**
     * Creates a metadata object describing this application and its icon.
     * This is used by SAMP or PLASTIC.
     *
     * @return metadata describing this application
     */
    protected Metadata createApplicationMetadata() {
        Metadata meta = new Metadata();
        meta.setName("JSkyCat");
        meta.setDescriptionText("JSkyCat - Astronomical Image and Catalog Browser");
        meta.put("author.name", "Allan Brighton");
        meta.put("author.mail", "Allan.Brighton@t-online.de");

        // use the built-in web server to host the icon, or if there is an error, use a default URL
        String defUrl = "http://java.sun.com/developer/techDocs/hi/repository/graphicsRepository/toolbarButtonGraphics/development/WebComponent24.gif";
        try {
            JSkyServer server = JSkyServer.getInstance();
            URL packageUrl = server.getJSkyPackageUrl();
            URL logoUrl = new URL(packageUrl, "images/ImageDisplay24.gif");
            meta.setIconUrl(server.isFound(logoUrl)
                    ? logoUrl.toString()
                    : defUrl);
        } catch (IOException e) {
            e.printStackTrace();
            meta.setIconUrl(defUrl);
        }
        return meta;
    }

    /**
     * Create the JSkyCat application class and display the contents of the
     * given image file or URL, if not null.
     *
     * @param imageFileOrUrl an image file or URL to display
     * @param showNavigator  if true, display the catalog navigator on startup
     */
    public JSkyCat(String imageFileOrUrl, boolean showNavigator) {
        this(imageFileOrUrl, showNavigator, true, false, 0);
    }


    /**
     * Create the JSkyCat application class and display the contents of the
     * given image file or URL, if not null.
     *
     * @param imageFileOrUrl an image file or URL to display
     */
    public JSkyCat(String imageFileOrUrl) {
        this(imageFileOrUrl, false, true, false, 0);
    }

    /**
     * Do the window layout using normal frames
     *
     * @param showNavigator  if true, display the catalog navigator on startup
     * @param imageFileOrUrl an image file or URL to display
     */
    protected void makeFrameLayout(boolean showNavigator, String imageFileOrUrl) {
        _imageFrame = makeNavigatorImageDisplayFrame(imageFileOrUrl);
        if (showNavigator) {
            NavigatorImageDisplay imageDisplay = (NavigatorImageDisplay) _imageFrame.getImageDisplayControl().getImageDisplay();
            imageDisplay.openCatalogWindow();
        }
    }


    /**
     * @return the name of this application.
     */
    protected String getAppName() {
        return "JSkyCat";
    }

    /**
     * @return the version number of this application as a String.
     */
    protected String getAppVersion() {
        return JSkyCatVersion.JSKYCAT_VERSION.substring(5);
    }

    /**
     * Make and return a frame for displaying the given image (may be null).
     *
     * @param imageFileOrUrl specifies the iamge file or URL to display
     * @return the new frame
     */
    protected NavigatorImageDisplayFrame makeNavigatorImageDisplayFrame(String imageFileOrUrl) {
        NavigatorImageDisplayFrame f = new NavigatorImageDisplayFrame(imageFileOrUrl);
        f.getImageDisplayControl().getImageDisplay().setTitle(getAppName() + " - version " + getAppVersion());
        f.setVisible(true);
        return f;
    }

    /**
     * Make and return a frame for displaying catalog information.
     *
     * @param imageDisplay used to display images from image servers
     * @return the frame for displaying catalog information
     */
    protected NavigatorFrame makeNavigatorFrame(MainImageDisplay imageDisplay) {
        return new NavigatorFrame(imageDisplay);
    }


    /**
     * Create and return a new file chooser to be used to select a local catalog file
     * to open.
     *
     * @return the file chooser
     */
    public JFileChooser makeFileChooser() {
        JFileChooser fileChooser = new JFileChooser(new File("."));

        ExampleFileFilter configFileFilter = new ExampleFileFilter(new String[]{"cfg"},
                _I18N.getString("catalogConfigFilesSkycat"));
        fileChooser.addChoosableFileFilter(configFileFilter);

        ExampleFileFilter skycatLocalCatalogFilter = new ExampleFileFilter(new String[]{"table", "tbl", "cat"},
                _I18N.getString("localCatalogFilesSkycat"));
        fileChooser.addChoosableFileFilter(skycatLocalCatalogFilter);

        ExampleFileFilter fitsFilter = new ExampleFileFilter(new String[]{"fit", "fits", "fts"},
                _I18N.getString("fitsFileWithTableExt"));
        fileChooser.addChoosableFileFilter(fitsFilter);

        fileChooser.setFileFilter(fitsFilter);

        return fileChooser;
    }


    /**
     * Exit the application with the given status.
     */
    public void exit() {
        System.exit(0);
    }


    /**
     * @return the main image display
     */
    protected MainImageDisplay getImageDisplay() {
        return _imageFrame.getImageDisplayControl().getImageDisplay();
    }

    /**
     * Convenience method to set the visibility of the image JFrame.
     *
     * @param visible set to true to show the image frame, false to hide it
     */
    public void setImageFrameVisible(boolean visible) {
        if (_imageFrame != null) {
            _imageFrame.setVisible(visible);

            if (visible) {
                SwingUtil.showFrame(_imageFrame);
            }
        }
    }

    /**
     * Initialize the SAMP connection support
     *
     * @param meta application metadata
     */
    protected void initSamp(Metadata meta) {
        SampHelper.init(meta, _imageFrame);
    }

    /**
     * Initialize the PLASTIC connection support
     *
     * @param meta application metadata
     */
    protected void initPlastic(Metadata meta) {
        PlasticHelper.init(meta, _imageFrame);
    }

    public String toString() {
        return "JSkyCat";
    }

    /**
     * Prints a usage message on stdout
     */
    protected static void _usage() {
        System.out.println("Usage: jskycat [-plastic] [-noplastic] [-samp] [-nosamp] [-setlookandfeel] [-nosetlookandfeel] [-shownavigator] [imageFileOrUrl]\n" +
                "\nIf -plastic is specified, the PLASTIC package for interprocess communication is used\n" +
                "instead of the default SAMP (use -plastic -samp to use both at once).\n" +
                "\nIf -setlookandfeel is given, a custom (JGoodies Plastic3D) look and feel is set (default, except on Mac OS X).\n" +
                "\nIf -shownavigator is specified, the catalog navigator window is displayed on startup.\n" +
                "\nThe imageFileOrUrl argument may be an image file or URL to load.");
    }

    /**
     * The main class of the JSkyCat application.
     * <p/>
     * Args:
     * [-plastic] [-noplastic]
     * [-samp] [-nosamp]
     * [-setlookandfeel] [-nosetlookandfeel]
     * [-shownavigator]
     * [imageFileOrUrl]
     * <p/>
     * If -plastic is specified, the PLASTIC package for interprocess communication is used
     * instead of the default SAMP (use -plastic -samp to use both at once).
     * <p/>
     * If -setlookandfeel is given, a custom (JGoodies Plastic3D) look and feel is set (default, except on Mac OS X)
     * <p/>
     * If -shownavigator is specified, the catalog navigator window is displayed on startup.
     * <p/>
     * The imageFileOrUrl argument may be an image file or URL to load.
     *
     * @param args command line arguments
     */
    public static void main(String args[]) {
        String imageFileOrUrl = null;
        boolean showNavigator = false;
        Boolean useSamp = null;
        Boolean usePlastic = null;
        int portNum = 0;
        boolean ok = true;
        int tilecache = 64;

        // By default, use a custom (JGoodies Plastic3D) look&feel on all systems other than Mac OS X 
        boolean setLookAndFeel = !"Mac OS X".equals(UIManager.getLookAndFeel().getName());

        for (int i = 0; i < args.length; i++) {
            if (args[i].charAt(0) == '-') {
                String opt = args[i];
                if (opt.equals("-help")) {
                    _usage();
                    System.exit(0);
                } else if (opt.equals("-setlookandfeel")) {
                    setLookAndFeel = true;
                } else if (opt.equals("-nosetlookandfeel")) {
                    setLookAndFeel = false;
                } else if (opt.equals("-shownavigator")) {
                    showNavigator = true;
                } else if (opt.equals("-plastic")) {
                    usePlastic = true;
                } else if (opt.equals("-noplastic")) {
                    usePlastic = false;
                } else if (opt.equals("-samp")) {
                    useSamp = true;
                } else if (opt.equals("-nosamp")) {
                    useSamp = false;
                } else if (opt.equals("-port")) {
                    String arg = args[++i];
                    portNum = Integer.parseInt(arg);
                } else if (opt.equals("-tilecache")) {
                    try {
                        tilecache = Integer.parseInt(args[++i]);
                    } catch (NumberFormatException e) {
                        System.out.println("Warning: bad value for -tilecache option: " + args[i]);
                    }
                } else {
                    System.out.println(_I18N.getString("unknownOption") + ": " + opt);
                    ok = false;
                    break;
                }
            } else {
                if (imageFileOrUrl != null) {
                    System.out.println(_I18N.getString("specifyOneImageOrURL") + ": " + imageFileOrUrl);
                    ok = false;
                    break;
                }
                imageFileOrUrl = args[i];
            }
        }

        // Handle default interop options. A non-null value indicates an option was given
        // to enable or disable the service
        if (useSamp == null && usePlastic == null) {
            // no options: use SAMP by default
            useSamp = true;
            usePlastic = false;
        } else if (useSamp == null) {
            useSamp = false;
        } else if (usePlastic == null) {
            usePlastic = false;
        }

        if (!ok) {
            _usage();
            System.exit(1);
        }

        _startJSkyCat(imageFileOrUrl, tilecache, setLookAndFeel, showNavigator, useSamp, usePlastic, portNum);
    }

    /**
     * Start the JSkyCat application
     *
     * @param imageFileOrUrl optional image file name or URL
     * @param tilecache      size of JAI tile cache in MB
     * @param setLookAndFeel if true, set the look and feel
     * @param showNavigator  if true, display the catalog window on start
     * @param useSamp        if true, use SAMP for communication (default)
     * @param usePlastic     if true, use PLASTIC instead of SAMP for communication
     * @param portNum        optional port number for remote access (deprecated)
     */
    private static void _startJSkyCat(final String imageFileOrUrl, int tilecache, boolean setLookAndFeel,
                                      final boolean showNavigator,
                                      final boolean useSamp, final boolean usePlastic, final int portNum) {

        // JAI tile cache
        TileCache cache = JAI.getDefaultInstance().getTileCache();
        cache.setMemoryCapacity(tilecache * 1024 * 1024);
        // For testing
        // new tilecachetool.TCTool();

        // Look and feel
        System.setProperty("apple.laf.useScreenMenuBar", "true"); // only applies to default Mac OS X L&F
        if (setLookAndFeel) {
            try {
                UIManager.setLookAndFeel(new Plastic3DLookAndFeel());
            } catch (UnsupportedLookAndFeelException e) {
                DialogUtil.error(e);
            }
        }
        UIManager.put("ToolTip.background", new ColorUIResource(245, 245, 220));

        // Start in AWT event thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new JSkyCat(imageFileOrUrl, showNavigator, useSamp, usePlastic, portNum);
            }
        });
    }
}

