#!/bin/sh
#
# Make a release
#
# usage: sh make_release [-nosvn]
#
# If -nosvn is specified, the svn export is not done.

# top level JSky source directory
top=`dirname $0`/..
top=`cd $top; pwd`

# directory that should contain the release files
distdir=$top/dist

# base directory to hold the exported sources
export=$distdir/export

version=`grep '<version>' $top/pom.xml | sed -e 's/[^0-9\.]*//g'`
jsky_version=jsky-$version

# top level SVN URL
svnroot='https://jsky.svn.sourceforge.net/svnroot/jsky'

# ------------------------------------------------------------

echo "Making release for $jsky_version"
set -x

# directory used to build the source release
srcdir=$export/$jsky_version

# top level JSky SVN dir
jsky=JSky

if [ "$1" != "-nosvn" ] ; then
    # tag the current sources, then export to a release dir
    svn copy "$svnroot/trunk" "$svnroot/tags/$jsky_version" -m "Tagged release $jsky_version"
    
    rm -rf $srcdir
    (cd $export; svn export $svnroot/tags/$jsky_version)
fi

(cd $srcdir
    mvn.sh -o clean

    # generate source packages
    (cd $export; zip -r $distdir/${jsky_version}-src.zip $jsky_version)
    # add a version without the maven repository
    (cd $distdir
	cp ${jsky_version}-src.zip ${jsky_version}-src-norepo.zip
	zip -d ${jsky_version}-src-norepo.zip $jsky_version/repository/\*
    )

    # build
    mvn.sh -o install javadoc:javadoc

    # build rpm on linux
    test `uname` = 'Linux' && (cd jskycat; mvn.sh -o rpm:rpm)

    # generate and copy api doc jar
    (cd $srcdir/target/site/apidocs; zip -r $distdir/${jsky_version}-doc.zip .)
    cp $srcdir/doc/jsky.pdf $distdir

    # copy install packages
    # Rename the assembly dir, which contains the start script and exe file, then zip it
    (cd $srcdir/jskycat/target
	mkdir tmp
	mv jskycat-${version}-assembly.dir tmp/jskycat-${version}
	(cd tmp; zip -r $distdir/jskycat-${version}.zip jskycat-${version})
	mv tmp/jskycat-${version} jskycat-${version}-assembly.dir
	rmdir tmp
    )
    cp $srcdir/jskycat/target/${jsky_version}.jar $distdir

    # DMG file (only built on Mac OS X, automatically)
    dmg=$srcdir/jskycat/target/jskycat-$version.dmg
    test -f $dmg && cp $dmg $distdir

    # Zipped Mac application (always built automatically)
    cp $srcdir/jskycat/target/jskycat-${version}-app.zip $distdir

    # RPM (only built on Linux, with mvn.sh -o rpm:rpm)
    rpm=$srcdir/jskycat/target/rpm/RPMS/noarch/jskycat-${version}-1.noarch.rpm
    test -f $rpm && cp $rpm $distdir
)

# cleanup
rm -rf $export
