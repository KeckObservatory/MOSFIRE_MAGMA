#!/bin/sh
#
# Removes generated release files
#

files="jsky-3.0-doc.zip jsky-3.0.jar jsky-3.0-src.zip jsky-3.0-src-norepo.zip jsky.pdf jskycat-3.0-app.zip jskycat-3.0.zip jskycat-3.0.dmg jskycat-3.0-1.noarch.rpm"
rm -f $files

