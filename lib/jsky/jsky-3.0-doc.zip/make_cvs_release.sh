#!/bin/sh
#
# Make a release
#
# usage: sh make_release [-nocvs]
#
# If -nocvs is specified, the cvs export is not done.

# top level JSky source directory
top=`dirname $0`/..
top=`cd $top; pwd`

# directory that should contain the release files
distdir=$top/dist

# base directory to hold the exported sources
export=$distdir/export

version=`grep '<version>' $top/pom.xml | sed -e 's/[^0-9\.]*//g'`
jsky_version=jsky-$version

# ------------------------------------------------------------

echo "Making release for $jsky_version"
set -x

# directory used to build the source release
srcdir=$export/$jsky_version

# top level JSky CVS dir
jsky=JSky

# determine CVSROOT
if [ -e $top/CVS/Root ] ; then
    CVSROOT=`cat $top/CVS/Root`; export CVSROOT
else
    echo "Error: Can't determine CVSROOT"
    exit 1
fi

if [ "$1" != "-nocvs" ] ; then
    # tag the current sources, then export to a release dir
    tag=`echo $jsky_version | sed -e 's/\-/_/g' -e 's/\./_/g'`
    (cd $top; cvs tag -F $tag .)
    
    rm -rf $srcdir
    mkdir -p $srcdir || exit 1

    (cd $srcdir; cvs export -r $tag $jsky)

    # remove extra directory level: jsky-3.0/JSky => jsky-3.0
    (cd $srcdir; mv $jsky tmp; mv tmp/* .; rm -rf tmp)
fi

(cd $srcdir
    find . -type d -name 'CVS' -prune -print -exec rm -rf {} \;
    mvn.sh -o clean

    # generate source packages
    (cd $export; zip -r $distdir/${jsky_version}-src.zip $jsky_version)
    # add a version without the maven repository
    (cd $distdir
	cp ${jsky_version}-src.zip ${jsky_version}-src-norepo.zip
	zip -d ${jsky_version}-src-norepo.zip $jsky_version/repository/\*
    )

    # build
    mvn.sh -o install javadoc:javadoc

    # build rpm on linux
    test `uname` = 'Linux' && (cd jskycat; mvn.sh -o rpm:rpm)

    # generate and copy api doc jar
    (cd $srcdir/target/site/apidocs; zip -r $distdir/${jsky_version}-doc.zip .)
    cp $srcdir/doc/jsky.pdf $distdir

    # copy install packages
    # Rename the assembly dir, which contains the start script and exe file, then zip it
    (cd $srcdir/jskycat/target
	mkdir tmp
	mv jskycat-${version}-assembly.dir tmp/jskycat-${version}
	(cd tmp; zip -r $distdir/jskycat-${version}.zip jskycat-${version})
	mv tmp/jskycat-${version} jskycat-${version}-assembly.dir
	rmdir tmp
    )
    cp $srcdir/jskycat/target/${jsky_version}.jar $distdir

    # DMG file (only built on Mac OS X, automatically)
    dmg=$srcdir/jskycat/target/jskycat-$version.dmg
    test -f $dmg && cp $dmg $distdir

    # Zipped Mac application (always built automatically)
    cp $srcdir/jskycat/target/jskycat-${version}-app.zip $distdir

    # RPM (only built on Linux, with mvn.sh -o rpm:rpm)
    rpm=$srcdir/jskycat/target/rpm/RPMS/noarch/jskycat-${version}-1.noarch.rpm
    test -f $rpm && cp $rpm $distdir
)

# cleanup
rm -rf $export
